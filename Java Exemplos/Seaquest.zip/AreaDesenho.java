import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;
import java.util.*;

class AreaDesenho extends JComponent
{

	AreaDesenho()
	{
	}

	public void paint(Graphics g)
	{
		int largura = getBounds().width;
		int altura  = getBounds().height;
	    g.setColor(Color.blue);
		g.fillRect(0, 0, largura, altura);
		g.setColor(Color.red);
		g.drawLine(0, 50,largura, 50);
	}
}