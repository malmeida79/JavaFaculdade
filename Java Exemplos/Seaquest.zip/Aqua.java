import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;
import java.util.*;

class Aqua extends Thread
{
	static int VELOCIDADE = 100;
	static int AVANCO = 8;
	static int ALTURAE = 80;
	static int ALTURAD = 130;
	Image imagem;
	int alturaImagem, larguraImagem;
	AreaDesenho areaDesenho;
	Seaquest seaquest;
	Graphics g;
	int posInicial, posFinal, qualAvanco;
	boolean paraLa;
	int ContaTiros = 0;
	int x = 0;
	Rectangle retangulo;
	int indiceNoArray;
	Aqua[] itens;

	int subX, subY;

	boolean acertado;
	

	Aqua(Seaquest seaquest,Image imagemSubI, AreaDesenho areaDesenho, boolean paraLa, int indiceNoArray, Aqua[] itens)
	{
		this.itens = itens;
		this.indiceNoArray = indiceNoArray;
		this.areaDesenho = areaDesenho;
		this.seaquest = seaquest;
		this.paraLa = paraLa;

	
		imagem = imagemSubI;
 		alturaImagem = imagem.getHeight(new Observador());
 		larguraImagem = imagem.getWidth(new Observador());

 		retangulo = new Rectangle(x, 0, larguraImagem, alturaImagem);
		g = areaDesenho.getGraphics();
        ContaTiros = 0;
          
        acertado = false;
	}

	public void foiAcertado()
	{		acertado = true;	}

	public int devolveIndice()
	{
		int i = 0, indiceRetorno = 0;
		boolean achou = false;
		while ((i < 20)&& (!achou))
		{
			if (itens[i] == null)
			{
				achou = true;
				indiceRetorno = i;
			}
			else
				i++;
		}
		return(indiceRetorno);
	}

	public void run()
	{
   		if(seaquest.submarino.explodiu.getFim()==0)
		{
			if((Math.random() > 0.5)&&(seaquest.submarino.explodiu.getFim()==0))
					Inimigo(70);
			if((Math.random() < 0.5)&&(seaquest.submarino.explodiu.getFim()==0))
				Inimigo(120);
		}
	}

	public void Inimigo(int profundo)
	{

		int indice = 0;
//---Direita
   		if(seaquest.submarino.explodiu.getFim()==0)
   		if (paraLa)
		{
			if(!acertado)
  			for (x = 0; ((x < areaDesenho.getBounds().width) && (!acertado)); x += AVANCO)
 	    	{
 	    		if(seaquest.submarino.explodiu.getFim()==1)
 	    			break;
 	    		
 	    		if(acertado)
 	    			break;
			  	indice = devolveIndice();
		  	  	if (g != null)
				{
					g.drawImage(imagem, x, ALTURAD+profundo, new Observador());
					retangulo.setRect(x, ALTURAD+profundo, larguraImagem, alturaImagem/10);

					Encontro();
					
					try
					{
						Thread.sleep(VELOCIDADE);
					}
					catch(InterruptedException ie) {}
				}
			}
		}
//---Esquerda
		else
		{
    		if(seaquest.submarino.explodiu.getFim()==0)
			for (x = areaDesenho.getBounds().width; ((x > -70) && (!acertado)); x -= AVANCO)
			{
 	    		if(seaquest.submarino.explodiu.getFim()==1)
 	    			break;

				indice = devolveIndice();
				if (g != null)
				{
	  	    		g.drawImage(imagem, x, ALTURAE+profundo, new Observador());
					retangulo.setRect(x-10, ALTURAE+profundo, larguraImagem, alturaImagem/10);

					Encontro();
					try
					{
						Thread.sleep(VELOCIDADE);
					}
					catch(InterruptedException ie) {}
				}
			}
		} 
		itens[indiceNoArray] = null;
	}

	public void Encontro()
	{
		for (int indiceArray = 0; indiceArray < 20; indiceArray++)
		{
			if(seaquest.submarino.explodiu.getFim()==1)
				break;
			if (itens[indiceArray] != null)
			{	int xtamanho= seaquest.submarino.posicoes.getHorizonte() + seaquest.submarino.larguraImagem;
				int xSubmarino = seaquest.submarino.posicoes.getHorizonte();
				for(int a= xSubmarino ; a <=xtamanho; a++)
				{
					int ytamanho = 	seaquest.submarino.posicoes.getVertical() + seaquest.submarino.alturaImagem;
					int ySubmarino = seaquest.submarino.posicoes.getVertical();
					for(int b= ySubmarino; ((b <=ytamanho)&&(!acertado)); b++)
					{
						if((itens[indiceArray].retangulo.contains(a,b))&&(seaquest.submarino.explodiu.getFim()!=1))
						{
							areaDesenho.repaint();
							itens[indiceArray].foiAcertado();
							seaquest.submarino.Resgate();
							itens[indiceArray] = null;
							foiAcertado();
						}
					}
				}
			}
		}
	}
}