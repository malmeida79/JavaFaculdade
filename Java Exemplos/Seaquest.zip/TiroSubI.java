import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;
import java.util.*;

class TiroSubI extends Thread
{
	static int VELOCIDADE = 30;
	static int AVANCO = 5;
	int ALTURAE;
	int ALTURAD;
	Image imagemPara;
	AudioClip somTiro;
	AreaDesenho areaDesenho;
	Graphics g;
	int largura, altura, x, y, altitude, posicaoInicial;
	boolean acertou;
	boolean paraLa;
	int alturaImagem, larguraImagem;
	String quem;
	
	TiroSubI[] arrayTiro;
	Seaquest game;
	
	Rectangle retangulo;

	TiroSubI (String quem,boolean paraLa, Seaquest seaquest, AreaDesenho areaDesenho, int posicaoInicial, int altitude)
	{
		this.game = seaquest;
		this.areaDesenho = areaDesenho;
		this.paraLa = paraLa;
		imagemPara = Toolkit.getDefaultToolkit().getImage("bala.gif");
		g  = areaDesenho.getGraphics();
		largura = areaDesenho.getBounds().width;
		altura  = areaDesenho.getBounds().height;
		this.posicaoInicial = posicaoInicial;
		this.altitude = altitude;
		this.ALTURAD = altitude;
		this.ALTURAE = altitude;
		this.quem = quem;
		acertou = false;
		alturaImagem = imagemPara.getHeight(new Observador());
		larguraImagem = imagemPara.getWidth(new Observador());

		retangulo = new Rectangle(x, altitude, larguraImagem, alturaImagem);

	    try
	    {
			somTiro = Applet.newAudioClip(new URL("file:" + System.getProperty("user.dir") + "/Type.wav"));
		}
		catch (MalformedURLException eitcha)
		{
			System.out.println("Erro na abertura dos arquivos de som");
		}
	}

	public void Matou()
	{
		acertou = true;
	}

	public void run()
	{
		if (somTiro != null)
			somTiro.play();
		if (paraLa==false)
		{
			for (x = posicaoInicial-5; x > -70; x -= AVANCO)
			{
				if ((g != null)&&(!acertou))
				{
					g.drawImage(imagemPara, x, ALTURAE+20, new Observador());
					retangulo.setRect(x, ALTURAE+20, larguraImagem+10, alturaImagem/10);
					try
					{
						Thread.sleep(VELOCIDADE);
					}
					catch(InterruptedException ie)	{}
				}
		    }
		} 
		if(paraLa==true)
		{
			for (x = posicaoInicial; x < areaDesenho.getBounds().width; x += AVANCO)
			{
				if ((g != null)&&(!acertou))
				{
					g.drawImage(imagemPara, x+45, ALTURAD+20, new Observador());
					retangulo.setRect(x+45, ALTURAD+20, larguraImagem, alturaImagem/10);
					try
					{
						Thread.sleep(VELOCIDADE);
					}
					catch(InterruptedException ie)	{}			
				}
	    	}
	 	}
	}


	public void Atingido()
	{
		
		
	}



}

