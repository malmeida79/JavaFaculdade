import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;
import java.util.*;
import java.io.*;
import java.lang.Integer.*;

public class ListaPontos extends JFrame implements ActionListener
{
	JLabel lnome, lPontos;
	JButton b1;
	JPanel p;
	JTextArea ta;

	ListaPontos()
	{
		setSize(200,300);
		setTitle("Seaquest - Andr�");

		lnome = new JLabel("Nome");
		lPontos = new JLabel("Pontos");
		p= new JPanel();
		p.add(lnome);
		p.add(lPontos);
		b1 = new JButton("OK");
	
		ta = new JTextArea(1, 1);
		getContentPane().add(ta, "Center");


		getContentPane().add("South", b1);
		getContentPane().add("North", p);

		b1.addActionListener(this);
		abrirC();
	}

	public void actionPerformed(ActionEvent ae)
	{
		String qualBotao = ae.getActionCommand();

		if (qualBotao.equals("OK"))
		{
			gravarC();
			setVisible(false);
		}
	}
	
	public void gravarC()
	{
		String conteudo_ta;
		conteudo_ta = ta.getText();

		FileDialog fff = new FileDialog(this, "Salvar", FileDialog.SAVE);
		fff.setVisible(true);
		if (fff.getFile() != null)
		{
			try
			{
				FileOutputStream saida = new FileOutputStream(fff.getDirectory()+"pontos.txt");
				ObjectOutputStream out = new ObjectOutputStream(saida);
				out.writeObject(conteudo_ta);
				out.close();
			}
			catch(IOException e)
			{
			}
		}
	}

	public void abrirC()
	{
		FileDialog fff = new FileDialog(this, "Abrir", FileDialog.LOAD);
		fff.setVisible(true);
		String conteudo_ta;
		if (fff.getFile() != null)
		{
	        ta.setText("");

    	    try
			{
				FileInputStream  infile = new FileInputStream(fff.getDirectory()+"pontos.txt");
				ObjectInputStream  in = new ObjectInputStream(infile);
				conteudo_ta = (String) in.readObject();
				ta.setText(conteudo_ta);
			}
			catch (ClassNotFoundException e)
			{
			}
			catch (IOException e)
			{
			}
			catch (Exception e)
			{
			}
		}
	}

	public static void main(String args[])
	{
		ListaPontos S = new ListaPontos();
		S.setVisible(true);
	}

	
	
}
