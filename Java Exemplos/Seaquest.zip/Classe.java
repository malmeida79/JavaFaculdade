import java.util.*;

class Classe
{
	static private int horizontal;
	static private int vertical;
	static private String lado;

	Classe(int horizontal, int vertical, String lado)
	{
	  this.horizontal = horizontal;
	  this.vertical  = vertical;
	  this.lado = lado;
	}

	public void setHorizonte(int horizontal)
	{
		 this.horizontal = horizontal;
	}
	public int getHorizonte()
	{
		 return (horizontal);
	}

	public void setVertical(int vertical)
	{
		this.vertical = vertical;
	}
	public int getVertical()
	{
		return (vertical);
	}
	 
	public void setLado(String lado)
	{
		this.lado = lado;	
	}
	public String getLado()
	{
		return(lado);
	}


}

