import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;
import java.util.*;

class SubI extends Thread
{
	static int VELOCIDADE = 100;
	static int AVANCO = 8;
	static int ALTURAE = 80;
	static int ALTURAD = 130;
	static int QUANTOSTIROS = 3;
	boolean Vazio;
	Image imagem, boom;
	int alturaImagem, larguraImagem;
	AreaDesenho areaDesenho;
	Seaquest seaquest;
	Graphics g;
	int posInicial, posFinal, qualAvanco;
	boolean paraLa;
	int ContaTiros = 0;
	int x = 0;
	Rectangle retangulo;
	int peixeOUsub;
	int indiceNoArray;
	SubI[] itens;

	int subX, subY;

	boolean acertado;
	TiroSubI[] arrayTiro;
	SubI[] aqua;
	

	SubI(int peixeOUsub, Seaquest seaquest,Image imagemSubI, AreaDesenho areaDesenho, boolean paraLa,
			int indiceNoArray, SubI[] itens, TiroSubI[] array)
	{
		this.itens = itens;
		this.indiceNoArray = indiceNoArray;
		this.areaDesenho = areaDesenho;
		this.seaquest = seaquest;
		this.paraLa = paraLa;
		this.peixeOUsub = peixeOUsub;	//Peixe =0			Sub =1		Merg =2

		if(peixeOUsub == 2)
			this.aqua = itens;
		else
			this.arrayTiro = array;

		boom = Toolkit.getDefaultToolkit().getImage("boom.gif");
		
		imagem = imagemSubI;
 		alturaImagem = imagem.getHeight(new Observador());
 		larguraImagem = imagem.getWidth(new Observador());

		if((alturaImagem == -1)&&(peixeOUsub == 0))
		{
			alturaImagem=21;
		}
		if((alturaImagem == -1)&&(peixeOUsub == 1))
		{
			alturaImagem=24;
		}


 		retangulo = new Rectangle(x, 0, larguraImagem, alturaImagem);
		g = areaDesenho.getGraphics();
        ContaTiros = 0;
        if (Math.random() > 0.5)
           Vazio = true;
        else
           Vazio = false;
           
        acertado = false;
	}

	public void foiAcertado()
	{		acertado = true;	}


	public int devolveIndice()
	{
		int i = 0, indiceRetorno = 0;
		boolean achou = false;
		while ((i < 20)&& (!achou))
		{
			if (itens[i] == null)
			{
				achou = true;
				indiceRetorno = i;
			}
			else
				i++;
		}
		return(indiceRetorno);
	}

	public void run()
	{
   		if(seaquest.submarino.explodiu.getFim()==0)
		{
			if((Math.random() < 0.5)&&(seaquest.submarino.explodiu.getFim()==0))
			{
				if((Math.random() > 0.5)&&(seaquest.submarino.explodiu.getFim()==0))
					Inimigo(70);
				if((Math.random() < 0.5)&&(seaquest.submarino.explodiu.getFim()==0))
					Inimigo(120);
			}
			if((Math.random() < 0.5)&&(seaquest.submarino.explodiu.getFim()==0))
				Inimigo(1);
		}
	}

	public void Inimigo(int profundo)
	{

		int indice = 0;
//---Direita
   		if(seaquest.submarino.explodiu.getFim()==0)
   		if (paraLa)
		{
			if(!acertado)
  			for (x = 0; ((x < areaDesenho.getBounds().width) && (!acertado)); x += AVANCO)
 	    	{
 	    		if(seaquest.submarino.explodiu.getFim()==1)
 	    			break;
 	    		
 	    		if(acertado)
 	    			break;
			  	indice = devolveIndice();
		  	  	if (g != null)
				{
					g.drawImage(imagem, x, ALTURAD+profundo, new Observador());
					retangulo.setRect(x, ALTURAD+profundo, larguraImagem, alturaImagem/10);

/*					int x0=0;	int y0=0;	int x1=0;	int y1=0;
					x0=x;
					x1=x+larguraImagem;
					y0=ALTURAD+profundo;
					y1=ALTURAD+profundo+alturaImagem;
					
					g.setColor(Color.red);
					g.drawLine(x0, y0, x1, y0);
					g.setColor(Color.blue);
					g.drawLine(0, y0, x0, y0);
						
					g.setColor(Color.green);
					g.drawLine(x0, y1, x1, y1);
					g.setColor(Color.blue);
					g.drawLine(0, y1, x0, y1);
*/
					this.Colisao();
					
		  	  		  //lan�ar Tiros
					if ((ContaTiros < QUANTOSTIROS) && (!Vazio) && (peixeOUsub == 1))
					{
						int valor = new Date().getSeconds()+1;
						if ((x % valor) == 0)
						{
							arrayTiro[indice] = new TiroSubI("I", paraLa, seaquest,  areaDesenho, x, ALTURAD+profundo);
							arrayTiro[indice].start();
							ContaTiros++;
						}
					}
					try
					{
						Thread.sleep(VELOCIDADE);
					}
					catch(InterruptedException ie) {}
				}
			}
		}
//---Esquerda
		else
		{
    		if(seaquest.submarino.explodiu.getFim()==0)
			for (x = areaDesenho.getBounds().width; ((x > -70) && (!acertado)); x -= AVANCO)
			{
 	    		if(seaquest.submarino.explodiu.getFim()==1)
 	    			break;

				indice = devolveIndice();
				if (g != null)
				{
	  	    		g.drawImage(imagem, x, ALTURAE+profundo, new Observador());
					retangulo.setRect(x-10, ALTURAE+profundo, larguraImagem, alturaImagem/10);
/*
					int x0=0;	int y0=0;	int x1=0;	int y1=0;
					x0=x;
					x1=x+larguraImagem;
					y0=ALTURAE+profundo;
					y1=ALTURAE+profundo+alturaImagem;
					
					g.setColor(Color.red);
					g.drawLine(x0, y0, x1, y0);
					g.setColor(Color.blue);
					g.drawLine(x1, y0, areaDesenho.getBounds().width, y0);
						
					g.setColor(Color.green);
					g.drawLine(x0, y1, x1, y1);
					g.setColor(Color.blue);
					g.drawLine(x1, y1, areaDesenho.getBounds().width, y1);
*/
					this.Colisao();
					
			  	  //lan�ar Tiros
  	  	  			if ((ContaTiros < QUANTOSTIROS) && (!Vazio)&& (peixeOUsub == 1))
  	  	  			{
						int valor = new Date().getSeconds()+1;
						if ((x % valor) == 0)
						{
							arrayTiro[indice] = new TiroSubI("I", paraLa, seaquest, areaDesenho, x, ALTURAE+profundo);
							arrayTiro[indice].start();
							ContaTiros++;
						}
					}

					try
					{
						Thread.sleep(VELOCIDADE);
					}
					catch(InterruptedException ie) {}
				}
			}
		} 
		itens[indiceNoArray] = null;
	}

	public void Colisao()
	{
		for (int indiceArray = 0; indiceArray < 20; indiceArray++)
		{
			if(seaquest.submarino.explodiu.getFim()==1)
				break;
			if (itens[indiceArray] != null)
			{	int xtamanho= seaquest.submarino.posicoes.getHorizonte() + seaquest.submarino.larguraImagem;
				int xSubmarino = seaquest.submarino.posicoes.getHorizonte();
				for(int a= xSubmarino ; a <=xtamanho; a++)
				{
					int ytamanho = 	seaquest.submarino.posicoes.getVertical() + seaquest.submarino.alturaImagem;
					int ySubmarino = seaquest.submarino.posicoes.getVertical();
					for(int b= ySubmarino; ((b <=ytamanho)&&(!acertado)); b++)
					{
						if((itens[indiceArray].retangulo.contains(a,b))&&(seaquest.submarino.explodiu.getFim()!=1))
						{
							areaDesenho.repaint();
							itens[indiceArray].foiAcertado();
							seaquest.submarino.Explode();
							itens[indiceArray] = null;
							foiAcertado();
						}
					}
				}
			}
		}
	}



}