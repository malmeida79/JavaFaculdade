import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;
import java.util.*;

class Submarino extends JComponent
{
	AreaDesenho areaDesenho;
	Seaquest game;

  	AudioClip somTiro, somBoom;
	Image subD, subE, boom;
	Rectangle retangulo;
	Graphics g;
	int largura, altura;
	int alturaImagem, larguraImagem;
	boolean praEsq;
	boolean praDir;

	private int horizontal;
	private int vertical;

	Fim explodiu;
	Fim vida;
	Fim mergulhadores;
	Classe posicoes;
	TiroSubI tiros;

	Submarino(AreaDesenho areaDesenho)
	{
		this.areaDesenho = areaDesenho;
		explodiu = new Fim(0);
		vida = new Fim(4);
		mergulhadores = new Fim(0);
		posicoes = new Classe(largura/2-50, 35, "D");
		subE = Toolkit.getDefaultToolkit().getImage("SubE.gif");
		subD = Toolkit.getDefaultToolkit().getImage("SubD.gif");
		boom = Toolkit.getDefaultToolkit().getImage("boom.gif");
		g = areaDesenho.getGraphics();
		largura = areaDesenho.getBounds().width;
		altura  = areaDesenho.getBounds().height;
		retangulo = new Rectangle(0, 0, larguraImagem, alturaImagem);
	    try
	    {
			somTiro = Applet.newAudioClip(new URL("file:" + System.getProperty("user.dir") + "/tiro.wav"));
			somBoom = Applet.newAudioClip(new URL("file:" + System.getProperty("user.dir") + "/Explode.wav"));
		}
		catch (MalformedURLException eitcha)
		{
			System.out.println("Erro na abertura dos arquivos de som");
		}
	}


	public void Zera_Posicoes()
	{
		vertical=35;
		posicoes.setVertical(vertical);
		horizontal=largura/2-50;
		posicoes.setHorizonte(horizontal-5);

		alturaImagem = subD.getHeight(new Observador());
		larguraImagem = subD.getWidth(new Observador());

		g.drawImage(subD, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
		retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);

		g.setColor(Color.red);
		g.drawLine(0, 50,largura, 50);
		vida.setFim(4);
		explodiu.setFim(0);
	}

	public void Esquerda()
	{
		if(explodiu.getFim() == 0)
		{
			alturaImagem = subE.getHeight(new Observador());
			larguraImagem = subE.getWidth(new Observador());
			g.drawImage(subE, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
			retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);
			g.drawImage(subE, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
			retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);

			if(posicoes.getHorizonte() > 0)
			{
				posicoes.setHorizonte(posicoes.getHorizonte()-5);
			}
			g.drawImage(subE, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
			retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);
			if(vertical <= 50)
			{
				g.setColor(Color.red);
				g.drawLine(0, 50,largura, 50);
			}
			posicoes.setLado("E");			
		}
	}

	public void Direita()
	{
		if(explodiu.getFim() == 0)
		{
			alturaImagem = subD.getHeight(new Observador());
			larguraImagem = subD.getWidth(new Observador());
			if(posicoes.getHorizonte() < largura-55)
			{
				posicoes.setHorizonte(posicoes.getHorizonte()+5);
			}
			g.drawImage(subD, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
			retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);
			if(vertical <= 50)
			{
				g.setColor(Color.red);
				g.drawLine(0, 50,largura, 50);
			}
			posicoes.setLado("D");
		}
	}
	
	public void Desce()
	{
		if(explodiu.getFim() == 0)
		{	
			if(posicoes.getVertical() < altura-30)
			{
				posicoes.setVertical(posicoes.getVertical()+5);
			}
			if(posicoes.getLado() == "E")
			{
				alturaImagem = subE.getHeight(new Observador());
				larguraImagem = subE.getWidth(new Observador());
				g.drawImage(subE, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
				retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);
				}
			if(posicoes.getLado() == "D")
			{
				alturaImagem = subD.getHeight(new Observador());
				larguraImagem = subD.getWidth(new Observador());
				g.drawImage(subD, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
				retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);
			}
			if(posicoes.getVertical() <= 50)
			{
				g.setColor(Color.red);
				g.drawLine(0, 50,largura, 50);
			}
		}
	}

	public void Sobe()
	{
		if(explodiu.getFim() == 0)
		{
			if(posicoes.getVertical() > 35)
			{
				posicoes.setVertical(posicoes.getVertical()-5);
			}
			if(posicoes.getLado() == "E")
			{
				alturaImagem = subE.getHeight(new Observador());
				larguraImagem = subE.getWidth(new Observador());
				g.drawImage(subE, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
				retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);
			}
			if(posicoes.getLado() == "D")
			{
				alturaImagem = subD.getHeight(new Observador());
				larguraImagem = subD.getWidth(new Observador());
				g.drawImage(subD, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
				retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);
			}
			if(posicoes.getVertical() <= 50)
			{
				g.setColor(Color.red);
				g.drawLine(0, 50,largura, 50);
			}
		}
	}

	public void Atira(Seaquest game)
	{
		if(explodiu.getFim() == 0)
		{
			int atirou;
			atirou =Integer.parseInt(game.lcontaTiro.getText());
			atirou++;
			this.game = game;
			game.lcontaTiro.setText(String.valueOf(atirou));

			if(posicoes.getLado() == "D")
				tiros = new TiroSubI("S",true, game, areaDesenho, posicoes.getHorizonte()+15, posicoes.getVertical());
			else
				tiros = new TiroSubI("S",false, game, areaDesenho, posicoes.getHorizonte()-15, posicoes.getVertical());
			tiros.start();
	
//			if (somTiro != null)
//				  somTiro.play();

		}
	}

	public void Resgate()
	{
//		game.atualizaAcertos(false);
		mergulhadores.setFim(mergulhadores.getFim()+1);
		System.out.println("Pontos : "+String.valueOf(mergulhadores.getFim()*50));

	}

	public void Explode()
	{
		explodiu.setFim(1);
		alturaImagem = boom.getHeight(new Observador());
		larguraImagem = boom.getWidth(new Observador());
		areaDesenho.repaint();
		if(somBoom!=null)
			somBoom.play();
		explodiu.setFim(1);	
		g.drawImage(boom, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
		retangulo.setRect(posicoes.getHorizonte(), posicoes.getVertical(), larguraImagem+10, alturaImagem/10);
		Conta_Vida();
	}
	
	public void Conta_Vida()
	{
		System.out.println("Conta_Vida"+vida.getFim());
		g.drawImage(boom, posicoes.getHorizonte(), posicoes.getVertical(), new Observador());
		vida.setFim(vida.getFim()-1);
		if(vida.getFim() >= 0)
		{
			System.out.println("Conta_Vida "+vida.getFim());
//			game.lcontavida.setText("V");

		}
		else
		{
			g.setColor(Color.red);
			g.drawString("GAME OVER "+g.getFont(),200,200);
		}
	}
}
