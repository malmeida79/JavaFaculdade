import java.util.*;

class Fim
{
	private int explodiu;

	Fim(int explodiu)
	{
	  this.explodiu = explodiu;
	}

	public void setFim(int explodiu)
	{
		 this.explodiu = explodiu;
	}
	public int getFim()
	{
		 return (explodiu);
	}

}

