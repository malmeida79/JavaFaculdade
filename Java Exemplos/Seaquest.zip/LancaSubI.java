import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;
import java.util.*;

class LancaSubI extends Thread
{
	static int FREQUENCIA = 5500;
	AreaDesenho areaDesenho;
	Seaquest seaquest;
	private boolean continua;
	Image imagemSubD, imagemSubE, imagemPeixeD, imagemPeixeE;

  	SubI[] itens;
	TiroSubI[] arrayParaquedistas;

	LancaSubI (AreaDesenho areaDesenho, Seaquest seaquest, SubI[] itens, TiroSubI[] arrayParaquedistas)
	{
		this.itens = itens;
		this.arrayParaquedistas = arrayParaquedistas;
		this.areaDesenho = areaDesenho;
		this.seaquest = seaquest;

		imagemSubD = Toolkit.getDefaultToolkit().getImage("subID.gif");
		imagemSubE = Toolkit.getDefaultToolkit().getImage("subIE.gif");

		imagemPeixeD = Toolkit.getDefaultToolkit().getImage("FishiD.gif");
		imagemPeixeE = Toolkit.getDefaultToolkit().getImage("FishiE.gif");
		
		continua = true;	
  }

	public void para()
	{
		continua = false;
	}
	
	public int devolveIndice()
	{
		int i = 0, indiceRetorno = 0;
		boolean achou = false;
		while ((i < 20)&& (!achou))
		{
			if (itens[i] == null)
			{
				achou = true;
				indiceRetorno = i;
			}
			else
			  i++;
		}
		return(indiceRetorno);
	}

	public void run()
	{
		int indice = 0;
		while ((continua)||(seaquest.submarino.explodiu.getFim()!=1))
		{
			indice = devolveIndice();
			if (Math.random() > 0.5)
			{
				if (Math.random() > 0.5)
				{
				    itens[indice] = new SubI(1, seaquest, imagemSubD, areaDesenho, true, indice, itens, arrayParaquedistas);
	  			}
				else
				{
		    	    itens[indice] = new SubI(1, seaquest, imagemSubE, areaDesenho, false, indice, itens, arrayParaquedistas);
				}
			}
			else
			{
				if (Math.random() > 0.5)
				{
				    itens[indice] = new SubI(0, seaquest, imagemPeixeD, areaDesenho, true, indice, itens, arrayParaquedistas);
				}
				else
				{
		        itens[indice] = new SubI(0, seaquest, imagemPeixeE, areaDesenho, false, indice, itens, arrayParaquedistas);
				}
			}
			try
			{
				int tempo = (int) Math.floor(Math.random() * FREQUENCIA);
				Thread.sleep(tempo);
				if((tempo > 700)&&(seaquest.submarino.explodiu.getFim()!=1)) //para nao sobrepor um desenho no outro
  					itens[indice].start();
			}
			catch (InterruptedException ie)	{}
		}
	}
}