import java.util.*;

class Tempo
{
	static private int conttempo;

	Tempo(int conttempo)
	{
	  this.conttempo = conttempo;
	}

	public void setTempo(int conttempo)
	{
		 this.conttempo = conttempo;
	}
	public int getTempo()
	{
		 return (conttempo);
	}

}

