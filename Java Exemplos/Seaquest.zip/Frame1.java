import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Frame1 extends JFrame 
{
  JPanel contentPane;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JButton jbtnOK = new JButton();
  JPanel jPanel2 = new JPanel();
  JLabel jLblNome = new JLabel();
  JLabel jLblPontos = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JLabel jLabel20 = new JLabel();
  JLabel jLabel21 = new JLabel();
  JLabel jLabel22 = new JLabel();

  //Construct the frame
  public Frame1() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame1.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(305, 353));
    this.setTitle("Frame Title");
    jbtnOK.setText("OK");
    jLblNome.setHorizontalAlignment(SwingConstants.CENTER);
    jLblNome.setText("Nome");
    jLblPontos.setHorizontalAlignment(SwingConstants.CENTER);
    jLblPontos.setText("Pontos");
    jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel3.setText("-");
    jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel4.setText("-");
    jLabel5.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel5.setText("-");
    jLabel6.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel6.setText("-");
    jLabel7.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel7.setText("-");
    jLabel8.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel8.setText("-");
    jLabel9.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel9.setText("-");
    jLabel10.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel10.setText("-");
    jPanel2.setLayout(new GridLayout(11,2,0,0));
    jLabel11.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel11.setText("-");
    jLabel12.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel12.setText("-");
    jLabel13.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel13.setText("-");
    jLabel14.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel14.setText("-");
    jLabel15.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel15.setText("-");
    jLabel16.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel16.setText("-");
    jLabel17.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel17.setText("-");
    jLabel18.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel18.setText("-");
    jLabel19.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel19.setText("-");
    jLabel20.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel20.setText("-");
    jLabel21.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel21.setText("-");
    jLabel22.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel22.setText("-");
    contentPane.add(jPanel1,  BorderLayout.SOUTH);
    jPanel1.add(jbtnOK, null);
    contentPane.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jLblNome, null);
    jPanel2.add(jLblPontos, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(jLabel4, null);
    jPanel2.add(jLabel5, null);
    jPanel2.add(jLabel6, null);
    jPanel2.add(jLabel7, null);
    jPanel2.add(jLabel8, null);
    jPanel2.add(jLabel9, null);
    jPanel2.add(jLabel10, null);
    jPanel2.add(jLabel11, null);
    jPanel2.add(jLabel12, null);
    jPanel2.add(jLabel13, null);
    jPanel2.add(jLabel14, null);
    jPanel2.add(jLabel15, null);
    jPanel2.add(jLabel16, null);
    jPanel2.add(jLabel17, null);
    jPanel2.add(jLabel18, null);
    jPanel2.add(jLabel19, null);
    jPanel2.add(jLabel20, null);
    jPanel2.add(jLabel21, null);
    jPanel2.add(jLabel22, null);
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
}