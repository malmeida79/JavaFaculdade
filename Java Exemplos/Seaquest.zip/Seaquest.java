import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;

public class Seaquest extends JFrame implements KeyListener, ActionListener
{
	static int VARIACAO = 5;
	static int TAMANHO = 20;
	static int PONTOSAtaque = 30;
	static int PONTOSResgate =50;

	Thread t;
	JProgressBar progT;
	Cronometro cronometro;

	JLabel lcontaTiro, lmensTiro, lcontaOxig, lmensOxig, lmensPontos, lPontos;
	JLabel lvida, lrecuperou, lcontavida, lcontarecuperou;
	JPanel p, p1, p2;
	JButton b1, b2, b3, b4;

	AreaDesenho areaDesenho;
	Submarino submarino;
	LancaSubI lancaSubI;
	LancaAqua lancaAqua;
	AudioClip somInicio, somOxig15, somOxig10;
	AudioClip somExplosao, somMorte;
	int contaTiro, contaAcertos, pontos;

	public boolean tempoPara;

 	SubI[] itens;
 	Aqua[] gente;

	TiroSubI[] arrayTiro;

	Seaquest()
	{
		addWindowListener(new WindowAdapter() {public void windowClosing(WindowEvent e){System.exit(0);}});
		setSize(600,400);
		setTitle("Seaquest - Andr� Luiz Casetto");

		p  = new JPanel();
		p1 = new JPanel();
		p2 = new JPanel();

		lmensTiro = new JLabel("Tiros: ");
		lcontaTiro = new JLabel("0");
		lmensPontos = new JLabel("Pontos: ");
		lPontos = new JLabel("0");
		lmensOxig = new JLabel("Oxigenio: ");
		lcontaOxig = new JLabel("0");
		progT = new JProgressBar();
		lvida = new JLabel("Vidas: ");
		lrecuperou = new JLabel("Resgatou: ");
		lcontavida = new JLabel("0");
		lcontarecuperou = new JLabel("0");

		p1.add(lmensTiro);
		p1.add(lcontaTiro);
		p1.add(lmensPontos);
		p1.add(lPontos);
		p1.add(lmensOxig);
		p1.add(lcontaOxig);
		p1.add(progT);
		p1.add(lvida);
		p1.add(lcontavida);
		p1.add(lrecuperou);
		p1.add(lcontarecuperou);

		b3 = new JButton("Pontua��o");
		b4 = new JButton("Sair");
		b1 = new JButton("Novo Jogo");
		b2 = new JButton("Iniciar");
		p2.add(b3);
		p2.add(b1);
		p2.add(b2);
		p2.add(b4);

		p.setLayout(new GridLayout(2,2,0,0));
		p.add(p1);
		p.add(p2);
		getContentPane().add("South", p);
		areaDesenho = new AreaDesenho();
		areaDesenho.repaint();
		getContentPane().add("Center", areaDesenho);

		b2.setEnabled(false);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b4.addActionListener(this);
		b3.addActionListener(this);

		addKeyListener(this);
		lancaSubI = null;
		lancaAqua = null;

		itens = new SubI[TAMANHO];
		gente = new Aqua[TAMANHO];
		arrayTiro = new TiroSubI[TAMANHO];
		tempoPara=false;
//	Cronometro
	    t = null;
		progT.setForeground(Color.blue);



		try
		{
			somInicio = Applet.newAudioClip(new URL("file:" + System.getProperty("user.dir") + "/Startup.wav"));
			somOxig15 =Applet.newAudioClip(new URL("file:" + System.getProperty("user.dir") + "/radar.wav"));
			somOxig10 =Applet.newAudioClip(new URL("file:" + System.getProperty("user.dir") + "/Buzina.wav"));
		}
		catch (MalformedURLException eitcha)
		{
			System.out.println("Erro na abertura dos arquivos de som");
		}
//		if (somInicio != null)
//			somInicio.play();

	}

	public void actionPerformed(ActionEvent ae)
	{
		String qualBotao = ae.getActionCommand();

		if (qualBotao.equals("Sair"))
		{
			System.exit(0);
		}
		if(qualBotao.equals("Pontua��o"))
		{
			ListaPontos p = new ListaPontos();
			p.setVisible(true);
		}
		if (qualBotao.equals("Iniciar"))
		{
			submarino = new Submarino(areaDesenho);
			submarino.Zera_Posicoes();
			if (lancaSubI != null)
				lancaSubI.start();

			if (lancaAqua != null)
				lancaAqua.start();

			if(t==null)
			{
				tempoPara=false;
				t = new Thread(new Cronometro(this));
				t.start();
			}
			else
			{
				submarino.posicoes.setVertical(35);
				tempoPara=true;
			}
			progT.setMaximum(45);
			b1.setEnabled(true);
			b2.setEnabled(false);
			lcontavida.setText(String.valueOf(submarino.vida.getFim()-1));
			this.requestFocus();
		}
		this.requestFocus();
		if (qualBotao.equals("Novo Jogo"))
		{
			areaDesenho.repaint();
			submarino = new Submarino(areaDesenho);
			submarino.Zera_Posicoes();
			if (t != null) 
				Termina();
			lancaAqua = new LancaAqua(areaDesenho,this, gente);
			if (lancaAqua != null)
				lancaAqua.para();

			lancaSubI = new LancaSubI(areaDesenho,this, itens, arrayTiro);			
			if (lancaSubI != null)
				lancaSubI.para();

			contaTiro = 0;
			contaAcertos = 0;
			pontos = 0;
			lcontaTiro.setText(String.valueOf(contaTiro));
			lPontos.setText(String.valueOf(pontos));
			b1.setEnabled(false);
			b2.setEnabled(true);
			this.requestFocus();
		}
		this.requestFocus();
	}

	public void keyPressed(KeyEvent k)
	{
		if (k.getKeyCode() == KeyEvent.VK_LEFT)
		{
				submarino.Esquerda();
		}
		if (k.getKeyCode() == KeyEvent.VK_RIGHT)
		{
				submarino.Direita();
		}
		if (k.getKeyCode() == KeyEvent.VK_UP)
		{
				submarino.Sobe();
		}
		if (k.getKeyCode() == KeyEvent.VK_DOWN)
		{
				submarino.Desce();
		}
		if (k.getKeyCode() == KeyEvent.VK_NUMPAD0)
		{
				submarino.Atira(this);
		}
	}

	public void keyReleased(KeyEvent e)
	{
	}

	public void keyTyped(KeyEvent e)
	{
	}

	public static void main(String args[])
	{
		Seaquest S = new Seaquest();
		S.setVisible(true);
	}


//---------------- Pontua�ao  ------------------------------------------------\\
	public void atualizaAcertos(boolean foiPeixe)
	{
		if (foiPeixe)
		{
			pontos+=PONTOSAtaque;
		}
		else // foi resgate
		{
			pontos+=PONTOSResgate;
		}
//		lPontos.setText(String.valueOf(pontos));
		System.out.println("Pontos : "+String.valueOf(pontos));
	}
//---------------- Pontua�ao  ------------------------------------------------\\

//---------------- Cronometro ------------------------------------------------\\
	public void AtualizaLabel(int tempo)
	{
		lcontaOxig.setText(""+ tempo);
	 	progT.setValue(tempo);
		if((tempo < 1)||(tempo == 1)||(tempo == 0))
		{
			submarino.Explode();
		}
		if(tempo <= 10)
		{
			progT.setForeground(Color.yellow);
		}
		if(tempo <=5)
		{
			progT.setForeground(Color.red);
		}
		if(tempo >10)
			progT.setForeground(Color.blue);

		if((tempo == 5)&&(somOxig10 != null))
			   somOxig10.play();
		if((tempo == 10)&&(somOxig15 != null))
			   somOxig15.play();
//Atualiza Pontos
		lPontos.setText(""+submarino.mergulhadores.getFim()*50);
		lcontarecuperou.setText(""+submarino.mergulhadores.getFim());
		lcontavida.setText(""+submarino.vida.getFim());
		if(lcontavida.getText() != "0") 
		{
			System.out.println("+1");
		}

	}

	public void Termina()
	{
		tempoPara=true;
	}
}

//---------------- Cronometro ------------------------------------------------\\
class Cronometro extends Thread
{
	Seaquest seaquest;
	Tempo guardaTempo;
	int tempo;

	Cronometro(Seaquest seaquest)
	{
		this.seaquest = seaquest;
		guardaTempo = new Tempo(45);
	}

	public void run()
	{
		Contagem();
	}

	public void Contagem()
	{
		while ((guardaTempo.getTempo() >= 0)&&(seaquest.tempoPara==false)&&(seaquest.submarino.explodiu.getFim()==0))
		{
			guardaTempo.setTempo(guardaTempo.getTempo()-1);

			if(seaquest.submarino.posicoes.getVertical() == 35)
			{	guardaTempo.setTempo(45);		}

			seaquest.AtualizaLabel(guardaTempo.getTempo());
			try
			{
				Thread.sleep(1000);
			}
			catch (InterruptedException e){}
		}
//		if(seaquest.submarino.explodiu.getFim()==1)
		{
//			seaquest.submarino.Conta_Vida();
		}
	}
}