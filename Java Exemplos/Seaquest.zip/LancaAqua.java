import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;
import java.util.*;

class LancaAqua extends Thread
{
	static int FREQUENCIA = 9360;
	AreaDesenho areaDesenho;
	Seaquest seaquest;
	private boolean continua;
	Image imagemMergulador;

  	Aqua[] itens;

	LancaAqua (AreaDesenho areaDesenho, Seaquest seaquest, Aqua[] gente)
	{
		this.itens = gente;
		this.areaDesenho = areaDesenho;
		this.seaquest = seaquest;

		imagemMergulador = Toolkit.getDefaultToolkit().getImage("Aqua.gif");

		continua = true;	
  }

	public void para()
	{
		continua = false;
	}
	
	public int devolveIndice()
	{
		int i = 0, indiceRetorno = 0;
		boolean achou = false;
		while ((i < 20)&& (!achou))
		{
			if (itens[i] == null)
			{
				achou = true;
				indiceRetorno = i;
			}
			else
			  i++;
		}
		return(indiceRetorno);
	}

	public void run()
	{
		int indice = 0;
		while ((continua)||(seaquest.submarino.explodiu.getFim()!=1))
		{
			indice = devolveIndice();
			if (Math.random() > 0.5)
			{
			    itens[indice] = new Aqua(seaquest, imagemMergulador, areaDesenho, true, indice, itens);
  			}
			else
			{
		        itens[indice] = new Aqua(seaquest, imagemMergulador, areaDesenho, false, indice, itens);
			}			
			try
			{
				int tempo = (int) Math.floor(Math.random() * FREQUENCIA);
				Thread.sleep(tempo);
				if((tempo > 900)&&(seaquest.submarino.explodiu.getFim()!=1)) //para nao sobrepor um desenho no outro
  				itens[indice].start();
			}
			catch (InterruptedException ie)	{}
		}
	}
}