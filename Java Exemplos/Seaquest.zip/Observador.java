import java.awt.*;
import java.awt.image.*;

class Observador implements ImageObserver
{
	public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height)
	{
		return true;
	}
}