/**
 * <p>File: MenuFrame.java
 * <p>Title: Exerc�cios 4� Per�odo - Linguagem III - Jeveaux</p>
 * <p>Description: Exerc�cios 4� Per�odo - Linguagem III - Jeveaux</p>
 * <p>Copyright: Copyright (c) 2002-2003</p>
 * <p>Company: JavaSoft Team</p>
 * @author Paulo C�sar Machado Jeveaux
 * @version 1.1
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.text.*;


public class MenuFrame extends JFrame implements ActionListener, MouseListener, MouseMotionListener {
	JMenu menu;
	JMenuItem exemp = new JMenuItem("JInternalFrame 01");
//########################################### Vari�veis do JPopupMenu	
	JPopupMenu popup = new JPopupMenu();
	String[] nomePopup = {"JInternalFrame 01","Sair"};
	JMenuItem[] menuPopup = new JMenuItem[2];
//###############################################################################
	
	Color color = new Color(29,140,194);
//###################################Bot�es com os icones
	JButton botaoSair = new JButton("A");
	static JButton botaoBackup = new JButton("B");
	static JButton botaoNovo = new JButton("C");
	
//###################################Bot�es com os icones

//################################### Icones do programa - Est�o seperados para melhor identifica��o


    Container c;
    static JMenuBar menuBar;
    JDesktopPane desktop = new JDesktopPane();

    static final Integer DOCLAYER = new Integer(5);
    static final Integer TOOLLAYER = new Integer(6);
    static final Integer HELPLAYER = new Integer(7);

    public MenuFrame() {
        super("Jeveaux");
        final int inset = 60;
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds ( inset, inset, screenSize.width - inset*2, screenSize.height - inset*2 );
		buildContent();
		buildMenus();
		this.addWindowListener(new WindowAdapter() {
	                       public void windowClosing(WindowEvent e) {
				   quit();
			       }});
		System.out.println("Iniciando Menu Principal");
		show();
	}

    protected void buildMenus() {
        menuBar = new JMenuBar();
		menuBar.setOpaque(true);
		menu = buildFileMenu(); 
		menuBar.add(menu);
		setJMenuBar(menuBar);

		builPopup();
    }

	public void builPopup() {
		for(int i=0; i<2; i++) {
			menuPopup[i] = new JMenuItem(nomePopup[i]);
			if(i == 1)
				popup.addSeparator();
			popup.add(menuPopup[i]);
			menuPopup[i].addActionListener(this);
		}
	}    
    

    protected JMenu buildFileMenu() {

		menu = new JMenu("Exemplo");
		menu.addActionListener(this);
		menu.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); //Mudar cursor
	
		exemp.addActionListener(new ActionListener() {
	    	                   public void actionPerformed(ActionEvent e) {
					   openWindow();
			    	   }});

		menu.add(exemp);
		return menu;
	
    }

    protected void buildContent() {  //@#$@#$@#$ DESKTOP @#$@#$@#$@#$
        desktop.addMouseListener(this);
        desktop.addMouseMotionListener(this);
        getContentPane().add(desktop);
        desktop.setBackground(color); //FUNDO
    }

    public void quit() {
		int result = JOptionPane.showConfirmDialog(null,"Deseja realmente Sair ?", "Sair do Programa ?", JOptionPane.WARNING_MESSAGE);
		if (result == JOptionPane.YES_OPTION) {
			System.out.println("Fechando Menu Principal");		
			System.exit(0);
		}
    }


//##############################################################################################
//                 M�TODOS QUE ABREM UM JINTERNALFRAME NO DESKTOP
//##############################################################################################
    public void openWindow() { //Abre a janela de ajuda
		JInternalFrame internal1 = new sobre();
		desktop.add(internal1, HELPLAYER);
		try { 
	    	internal1.setVisible(true);
	    	internal1.setSelected(true); 
		}
		catch (java.beans.PropertyVetoException e2) {}
    }


    public void actionPerformed(ActionEvent e) {
    	if(e.getSource() == menuPopup[0])
    		openWindow();
    	if(e.getSource() == menuPopup[1])
    		quit();
    		
    	if(e.getSource() == botaoSair)
    		quit();
    }	

	public void mouseClicked(MouseEvent e) {
	}

//%%%%%%%%%%%%%%%%%%%%%% M�TODO QUE FAZ O POPUP APARECER %%%%%%%%%%%%%%%%%%%%%%
	private void checkForTriggerEvent(MouseEvent e) {
		if(e.isPopupTrigger())
			popup.show(e.getComponent(), e.getX(), e.getY());
	}
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	

   	public void mouseReleased(MouseEvent e) {
		if(e.getSource() == desktop) { //Teste para fazer popup
			checkForTriggerEvent(e);	
		}
   	}

	public void mouseEntered(MouseEvent e) {
	}
		
	public void mouseExited(MouseEvent e) {
	}
	public void mousePressed(MouseEvent e) {
		if(e.getSource() == desktop) { //Teste para fazer o popup
			checkForTriggerEvent(e);	
		}		
	}
	public void mouseDragged(MouseEvent e) {}
	public void mouseMoved(MouseEvent e) {
	}
	
	public static void main(String[] args) {
		new MenuFrame();	
	}


} //FIM DA CLASSE PRINCIPAL -- MENUFRAME.JAVA