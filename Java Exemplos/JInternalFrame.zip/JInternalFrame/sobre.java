//file sobre.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.io.*;

public class sobre extends JInternalFrame implements ActionListener {

	JPanel p = new JPanel();
	
	static final int offset = 25;
	static int frameCount = 1;
	
	JButton botaoOk = new JButton("OK");

	public sobre() {
		super("Exemplo 1",false,true,false,false); //Botoes da janela	
		setBounds(offset * frameCount, offset * frameCount, 420, 370);
		frameCount++;
		setBackground(Color.white);
		
		montaTela();
	}
	
	public void montaTela() {
		botaoOk.setBounds(310,300,80,20);
		botaoOk.addActionListener(this);
		getContentPane().add(botaoOk, null);

		p.setBackground(Color.white);
		getContentPane().add(p);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == botaoOk)
			this.setVisible(false);
	}
}