import javax.swing.*;
import java.awt.*;
public class Proxima extends JPanel{
 public static final int TIPOS = 7, MAX = 4;
 private static Quadrado quadrados[][] = new Quadrado[TIPOS][MAX];
 public static void init(){
  if (TIPOS != Peca.TIPOS) throw new RuntimeException("Problema com a pre-visualizacao das pecas");
  quadrados[0][0] = new Quadrado(1, 1, 0);
  quadrados[0][1] = new Quadrado(2, 1, 0);
  quadrados[0][2] = new Quadrado(2, 2, 0);
  quadrados[0][3] = new Quadrado(3, 2, 0);
  quadrados[1][0] = new Quadrado(3, 1, 1);
  quadrados[1][1] = new Quadrado(2, 1, 1);
  quadrados[1][2] = new Quadrado(2, 2, 1);
  quadrados[1][3] = new Quadrado(1, 2, 1);
  quadrados[2][0] = new Quadrado(1, 1, 2);
  quadrados[2][1] = new Quadrado(2, 1, 2);
  quadrados[2][2] = new Quadrado(3, 1, 2);
  quadrados[2][3] = new Quadrado(3, 2, 2);
  quadrados[3][0] = new Quadrado(1, 1, 3);
  quadrados[3][1] = new Quadrado(2, 1, 3);
  quadrados[3][2] = new Quadrado(3, 1, 3);
  quadrados[3][3] = new Quadrado(1, 2, 3);
  quadrados[4][0] = new Quadrado(1, 1, 4);
  quadrados[4][1] = new Quadrado(2, 1, 4);
  quadrados[4][2] = new Quadrado(3, 1, 4);
  quadrados[4][3] = new Quadrado(2, 2, 4);
  quadrados[5][0] = new Quadrado(1, 1, 5);
  quadrados[5][1] = new Quadrado(2, 1, 5);
  quadrados[5][2] = new Quadrado(1, 2, 5);
  quadrados[5][3] = new Quadrado(2, 2, 5);
  quadrados[6][0] = new Quadrado(0, 2, 6);
  quadrados[6][1] = new Quadrado(1, 2, 6);
  quadrados[6][2] = new Quadrado(2, 2, 6);
  quadrados[6][3] = new Quadrado(3, 2, 6);
 }
 public void paintComponent(Graphics g){
  super.paintComponent(g);
  g.setColor(Color.black);
  g.fillRect(0, 0, Quadrado.TAMANHOX * TIPOS, Quadrado.TAMANHOY * TIPOS);
  for (int i = 0; i < MAX; i++){
   if (quadrados[Jogo.proxima][i] != null) quadrados[Jogo.proxima][i].desenha(g);
  }
  g.setColor(Color.lightGray);
  for (int i = 1; i <= MAX - 1; i++){
   g.drawLine(0, i * Quadrado.TAMANHOY, MAX * Quadrado.TAMANHOX, i * Quadrado.TAMANHOY);
  }
  for (int i = 1; i <= MAX - 1; i++){
   g.drawLine(i * Quadrado.TAMANHOX, 0, i * Quadrado.TAMANHOX, MAX * Quadrado.TAMANHOY);
  }
 }
}