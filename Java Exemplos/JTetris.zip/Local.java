import java.util.*;
public class Local{
 private ArrayList quadrados;
 private int posX, posY;
 public static final int TAMANHOX = 5, TAMANHOY = 5;
 public Local(int x, int y){
  quadrados = new ArrayList();
  posX = x;
  posY = y;
 }
 public void addQuadrado(Quadrado q){
  quadrados.add(q);
 }
 public void limpa(){
  quadrados = new ArrayList();
 }
 public Quadrado[] getQuadrados(){
  Object aux[] = quadrados.toArray();
  Quadrado q[] = new Quadrado[aux.length];
  for (int i = 0; i < q.length; i++){
   q[i] = (Quadrado)aux[i];
  }
  return q;
 }
 public Quadrado getQuadrado(int x, int y){
  Quadrado q;
  for (int i = 0; i < quadrados.size(); i++){
   q = (Quadrado)quadrados.get(i);
   if (q.getX() == x && q.getY() == y) return q;
  }
  return null;
 }
 public boolean isFileraCompleta(int y){
  for (int i = posX; i < posX + 5; i++){
   if (getQuadrado(i, y) == null) return false;
  }
  return true;
 }
 public void removeQuadrado(Quadrado q){
  for (int i = 0; i < quadrados.size(); i++){
   if (quadrados.get(i) == q){
    quadrados.remove(i);
    return;
   }
  }
 }
}