public class Movimento extends Thread{
 public void run(){
  Peca p;
  do{
   Jogo.nextPeca();
   while (Jogo.peca.move(Peca.DESCE)){
    try{
     if (JTetris.desceRapido && Jogo.continua) Thread.sleep(25);
     else if (JTetris.level >= 5 && Jogo.continua) Thread.sleep(1000 / JTetris.level);
     else{
      for (int i = 0; i < 20 && !JTetris.desceRapido&& Jogo.continua; i++) Thread.sleep((1000 - JTetris.level * 200) / 20);
     }
     while (Jogo.pausado) Thread.sleep(500);
    }
    catch (Exception erro){}
   }
  }while (Jogo.continua);
  JTetris.tetris.repaint();
 }
}