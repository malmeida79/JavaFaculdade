import java.awt.*;
public class Quadrado{
 private int posX, posY;
 private Color cor;
 private static Color CORES[];
 private Local local;
 private boolean taNaPeca = true;
 public static final int TAMANHOX = 30, TAMANHOY = 30;
 public Quadrado(int x, int y){
  posX = x;
  posY = y;
  cor = CORES[(int)(Math.random() * CORES.length)];
  mudaLocal();
 }
 public Quadrado(int x, int y, int c){
  posX = x;
  posY = y;
  cor = CORES[c];
  mudaLocal();
 }
 public Quadrado(int x, int y, Color c){
  posX = x;
  posY = y;
  cor = c;
  mudaLocal();
 }
 public static void init(){
  CORES = new Color[7];
  CORES[0] = Color.blue;
  CORES[1] = Color.yellow;
  CORES[2] = Color.red;
  CORES[3] = Color.gray;
  CORES[4] = Color.white;
  CORES[5] = Color.green;
  CORES[6] = Color.orange;
 }
 private void mudaLocal(){
  Local l = Jogo.getLocal(posX, posY);
  if (local != l){
   if (local != null) local.removeQuadrado(this);
   l.addQuadrado(this);
   local = l;
  }
 }
 public void desenha(Graphics g){
  if (posY < 0) return;
  g.setColor(cor);
  g.fillRect(posX * TAMANHOX, posY * TAMANHOY, TAMANHOX, TAMANHOY);
 }
 public void brilha(Graphics g){
  if (posY < 0) return;
  g.setColor(new Color(255, 255, 55));
  g.fillRect(posX * TAMANHOX, posY * TAMANHOY, TAMANHOX, TAMANHOY);
 }
 public Color getColor(){
  return cor;
 }
 public int getColorNum(){
  for (int i = 0; i < CORES.length; i++){
   if (cor == CORES[i]) return i;
  }
  return -1;
 }
 public int getNumColors(){
  return CORES.length;
 }
 public Point getPos(){
  return new Point(posX, posY);
 }
 public int getX(){
  return posX;
 }
 public int getY(){
  return posY;
 }
 public void setColor(Color c){
  cor = c;
 }
 public void setColor(int c){
  cor = CORES[c];
 }
 public void setPos(int x, int y){
  posX = x;
  posY = y;
  mudaLocal();
 }
 public void setPos(Point p){
  posX = p.x;
  posY = p.y;
  mudaLocal();
 }
 public void setX(int x){
  posX = x;
  mudaLocal();
 }
 public void setY(int y){
  posY = y;
  mudaLocal();
 }
 public void saiDaPeca(){
  taNaPeca = false;
 }
 public boolean taNaPeca(){
  return taNaPeca;
 }
}