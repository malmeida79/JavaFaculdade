import javax.swing.*;
import java.awt.*;
import java.util.*;
public class Jogo extends JPanel{
 public static final int TAMANHOX = 10, TAMANHOY = 20;
 public static Local locais[][] = new Local[TAMANHOX / Local.TAMANHOX][TAMANHOY / Local.TAMANHOY];;
 public static boolean continua, mostraBrilho, pausado;
 public static Peca peca;
 public static ArrayList brilha;
 public static int proxima;
 public Jogo(){
  for (int i = 0; i < locais.length; i++){
   for (int j = 0; j < locais[0].length; j++){
    locais[i][j] = new Local(i * Local.TAMANHOX, j * Local.TAMANHOY);
   }
  }
  brilha = new ArrayList();
  mostraBrilho = false;
  continua = true;
  pausado = false;
  proxima = (int)(Math.random() * Peca.TIPOS);
 }
 public void inicia(){
  brilha = new ArrayList();
  mostraBrilho = false;
  JTetris.level = 0;
  JTetris.pontos = 0;
  JTetris.proximoLevel = 5;
  JTetris.pontosLabel.setText("0");
  JTetris.levelLabel.setText("0");
  JTetris.fileirasLabel.setText("0");
  continua = true;
  pausado = false;
  JTetris.terminaMenu();
  for (int i = 0; i < locais.length; i++){
   for (int j = 0; j < locais[0].length; j++){
    locais[i][j].limpa();
   }
  }
  new Movimento().start();
 }
 public void inicia(int sl, int sq){
  int b1, b2;
  inicia();
  JTetris.level = sl;
  JTetris.levelLabel.setText(sl + "");
  JTetris.proximoLevel = 5 + sl * 2;
  for (int j = 19; j > 19 - sq; j--){
   b1 = (int)(Math.random() * 10);
   b2 = (int)(Math.random() * 10);
   for (int i = 0; i < 10; i++){
    if (i == b1 || i == b2) continue;
    new Quadrado(i, j, (int)(Math.random() * Peca.TIPOS));
   }
  }
 }
 public static void nextPeca(){
  Quadrado q[];
  for (int l = 0; l < locais.length; l++){
   q = locais[l][0].getQuadrados();
   for (int i = 0; i < q.length; i++){
    if (q[i].getY() < 0){
     continua = false;
     JTetris.rank.add(JTetris.nome, JTetris.pontos);
     return;
    }
   }
  }
  (new Thread(){public void run(){veCompletas();}}).start();
  peca = new Peca(proxima);
  proxima = (int)(Math.random() * Peca.TIPOS);
  System.gc();
 }
 public static void veCompletas(){
  boolean completa = true;
  final int TEMPO = 100;
  Quadrado q[];
  int y;
  for (int j = 0; j < TAMANHOY; j++){
   for (int i = 0; i < locais.length && completa; i++){
    if (!locais[i][j / Local.TAMANHOY].isFileraCompleta(j)) completa = false;
   }
   if (completa){
    brilha.add(new Integer(j));
   }
   completa = true;
  }
  if (brilha.size() == 0) return;
  JTetris.fileiras += brilha.size();
  JTetris.proximoLevel -= brilha.size();
  while (JTetris.proximoLevel <= 0){
   JTetris.level++;
   JTetris.proximoLevel += 5 + 2 * JTetris.level;
  }
  JTetris.levelLabel.setText(JTetris.level + "");
  JTetris.fileirasLabel.setText(JTetris.fileiras + "");
  JTetris.pontos += 100L * (long)Math.pow(2, brilha.size() - 1) * (long)Math.pow(2, JTetris.level);
  JTetris.pontosLabel.setText(JTetris.pontos + "");
  mostraBrilho = true;
  JTetris.tetris.repaint();
  try{
   Thread.sleep(TEMPO);
   for (int i = 0; i < brilha.size(); i++){
    y = ((Integer)brilha.get(i)).intValue();
    for (int x = 0; x < locais.length; x++){
     q = locais[x][y / Local.TAMANHOY].getQuadrados();
     for (int k = 0; k < q.length; k++){
      if (q[k].getY() == y) locais[x][y / Local.TAMANHOY].removeQuadrado(q[k]);
     }
    }
   }
   mostraBrilho = false;
   JTetris.tetris.repaint();
   Thread.sleep(TEMPO);
   for (int i = 0; i < brilha.size(); i++){
    y = ((Integer)brilha.get(i)).intValue();
    for (int j = y - 1; j >= 0; j--){
     for (int x = 0; x < locais.length; x++){
      q = locais[x][j / Local.TAMANHOY].getQuadrados();
      for (int k = 0; k < q.length; k++){
       if (q[k].getY() == j && !q[k].taNaPeca()) q[k].setPos(q[k].getX(), j + 1);
      }
     }
    }
   }
   brilha = new ArrayList();
   JTetris.tetris.repaint();
  }
  catch (Exception erro){}
 }
 public Dimension getPreferedSize(){
  return new Dimension(Quadrado.TAMANHOX * TAMANHOX, Quadrado.TAMANHOY * TAMANHOY);
 }
 public static Local getLocal(int x, int y){
  return locais[x / Local.TAMANHOX][y / Local.TAMANHOY];
 }
 public void paintComponent(Graphics g){
  super.paintComponent(g);
  g.setColor(Color.black);
  g.fillRect(0, 0, TAMANHOX * Quadrado.TAMANHOX, TAMANHOY * Quadrado.TAMANHOY);
  if (!pausado){
   Quadrado q[];
   for (int i = 0; i < locais.length; i++){
    for (int j = 0; j < locais[0].length; j++){
     q = locais[i][j].getQuadrados();
     for (int k = 0; k < q.length; k++){
      q[k].desenha(g);
     }
    }
   }
   if (mostraBrilho){
    int y;
    for (int j = 0; j < brilha.size(); j++){
     y = ((Integer)brilha.get(j)).intValue();
     for (int i = 0; i < locais.length; i++){
      q = locais[i][y / Local.TAMANHOY].getQuadrados();
      for (int k = 0; k < q.length; k++){
       if (q[k].getY() == y) q[k].brilha(g);
      }
     }
    }
   }
  }
  else{
   g.setColor(Color.white);
   g.setFont(new Font("Arial", Font.BOLD, 20));
   g.drawString("Pausado", TAMANHOX * Quadrado.TAMANHOX / 3, TAMANHOY * Quadrado.TAMANHOY / 2);
  }
  g.setColor(Color.lightGray);
  for (int i = 1; i <= TAMANHOY - 1; i++){
   g.drawLine(0, i * Quadrado.TAMANHOY, TAMANHOX * Quadrado.TAMANHOX, i * Quadrado.TAMANHOY);
  }
  for (int i = 1; i <= TAMANHOX - 1; i++){
   g.drawLine(i * Quadrado.TAMANHOX, 0, i * Quadrado.TAMANHOX, TAMANHOY * Quadrado.TAMANHOY);
  }
  if (!continua){
   g.setColor(Color.white);
   g.setFont(new Font("Arial", Font.BOLD, 20));
   g.drawString("Game Over", TAMANHOX * Quadrado.TAMANHOX / 3, TAMANHOY * Quadrado.TAMANHOY / 2);
  }
 }
}