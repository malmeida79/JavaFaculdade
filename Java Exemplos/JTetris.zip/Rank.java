import javax.swing.*;
import java.io.*;
public class Rank extends JPanel{
 public static final int NUMERO = 10;
 private static Dados dados;
 private JLabel label[][] = new JLabel[NUMERO + 1][3];
 public Rank(){
  dados = abre();
  carrega();
 }
 public void carrega(){
  setLayout(null);
  removeAll();
  for (int i = 0; i < NUMERO; i++){
   label[i][0] = new JLabel((i + 1) + "");
   label[i][0].setSize(20, 20);
   label[i][0].setLocation(30, i * 30 + 30);
   add(label[i][0]);
   label[i][1] = new JLabel(dados.nomes[i]);
   label[i][1].setSize(100, 20);
   label[i][1].setLocation(60, i * 30 + 30);
   add(label[i][1]);
   label[i][2] = new JLabel(dados.pontos[i] + "");
   label[i][2].setSize(60, 20);
   label[i][2].setLocation(170, i * 30 + 30);
   add(label[i][2]);
  }
 }
 public Dados abre(){
  File arq = new File("rank.dat");
  ObjectInputStream in = null;
  if (!arq.exists()){
   return new Dados();
  }
  try{
   in = new ObjectInputStream(new FileInputStream(arq));
   return (Dados)in.readObject();
  }
  catch (Exception erro){
   JOptionPane.showMessageDialog(null, erro, "ERRO!", JOptionPane.ERROR_MESSAGE);
  }
  return new Dados();
 }
 public void salva(){
  File arq = new File("rank.dat");
  ObjectOutputStream out = null;
  try{
   out = new ObjectOutputStream(new FileOutputStream(arq));
   out.writeObject(dados);
  }
  catch (Exception erro){
   JOptionPane.showMessageDialog(null, erro, "ERRO!", JOptionPane.ERROR_MESSAGE);
  }
 }
 public void add(String n, long p){
  dados.nomes[NUMERO] = n;
  dados.pontos[NUMERO] = p;
  quicksort(0, NUMERO);
  salva();
  carrega();
 }
 public void quicksort(int p, int q){
  if (p < q){
   int x = particao(p, q);
   quicksort(p, x - 1);
   quicksort(x + 1, q);
  }
 }
 private int particao(int p, int q){
  int j = p - 1;
  long aux = dados.pontos[q];
  for (int i = p; i <= q; i++){
   if (dados.pontos[i] >= aux) troca(i, ++j);
  }
  return j;
 }
 private void troca(int x, int y){
  long auxl = dados.pontos[x];
  dados.pontos[x] = dados.pontos[y];
  dados.pontos[y] = auxl;
  String auxs = dados.nomes[x];
  dados.nomes[x] = dados.nomes[y];
  dados.nomes[y] = auxs;
 }
}
class Dados implements Serializable{
 String nomes[] = new String[Rank.NUMERO + 1];
 long pontos[] = new long[Rank.NUMERO + 1];
}