import javax.swing.*;
import java.awt.*;
public class Menu extends JPanel{
 public static final int OPCOES = 4;
 public void paintComponent(Graphics g){
  super.paintComponent(g);
  int x1 = Jogo.TAMANHOX * Quadrado.TAMANHOX / 7, x2 = x1 * 5;
  g.setColor(Color.black);
  g.fillRect(0, 0, Jogo.TAMANHOX * Quadrado.TAMANHOX, Jogo.TAMANHOY * Quadrado.TAMANHOY);
  g.setColor(Color.white);
  g.setFont(new Font("Arial", Font.BOLD, 20));
  if (JTetris.menuSelect == 0) g.setColor(Color.red);
  else g.setColor(Color.white);
  g.drawString("Novo Jogo", (x1 + x2) / 2, 100);
  if (JTetris.menuSelect == 1) g.setColor(Color.red);
  else g.setColor(Color.white);
  g.drawString("Nome", x1, 130);
  g.drawString(JTetris.nome, x2, 130);
  if (JTetris.menuSelect == 2) g.setColor(Color.red);
  else g.setColor(Color.white);
  g.drawString("Level inicial", x1, 160);
  g.drawString(JTetris.level + "", x2, 160);
  if (JTetris.menuSelect == 3) g.setColor(Color.red);
  else g.setColor(Color.white);
  g.drawString("Fileiras iniciais", x1, 190);
  g.drawString(JTetris.fileiras + "", x2, 190);
 }
}