public class Peca{
 private Quadrado quadrados[];
 private int tipo, posicao;
 public static final int DESCE = 0, DIREITA = 1, ESQUERDA = 2, RODA = 3, TIPOS = 7;
 public Peca(int t){
  tipo = t;
  if (tipo == 0){
   quadrados = new Quadrado[4];
   quadrados[0] = new Quadrado(3, -2);
   quadrados[1] = new Quadrado(4, -2);
   quadrados[2] = new Quadrado(4, -1);
   quadrados[3] = new Quadrado(5, -1);
  }
  else if (tipo == 1){
   quadrados = new Quadrado[4];
   quadrados[0] = new Quadrado(5, -2);
   quadrados[1] = new Quadrado(4, -2);
   quadrados[2] = new Quadrado(4, -1);
   quadrados[3] = new Quadrado(3, -1);
  }
  else if (tipo == 2){
   quadrados = new Quadrado[4];
   quadrados[0] = new Quadrado(3, -2);
   quadrados[1] = new Quadrado(4, -2);
   quadrados[2] = new Quadrado(5, -2);
   quadrados[3] = new Quadrado(5, -1);
  }
  else if (tipo == 3){
   quadrados = new Quadrado[4];
   quadrados[0] = new Quadrado(3, -2);
   quadrados[1] = new Quadrado(4, -2);
   quadrados[2] = new Quadrado(5, -2);
   quadrados[3] = new Quadrado(3, -1);
  }
  else if (tipo == 4){
   quadrados = new Quadrado[4];
   quadrados[0] = new Quadrado(3, -2);
   quadrados[1] = new Quadrado(4, -2);
   quadrados[2] = new Quadrado(5, -2);
   quadrados[3] = new Quadrado(4, -1);
  }
  else if (tipo == 5){
   quadrados = new Quadrado[4];
   quadrados[0] = new Quadrado(4, -2);
   quadrados[1] = new Quadrado(5, -2);
   quadrados[2] = new Quadrado(4, -1);
   quadrados[3] = new Quadrado(5, -1);
  }
  else if (tipo == 6){
   quadrados = new Quadrado[4];
   quadrados[0] = new Quadrado(3, -1);
   quadrados[1] = new Quadrado(4, -1);
   quadrados[2] = new Quadrado(5, -1);
   quadrados[3] = new Quadrado(6, -1);
  }
  for (int i = 0; i < quadrados.length; i++) quadrados[i].setColor(tipo);
  posicao = 0;
 }
 public synchronized boolean move(int d){
  if (d == DESCE){
   if (desce()) return true;
   for (int i = 0; i < quadrados.length; i++){
    quadrados[i].saiDaPeca();
   }
   return false;
  }
  if (d == RODA) return roda();
  if (d == DIREITA) return direita();
  return esquerda();
 }
 private boolean desce(){
  int x, y;
  Quadrado q;
  boolean p;
  for (int i = 0; i < quadrados.length; i++){
   x = quadrados[i].getX();
   y = quadrados[i].getY() + 1;
   p = false;
   if (x < 0 || x >= 10 || y >= 20) return false;
   q = Jogo.getLocal(x, y).getQuadrado(x, y);
   for (int j = 0; j < quadrados.length; j++) if (q == quadrados[j]) p = true;
   if (Jogo.getLocal(x, y).getQuadrado(x, y) != null && !p) return false;
  }
  for (int i = 0; i < quadrados.length; i++){
   x = quadrados[i].getX();
   y = quadrados[i].getY() + 1;
   quadrados[i].setPos(x, y);
  }
  JTetris.tetris.repaint();
  return true;
 }
 private boolean direita(){
  int x, y;
  Quadrado q;
  boolean p;
  for (int i = 0; i < quadrados.length; i++){
   x = quadrados[i].getX() + 1;
   y = quadrados[i].getY();
   p = false;
   if (x < 0 || x >= 10 || y >= 20) return false;
   q = Jogo.getLocal(x, y).getQuadrado(x, y);
   for (int j = 0; j < quadrados.length; j++) if (q == quadrados[j]) p = true;
   if (Jogo.getLocal(x, y).getQuadrado(x, y) != null && !p) return false;
  }
  for (int i = 0; i < quadrados.length; i++){
   x = quadrados[i].getX() + 1;
   y = quadrados[i].getY();
   quadrados[i].setPos(x, y);
  }
  return true;
 }
 private boolean esquerda(){
  int x, y;
  Quadrado q;
  boolean p;
  for (int i = 0; i < quadrados.length; i++){
   x = quadrados[i].getX() - 1;
   y = quadrados[i].getY();
   p = false;
   if (x < 0 || x >= 10 || y >= 20) return false;
   q = Jogo.getLocal(x, y).getQuadrado(x, y);
   for (int j = 0; j < quadrados.length; j++) if (q == quadrados[j]) p = true;
   if (Jogo.getLocal(x, y).getQuadrado(x, y) != null && !p) return false;
  }
  for (int i = 0; i < quadrados.length; i++){
   x = quadrados[i].getX() - 1;
   y = quadrados[i].getY();
   quadrados[i].setPos(x, y);
  }
  return true;
 }
 private boolean roda(){
  if (tipo == 5) return true;
  if (tipo == 0){
   int x1, x2, y1, y2;
   if (posicao == 0){
    x1 = quadrados[2].getX() - 1;
    y1 = quadrados[2].getY();
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[3].getX() - 1;
    y2 = quadrados[3].getY() - 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[2].setPos(x1, y1);
    quadrados[3].setPos(x2, y2);
    posicao++;
   }
   else{
    x1 = quadrados[2].getX() + 1;
    y1 = quadrados[2].getY();
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[3].getX() + 1;
    y2 = quadrados[3].getY() + 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[2].setPos(x1, y1);
    quadrados[3].setPos(x2, y2);
    posicao--;
   }
  }
  else if (tipo == 1){
   int x1, x2, y1, y2;
   if (posicao == 0){
    x1 = quadrados[2].getX() + 1;
    y1 = quadrados[2].getY();
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[3].getX() + 1;
    y2 = quadrados[3].getY() - 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[2].setPos(x1, y1);
    quadrados[3].setPos(x2, y2);
    posicao++;
   }
   else{
    x1 = quadrados[2].getX() - 1;
    y1 = quadrados[2].getY();
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[3].getX() - 1;
    y2 = quadrados[3].getY() + 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[2].setPos(x1, y1);
    quadrados[3].setPos(x2, y2);
    posicao--;
   }
  }
  else if (tipo == 2){
   int x1, x2, y1, y2;
   if (posicao == 0){
    x1 = quadrados[0].getX() + 2;
    y1 = quadrados[0].getY() + 2;
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[1].getX() + 2;
    y2 = quadrados[1].getY();
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[0].setPos(x1, y1);
    quadrados[1].setPos(x2, y2);
    posicao++;
   }
   else if (posicao == 1){
    x1 = quadrados[0].getX() + 2;
    y1 = quadrados[0].getY() - 2;
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[3].getX();
    y2 = quadrados[3].getY() - 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[0].setPos(x1, y1);
    quadrados[3].setPos(x2, y2);
    posicao++;
   }
   else if (posicao == 2){
    x1 = quadrados[0].getX() - 2;
    y1 = quadrados[0].getY() - 2;
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[1].getX() - 2;
    y2 = quadrados[1].getY();
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[0].setPos(x1, y1);
    quadrados[1].setPos(x2, y2);
    posicao++;
   }
   else{
    x1 = quadrados[0].getX() - 2;
    y1 = quadrados[0].getY() + 2;
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[3].getX();
    y2 = quadrados[3].getY() + 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[0].setPos(x1, y1);
    quadrados[3].setPos(x2, y2);
    posicao = 0;
   }
  }
  else if (tipo == 3){
   int x1, x2, y1, y2;
   if (posicao == 0){
    x1 = quadrados[2].getX() - 2;
    y1 = quadrados[2].getY() - 2;
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[3].getX();
    y2 = quadrados[3].getY() - 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x2, y2) != null) return false;
    quadrados[2].setPos(x1, y1);
    quadrados[3].setPos(x2, y2);
    posicao++;
   }
   else if (posicao == 1){
    x1 = quadrados[1].getX() - 2;
    y1 = quadrados[1].getY();
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[2].getX() - 2;
    y2 = quadrados[2].getY() + 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[1].setPos(x1, y1);
    quadrados[2].setPos(x2, y2);
    posicao++;
   }
   else if (posicao == 2){
    x1 = quadrados[2].getX() + 2;
    y1 = quadrados[2].getY() + 2;
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[3].getX();
    y2 = quadrados[3].getY() + 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[2].setPos(x1, y1);
    quadrados[3].setPos(x2, y2);
    posicao++;
   }
   else{
    x1 = quadrados[1].getX() + 2;
    y1 = quadrados[1].getY();
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[2].getX() + 2;
    y2 = quadrados[2].getY() - 2;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    quadrados[1].setPos(x1, y1);
    quadrados[2].setPos(x2, y2);
    posicao = 0;
   }
  }
  else if (tipo == 4){
   int x, y;
   if (posicao == 0){
    x = quadrados[0].getX() + 1;
    y = quadrados[0].getY() - 1;
    if (x < 0 || x >= 10 || y >= 20) return false;
    if (Jogo.getLocal(x, y).getQuadrado(x, y) != null) return false;
    quadrados[0].setPos(x, y);
    posicao++;
   }
   else if (posicao == 1){
    x = quadrados[3].getX() - 1;
    y = quadrados[3].getY() - 1;
    if (x < 0 || x >= 10 || y >= 20) return false;
    if (Jogo.getLocal(x, y).getQuadrado(x, y) != null) return false;
    quadrados[3].setPos(x, y);
    posicao++;
   }
   else if (posicao == 2){
    x = quadrados[2].getX() - 1;
    y = quadrados[2].getY() + 1;
    if (x < 0 || x >= 10 || y >= 20) return false;
    if (Jogo.getLocal(x, y).getQuadrado(x, y) != null) return false;
    quadrados[2].setPos(x, y);
    posicao++;
   }
   else if (posicao == 3){
    int x1, y1, x2, y2;
    x = quadrados[2].getX() + 1;
    y = quadrados[2].getY() - 1;
    if (x < 0 || x >= 10 || y >= 20) return false;
    if (Jogo.getLocal(x, y).getQuadrado(x, y) != null) return false;
    x1 = quadrados[3].getX() + 1;
    y1 = quadrados[3].getY() + 1;
    x2 = quadrados[0].getX() - 1;
    y2 = quadrados[0].getY() + 1;
    quadrados[2].setPos(x, y);
    quadrados[3].setPos(x1, y1);
    quadrados[0].setPos(x2, y2);
    posicao = 0;
   }
  }
  else if (tipo == 6){
   int x1, x2, x3, y1, y2, y3;
   if (posicao == 0){
    x1 = quadrados[0].getX() + 2;
    y1 = quadrados[0].getY() - 2;
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[1].getX() + 1;
    y2 = quadrados[1].getY() - 1;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    x3 = quadrados[3].getX() - 1;
    y3 = quadrados[3].getY() + 1;
    if (x3 < 0 || x3 >= 10 || y3 >= 20) return false;
    if (Jogo.getLocal(x3, y3).getQuadrado(x3, y3) != null) return false;
    quadrados[0].setPos(x1, y1);
    quadrados[1].setPos(x2, y2);
    quadrados[3].setPos(x3, y3);
    posicao++;
   }
   else{
    x1 = quadrados[0].getX() - 2;
    y1 = quadrados[0].getY() + 2;
    if (x1 < 0 || x1 >= 10 || y1 >= 20) return false;
    if (Jogo.getLocal(x1, y1).getQuadrado(x1, y1) != null) return false;
    x2 = quadrados[1].getX() - 1;
    y2 = quadrados[1].getY() + 1;
    if (x2 < 0 || x2 >= 10 || y2 >= 20) return false;
    if (Jogo.getLocal(x2, y2).getQuadrado(x2, y2) != null) return false;
    x3 = quadrados[3].getX() + 1;
    y3 = quadrados[3].getY() - 1;
    if (x3 < 0 || x3 >= 10 || y3 >= 20) return false;
    if (Jogo.getLocal(x3, y3).getQuadrado(x3, y3) != null) return false;
    quadrados[0].setPos(x1, y1);
    quadrados[1].setPos(x2, y2);
    quadrados[3].setPos(x3, y3);
    posicao--;
   }
  }
  return true;
 }
}