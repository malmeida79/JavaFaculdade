/************************************************************************************
 * Autor: Felipe Borges Alves                                                       *
 * Email: fbafelipe@hotmail.com                                                     *
 * ICQ: 158095106                                                                   *
 ************************************************************************************/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class JTetris extends JFrame implements KeyListener{
 private static Jogo jogo;
 private static Menu menu;
 private static Proxima proxima;
 private static JPanel status;
 private static JLabel l1, l2, l3;
 private static Container container;
 public static Rank rank;
 public static JLabel pontosLabel, levelLabel, fileirasLabel;
 public static long pontos;
 public static int fileiras, level, proximoLevel, menuSelect = 0;
 public static JTetris tetris;
 public static boolean desceRapido = false, taNoMenu = true;
 public static String nome = "Nome";
 public JTetris(){
  super("JTetris");
  addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){System.exit(0);}});
  addKeyListener(this);
  int x, y, sx, sy;
  x = Quadrado.TAMANHOX * Jogo.TAMANHOX * 2;
  y = Quadrado.TAMANHOY * Jogo.TAMANHOY;
  x += 30;
  y += 60;
  Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
  sx = d.width;
  sy = d.height;
  setSize(x, y);
  setLocation((sx - x) / 2, (sy - y) / 2);
  setResizable(false);
  container = getContentPane();
  container.setLayout(null);
  jogo = new Jogo();
  menu = new Menu();
  d = jogo.getPreferedSize();
  jogo.setSize(d.width, d.height);
  jogo.setLocation(10, 20);
  menu.setSize(d.width, d.height);
  menu.setLocation(10, 20);
  container.add(menu);
  rank = new Rank();
  rank.setSize(d.width, d.height);
  rank.setLocation(20 + d.width, 20);
  status = new JPanel(null);
  status.setSize(d.width, d.height);
  status.setLocation(20 + d.width, 20);
  proxima = new Proxima();
  proxima.setSize(Quadrado.TAMANHOX * Proxima.MAX, Quadrado.TAMANHOY * Proxima.MAX);
  proxima.setLocation(50, 150);
  status.add(proxima);
  l1 = new JLabel("Pontos:");
  l1.setSize(50, 20);
  l1.setLocation(20, 20);
  status.add(l1);
  pontosLabel = new JLabel("0");
  pontosLabel.setSize(100, 20);
  pontosLabel.setLocation(80, 20);
  status.add(pontosLabel);
  l2 = new JLabel("Level:");
  l2.setSize(50, 20);
  l2.setLocation(20, 50);
  status.add(l2);
  levelLabel = new JLabel("0");
  levelLabel.setSize(100, 20);
  levelLabel.setLocation(80, 50);
  status.add(levelLabel);
  l3 = new JLabel("Fileiras:");
  l3.setSize(50, 20);
  l3.setLocation(20, 80);
  status.add(l3);
  fileirasLabel = new JLabel("0");
  fileirasLabel.setSize(100, 20);
  fileirasLabel.setLocation(80, 80);
  status.add(fileirasLabel);
  container.add(rank);
  setVisible(true);
 }
 public static void main(String args[]){
  Quadrado.init();
  Proxima.init();
  tetris = new JTetris();
 }
 public static void iniciaMenu(){
  level = 0;
  fileiras = 0;
  menuSelect = 0;
  taNoMenu = true;
  Jogo.continua = false;
  container.remove(proxima);
  container.remove(jogo);
  container.add(menu);
  container.remove(status);
  container.add(rank);
  tetris.repaint();
 }
 public static void terminaMenu(){
  taNoMenu = false;
  container.remove(menu);
  container.add(jogo);
  container.remove(rank);
  container.add(status);
 }
 public void keyPressed(KeyEvent e){
  if (taNoMenu){
   if (menuSelect == 1){
    if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE){
     if (nome.length() > 0) nome = nome.substring(0, nome.length() - 1);
    }
    else{
     nome += e.getKeyChar();
    }
   }
   if (e.getKeyCode() == KeyEvent.VK_ENTER){
    if (menuSelect == 0){
     terminaMenu();
     jogo.inicia(level, fileiras);
    }
   }
   else if (e.getKeyCode() == KeyEvent.VK_DOWN) menuSelect = (menuSelect + 1) % Menu.OPCOES;
   else if (e.getKeyCode() == KeyEvent.VK_UP){
    menuSelect--;
    if (menuSelect < 0) menuSelect = Menu.OPCOES - 1;
   }
   else if (e.getKeyCode() == KeyEvent.VK_LEFT){
    if (menuSelect == 2){
     level--;
     if (level < 0) level = 0;
    }
    else if (menuSelect == 3){
     fileiras--;
     if (fileiras < 0) fileiras = 0;
    }
   }
   else if (e.getKeyCode() == KeyEvent.VK_RIGHT){
    if (menuSelect == 2){
     level++;
     if (level > 9) level = 9;
    }
    else if (menuSelect == 3){
     fileiras++;
     if (fileiras > 16) fileiras = 16;
    }
   }
   tetris.repaint();
  }
  else{
   if (e.getKeyCode() == KeyEvent.VK_ESCAPE) JTetris.iniciaMenu();
   if (!Jogo.continua) return;
   if (e.getKeyCode() == KeyEvent.VK_PAUSE || e.getKeyCode() == KeyEvent.VK_P){
    Jogo.pausado = !Jogo.pausado;
    tetris.repaint();
   }
   if (Jogo.pausado) return;
   if (e.getKeyCode() == KeyEvent.VK_DOWN) desceRapido = true;
   else{
    if (e.getKeyCode() == KeyEvent.VK_RIGHT) Jogo.peca.move(Peca.DIREITA);
    else if (e.getKeyCode() == KeyEvent.VK_LEFT) Jogo.peca.move(Peca.ESQUERDA);
    else if (e.getKeyCode() == KeyEvent.VK_UP) Jogo.peca.move(Peca.RODA);
    repaint();
   }
  }
 }
 public void keyTyped(KeyEvent e){}
 public void keyReleased(KeyEvent e){
  if (e.getKeyCode() == KeyEvent.VK_DOWN) desceRapido = false;
 }
}