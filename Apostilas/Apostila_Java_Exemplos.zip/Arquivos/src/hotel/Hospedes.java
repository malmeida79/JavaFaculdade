package hotel;

import java.util.Vector;

public class Hospedes {
  private Vector hospedes;

  public Hospedes() {
    hospedes = new Vector();
  }

  public void inserir (Hospede hospede) {
    this.hospedes.addElement(hospede);
  }

  public String toString () {
    StringBuffer sb = new StringBuffer("Hospedes : ");
    for (int i = 0; i < this.hospedes.size(); i++ ) {
      Hospede hospede = (Hospede) hospedes.get(i);
      sb.append(hospede.toString());
    }
    return sb.toString();
  }
}