package hotel;

import java.util.Vector;

public class Quartos {
  private Vector quartos;

  public Quartos () {
    quartos = new Vector();
  }

  public void inserir (Quarto quarto) {
    quartos.addElement (quarto);
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("Quartos : ");
    for (int i = 0; i < this.quartos.size(); i++ ) {
      Quarto quarto = (Quarto) quartos.get(i);
      sb.append(quarto.toString());
    }
    return sb.toString();
  }
}