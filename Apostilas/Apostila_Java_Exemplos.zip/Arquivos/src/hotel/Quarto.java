package hotel;

public class Quarto {

  private int numero;
  private int capacidade;
  private float diaria;
  private char status;

  public Quarto (int numero, int capacidade, float diaria, char status) {
    this.setNumero(numero);
    this.setCapacidade(capacidade);
    this.setDiaria(diaria);
    this.setStatus(status);
  }

  public void setNumero (int value) {
    this.numero = numero;
  }

  public void setCapacidade (int value) {
    this.capacidade = capacidade;
  }

  public void setDiaria (float value) {
    this.diaria = diaria;
  }

  public void setStatus (char value) {
    this.status = status;
  }

  public int getNumero () {
    return this.numero;
  }

  public int getCapacidade () {
    return this.capacidade;
  }

  public float getDiaria () {
    return this.diaria;
  }

  public char getStatus () {
    return this.status;
  }

  public String toString () {
    return "[" + this.getNumero() + "," + this.getCapacidade() + "," +
           this.getDiaria() + "," + this.getStatus() + "]";
  }
}