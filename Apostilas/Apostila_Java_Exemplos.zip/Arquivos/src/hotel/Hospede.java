package hotel;

public class Hospede {
  private String cpf;
  private String nome;
  private Quarto quarto;

  public Hospede(String cpf, String nome) {
    this.setCpf(cpf);
    this.setNome(nome);
  }

  public void setCpf (String value) {
    this.cpf = value;
  }

  public void setNome (String value) {
   this.nome = value;
  }

  public String getCpf () {
    return this.cpf;
  }

  public String getNome () {
    return this.nome;
  }

  public String toString () {
    return "[" + this.getCpf() + "," + this.getNome() + "]";
  }
}