package hotel;

public class Hotel {

  public static void main(String[] args) {
    Quartos quartos = new Quartos();
    quartos.inserir(new Quarto(1,1,100.0f,'L'));
    quartos.inserir(new Quarto(2,2,200.0f,'L'));
    quartos.inserir(new Quarto(3,3,300.0f,'L'));
    quartos.inserir(new Quarto(4,4,400.0f,'L'));
    quartos.inserir(new Quarto(5,5,500.0f,'L'));
    System.out.println(quartos.toString());

    Hospedes hospedes = new Hospedes();
    hospedes.inserir(new Hospede("11111111111","Jos�"));
    hospedes.inserir(new Hospede("22222222222","Jos�"));
    hospedes.inserir(new Hospede("33333333333","Jos�"));
    hospedes.inserir(new Hospede("44444444444","Jos�"));
    hospedes.inserir(new Hospede("55555555555","Jos�"));
    System.out.println(hospedes.toString());

  }

}