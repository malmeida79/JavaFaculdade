/* Classe usando Thread que simula a corrida de um sapo */

package threads.corridaDeSapos;

class SapoCorrendoThread extends Thread {

	String nome;					// nome do sapo
	int distanciaCorrida = 0;		// dist�ncia j� corrida pelo sapo
	int distanciaTotalCorrida;		// dist�ncia a ser corrida pelo sapo
	int pulo = 0;					// pulo do sampo em metros
	int pulos = 0;					// quantidades de pulos dados na corrida
	static int colocacao = 0;		// coloca��o do sapo ao final da corrida
	final static int PULO_MAXIMO = 50; // pulo m�ximo em cm que um sapo pode dar

	/** Construtor da classe. Par�mtros : Nome do Sapo e Dist�ncia da Corrida */
	public SapoCorrendoThread (String nome, int distanciaTotalCorrida) {
		/* chamando o construtor de Thread passando o nome do sapo como par�metro */
		super(nome);
		this.distanciaTotalCorrida = distanciaTotalCorrida;
		this.nome = nome;
	}
	/** Imprime o �ltimo pulo do sapo e a dist�ncia percorrida */
	synchronized public void sapoImprimindoSituacao () {
		System.out.println("O " + nome +  " pulou " + pulo + "cm \t e j� percorreu " +
							distanciaCorrida + "cm");
	}
	/** Faz o sapo pular */
	synchronized public void sapoPulando() {
		pulos++;
		pulo = (int) (Math.random() * PULO_MAXIMO);
		distanciaCorrida += pulo;
		if (distanciaCorrida > distanciaTotalCorrida) {
			distanciaCorrida = distanciaTotalCorrida;
		}
	}
	/** Rrepresentando o descanso do sapo */
	synchronized public void sapoDescansando () {
		/* M�todo que passa vez a outras threads */
		yield();
	}
	/** Imprime a coloca��o do sapo ao final da corrida */
	synchronized public void colocacaoSapo () {
		colocacao++;
		System.out.println(nome + " foi o " + colocacao +
							"� colocado com " + pulos + " pulos");
	}
	/** M�todo run da thread Corrida de Sapos */
	public void run () {
		while (distanciaCorrida < distanciaTotalCorrida) {
			sapoPulando();
			sapoImprimindoSituacao();
			sapoDescansando();
		}
		colocacaoSapo();
	}
}