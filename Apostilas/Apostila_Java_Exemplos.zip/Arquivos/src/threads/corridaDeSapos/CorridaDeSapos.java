/* Aplica��o que simula uma corrida de sapos usando threads */

package threads.corridaDeSapos;

public class CorridaDeSapos {
	final static int NUM_SAPOS = 5;	// QTE. de sapos na corrida
	final static int DISTANCIA = 500; // Dist�ncia da corrida em cm

	public static void main (String[] args) {

		/* Criando as threads para representar os sapos correndo */
		for (int i = 1; i < 5; i++ ) {
			new SapoCorrendoThread("SAPO_" + i, DISTANCIA).start();
		}
	}
}