 /**
  * @author Jos� Maria Rodrigues Santos Junior
  * zemaria@unitnet.com.br / http://www.unit.br/zemaria
  *
  * Classe de thread Produtora
  */

package threads.produtorConsumidor;

public class ProdutorThread extends Thread {
	/* objeto para referenciar o buffer */
	BufferLimitado buffer;
	/* quantidade de itens a serem produzidos */
	int quantItens;

	/**
	 * Construtor
	 * @param threadGroup Grupo da thread
	 * @param nomeThread Nome da thread
	 * @param buffer buffer a ser utilizado
	 * @param quantItens quantidade de itens a serem produzidos
	 */
	public ProdutorThread (ThreadGroup threadGroup,String nomeThread,
							BufferLimitado buffer, int quantItens)  {
		super(threadGroup, nomeThread);
		this.buffer = buffer;
		this.quantItens = quantItens;
	}

	/*
	 * M�todo run da thread, o qual cont�m o ser comportamento
	 */
	public void run () {
		for (int i = 1; i <= quantItens; i++) {
			/* Gera um novo item aleatoriamente */
			int novoItem = (int) (Math.random() * 10);
			/* Insere o novo item no buffer */
			buffer.insere(novoItem);
			/* dorme pelo intervalo de tempo aleat�rio [0 ... 100]mseg */
			int tempo = (int) (Math.random() * 1000);
			dorme(tempo);
		}
	}

	private void dorme(int tempo) {
		try {
			sleep(tempo);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
	}
}