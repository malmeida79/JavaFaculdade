/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@unitnet.com.br / http://www.unit.br/zemaria
 *
 * Aplica��o para simular o problema cl�ssico Produtor/Consumidor
 * de comunica��o entre processos usando threads em Java
 */

package threads.produtorConsumidor;

public class ProdutorConsumidor {
	public static void main (String[] args) {

		/* Criando o Buffer Limitado */
		BufferLimitado buffer = new BufferLimitado();
		/* Quantidade de itens a serem produzidos/consumidos pelas threads */
		final int QUANT_ITENS = 10;
		/* Quantidade de threads */
		final int QUANT_THREADS = 5;
		/* Criando os grupos de threads Produtoras/Consumidoras */
		ThreadGroup threadsProdutoras   = new ThreadGroup("Produtores");
		ThreadGroup threadsConsumidoras = new ThreadGroup("Consumidores");
		/* Criando e iniciando e inserindo nos grupos as threads Produtoras */
		for (int i = 1; i <= QUANT_THREADS; i++){
			new ProdutorThread(threadsProdutoras,"Produtor_" + i,
								buffer,QUANT_ITENS).start();
		}
		/* Criando, iniciando e inserindo nos grupos as threads Consumidoras */
		for (int i = 1; i <= QUANT_THREADS; i++){
			new ConsumidorThread(threadsConsumidoras,"Consumidor_" + i,
								  buffer,QUANT_ITENS).start();
		}
	}
}