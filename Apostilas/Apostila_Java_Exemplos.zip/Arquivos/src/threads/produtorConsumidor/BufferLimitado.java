/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@unitnet.com.br / http://www.unit.br/zemaria
 *
 * Classe representando o buffer limitado a ser compartilhado pelas threads
 * Produtoras e Consumidoras
 */

package threads.produtorConsumidor;

public class BufferLimitado {
	/* tamano do buffer */
	private final static int TAMANHO = 5;
	/* buffer */
	private int[] buffer = new int[TAMANHO];
	/* posi��o para inserc�o de novo item (in) */
	private int posicaoInsere = 0;
	/* posi��o para remo��o do item (out) */
	private int posicaoRetira = 0;
	/* quantidades de itens no buffer */
	private int quantItens = 0;

	/* Construtor */
	public BufferLimitado () {
	}

	/**
	 * Insere um novo item no buffer
	 * @param novoItem item a ser inserido no buffer
	 */
	synchronized public void insere (int novoItem) {
		/* enquanto o buffer estiver cheio a thread deve esperar */
		while (quantItens == TAMANHO) {
			try {
				wait();
			} catch (InterruptedException e){
				System.out.println("Erro de Estado da Thread "
				                   + e.getMessage());
			}
		}
		/* colocando novo item no buffer */
		buffer[posicaoInsere] = novoItem;
		/* exibindo inform��es sobre a inser��o do novo item */
		System.out.print("Inserindo " + novoItem + "\tna posi��o " + posicaoInsere + "\t");
		/* atualizando a posi��o de inser��o */
		posicaoInsere = proximaPosicao(posicaoInsere);
		/* incrementando a quantidade de itens no buffer */
		quantItens++;
		/* imprimindo o buffer */
		imprime();
		/* caso o buffer estivesse vazio, acordar as threads consumidoras */
		if (quantItens == 1) {
			notifyAll();
		}
	}

	/**
	 * Retira um item do buffer
	 * @return Item retirado do buffer
	 */
	synchronized public int retira () {
		int itemRetirado;	// item retirado
		/* enquanto o buffer estiver vazio a thread deve esperar */
		while (quantItens == 0) {
			try {
				wait();
			} catch (InterruptedException e){
				System.out.println("Erro de Estado da Thread "
									+ e.getMessage());
			}
		}
		/* armazendo o item a ser retirado */
		itemRetirado = buffer[posicaoRetira];
		/* atualizando a quantidade de itens */
		quantItens--;
		/* exibindo informa��es sobre a retirado do item do buffer */
		System.out.print("Retirando " + itemRetirado
						  + "\tda posi��o " + posicaoRetira + "\t");
		/* atualizando a  posi��o de retirado */
		posicaoRetira = proximaPosicao(posicaoRetira);
		/* imprimindo o buffer */
		imprime();
		/* caso o buffer estivesse cheio, acordar as threads produtoras */
		if (quantItens == TAMANHO - 1) {
			notifyAll();
		}

		/* retorna o item retirado */
		return itemRetirado;
	}

	/**
	 * Obtem a pr�xima posi��o no buffer
	 * @param posicaoAtual a atual posicao no buffer
	 * @return a pr�mixa posi��o no buffer
	 */
	private int proximaPosicao (int posicaoAtual) {
		/* obtem a nova posi��o */
		int novaPosicao = ++posicaoAtual;
		/* caso ultrapasse o tamanho do buffer,ir� para o 1� posi��o (0) */
		if (novaPosicao > TAMANHO - 1) {
			novaPosicao = 0;
		}

		return novaPosicao;
	}

	/**
	 * Obtem a posi��o anterior no buffer
	 * @param posicaoAtual a atual posicao no buffer
	 * @return a posi��o anterior no buffer
	 */
	private int posicaoAnterior (int posicaoAtual) {
		/* obtem a nova posi��o */
		int novaPosicao = --posicaoAtual;
		/* caso seja menor que a posi��o inicial, ir� para a �ltima posi��o */
		if (novaPosicao < 0) {
			novaPosicao  = TAMANHO-1;
		}

		return novaPosicao;
	}

	/*
	 * Imprime o buffer
	 */
	synchronized private void imprime () {
		/* posi��o inicial da impress�o */
		int inicio = posicaoRetira;
		/* posi��o final da impress�o */
		int fim = posicaoAnterior(posicaoInsere);
		/* posi��o impressa */
		int i = inicio;
		/* quantidade de itens impressos */
		int quantItensImpressos = 0;
		System.out.print("\tBuffer[" + quantItens + "] \t= ");
		while (quantItensImpressos < quantItens) {
			System.out.print(buffer[i] + " ");
			i = proximaPosicao(i);
			quantItensImpressos++;
		}
		System.out.println();
	}
}