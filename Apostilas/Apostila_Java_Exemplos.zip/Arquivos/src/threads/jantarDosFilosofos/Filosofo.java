/**
 * Classe para representar os filosofos
 *
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@unitnet.com.br
 * http://www.unit.br/zemaria
 */

package threads.jantarDosFilosofos;

public class Filosofo extends Thread {

 	/* Tempo m�ximo (em milesegundos) que o fil�sofo vai comer ou pensar */
 	final static int TEMPO_MAXIMO = 100;
 	/* Refer�ncia � mesa de jantar */
 	MesaDeJantar mesa;
 	/* Fil�sofo na mesa [0,1,2,3,4] */
 	int filosofo;

 	public Filosofo (String nomeThread, MesaDeJantar mesa, int filosofo) {
 		/* construtor da classe pai */
 		super(nomeThread);
 		this.mesa = mesa;
 		this.filosofo = filosofo;
 	}

 	public void run () {
 		int tempo = 0;
 		/* La�o representando a vida de um fil�sofo : pensar e comer */
 		while (true) {
 			/* sorteando o tempo pelo qual o fil�sofo vai pensar */
			tempo = (int) (Math.random() * TEMPO_MAXIMO);
			/* fil�sofo pensando */
			pensar(tempo);
			/* fil�sofo pegando garfos */
 			pegarGarfos();
 			/* sorteando o tempo pelo qual o fil�sofo vai comer */
			tempo = (int) (Math.random() * TEMPO_MAXIMO);
			/* fil�sofo comendo */
 			comer(tempo);
 			/* fil�sofo devolvendo garfos */
 			devolverGarfos();
 		}
 	}

 	/* simula o fil�sofo pensando */
 	private void pensar (int tempo) {
 		try {
 			/* fil�sofo dorme de tempo milisegundos */
 			sleep(tempo);
 		} catch (InterruptedException e){
 			System.out.println("Fil�foso pensou demais morreu");
 		}
 	}

 	/* simula o fil�sofo comendo */
 	private void comer (int tempo) {
 		try {
 			sleep(tempo);
 		} catch (InterruptedException e){
 			System.out.println("Fil�foso comeu demais morreu");
 		}
 	}

 	/* pega os garfos */
 	private void pegarGarfos() {
 		mesa.pegandoGarfos(filosofo);
 	}

 	/* devolve os garfos */
 	private void devolverGarfos() {
 		mesa.devolvendoGarfos(filosofo);
 	}
}