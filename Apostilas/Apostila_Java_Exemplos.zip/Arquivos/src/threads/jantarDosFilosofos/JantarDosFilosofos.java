/**
 * Aplica��o implementando o cl�ssico problema sobre Deadlock :
 * "O Jantar dos Fil�sofos Glut�es"
 *
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@unitnet.com.br
 * http://www.unit.br/zemaria
 */

package threads.jantarDosFilosofos;

public class JantarDosFilosofos {

 	public static void main (String[] args) {
 		/* Mesa de jantar para os fil�sofos */
 		MesaDeJantar mesa = new MesaDeJantar ();
 		/* Cria��o das threads representando os cinco fil�sofos */
 		for (int  filosofo = 0; filosofo < 5; filosofo++) {
 			new Filosofo("Filosofo_" + filosofo, mesa, filosofo).start();
 		}
 	}
 }