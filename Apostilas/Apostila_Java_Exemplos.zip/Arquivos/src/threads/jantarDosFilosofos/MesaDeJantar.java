/**
 * Classe para representar a mesa de jantar, talheres
 * e estados dos fisl�sofos
 *
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@unitnet.com.br
 * http://www.unit.br/zemaria
 */

package threads.jantarDosFilosofos;

public class MesaDeJantar {
	/* fil�sofo pensando */
	final static int PENSANDO = 1;
	/* fil�sofo comendo */
	final static int COMENDO  = 2;
	/* fil�sofo com fome */
	final static int COM_FOME = 3;
	/* Quantidade de fil�sofos */
	final static int QUANT_FILOSOFOS   = 5;
	/* N�mero do primeiro fil�sofo */
	final static int PRIMEIRO_FILOSOFO = 0;
	/* N�mero do �ltimo fil�sofo */
	final static int ULTIMO_FILOSOFO = QUANT_FILOSOFOS - 1;
	/* array[0...QUANT_FILOSOFOS - 1] representando os garfos na mesa :
	 * true = garfo na mesa; false = garfo com fil�sofo
	 */
	boolean[] garfos = new boolean[QUANT_FILOSOFOS];
	/* array [0...QUANT_FILOSOFOS - 1]
	   representando o estado de cada um dos fil�sofos
	 */
	int[] filosofos = new int[QUANT_FILOSOFOS];
	/* Quantas vezes cada fil�sofo tentou comer e n�o conseguiu,
	 * serve para identificar situa��es de Starvation
	 */
	int[] tentativasParaComer = new int[QUANT_FILOSOFOS];

	/* Construtor */
	public MesaDeJantar() {
		/* Preenchendo os vetores de Garfos e fil�sofos � mesa */
		for (int i = 0; i < 5; i++) {
			/* Todos os garfos est�o na mesa */
			garfos[i] = true;
			/* Todos os fil�sofos sentam � mesa pensando */
			filosofos[i] = PENSANDO;
			/* Nenhum fil�sofo tentou comer ainda */
			tentativasParaComer[i] = 0;
		}
	}

	/* filosofo pegando os garfos */
	synchronized void pegandoGarfos (int filosofo) {
		/* fil�sofo com fome */
		filosofos[filosofo] = COM_FOME;
		/* Deve esperar enquanto algum fil�sofo vizinho estive comendo */
		while (filosofos[aEsquerda(filosofo)] == COMENDO
			|| filosofos[aDireita(filosofo)]  == COMENDO) {
				try {
					/* Fil�sofo tentou comer e n�o conseguiu */
					tentativasParaComer[filosofo]++;
					/* colocando o filosofo para esperar */
					wait();
				} catch (InterruptedException e) {
					System.out.println("Fil�sofo morreu de fome");
				}
		}
		/* Fil�sofo conseguiu comer */
		tentativasParaComer[filosofo] = 0;
		/* retirando os garfos esquerdo e direito da mesa */
		garfos[garfoEsquerdo(filosofo)] = false;
		garfos[garfoDireito(filosofo)]  = false;
		/* Fil�sofo comendo */
		filosofos[filosofo] = COMENDO;
		imprimeEstadosFilosofos();
		imprimeGarfos();
		imprimeTentativasParaComer();
	}

	/* Filosofo devolvendo os garfos */
	synchronized void devolvendoGarfos (int filosofo) {
		/* Devolvendo os garfos esquerdo e direito da mesa */
		garfos[garfoEsquerdo(filosofo)] = true;
		garfos[garfoDireito(filosofo)]  = true;
		/* Verificando se h� algum fil�sofo vizinho com fome */
		if (filosofos[aEsquerda(filosofo)] == COM_FOME ||
			filosofos[aDireita(filosofo)]  == COM_FOME) {
			/* Notifica (acorda) os vizinhos com fome */
			notifyAll();
		}
		/* Fil�sofo pensando */
		filosofos[filosofo] = PENSANDO;
		imprimeEstadosFilosofos();
		imprimeGarfos();
		imprimeTentativasParaComer();
	}

	/* Retorna o n�mero do fil�sofo a direita */
	private int aDireita (int filosofo) {
		int direito;
		/* Caso seja o fil�sofo n�5, a sua direita est� o fil�sofo n�1 */
		if (filosofo == ULTIMO_FILOSOFO) {
			direito = PRIMEIRO_FILOSOFO;
		} else {
			/* Caso contr�rio */
			direito = filosofo + 1;
		}

		return direito;
	}

	/* Retorna o n�mero do fil�sofo a esquerda */
	private int aEsquerda (int filosofo) {
		int esquerdo;
		/* Caso seja o primeiro fil�sofo a sua esquerda est� o �ltimo */
		if (filosofo == PRIMEIRO_FILOSOFO) {
			esquerdo = ULTIMO_FILOSOFO;
		} else {
			esquerdo = filosofo - 1;
		}

		return esquerdo;
	}

	/** Retorna o n�mero do garfo a esquerda do fil�sofo */
	private int garfoEsquerdo (int filosofo) {
		/* O fil�sofo 1 possui o garfo 1 a sua esquerda e assim por diante */
		int garfoEsquerdo = filosofo;

		return garfoEsquerdo;
	}

	/** Retorna o n�mero do garfo a direita do fil�sofo */
	private int garfoDireito (int filosofo) {
		int garfoDireito;
		/* O �ltimo fil�sofo possui o garfo 0 a sua direita*/
		if (filosofo == ULTIMO_FILOSOFO) {
			garfoDireito = 0;
		} else {
			garfoDireito = filosofo + 1;
		}

		return garfoDireito;
	}

	/* Imprimindo os estados dos fil�sofos */
	private void imprimeEstadosFilosofos () {
		String texto = "*";
		System.out.print("Fil�sofos = [ ");
		for (int i = 0; i < QUANT_FILOSOFOS; i++) {
			switch (filosofos[i]) {
		  		case PENSANDO :
		  			texto = "PENSANDO";
	    			break;
	  			case COM_FOME :
	  				texto = "COM_FOME";
	    			break;
	  			case COMENDO :
	  				texto = "COMENDO";
	    			break;
			}
			System.out.print(texto + " ");
		}
		System.out.println("]");
	}

	/* Imprimindo os que est�o na mesa */
	private void imprimeGarfos () {
		String garfo = "*";
		System.out.print("Garfos    = [ ");
		for (int i = 0; i < QUANT_FILOSOFOS; i++) {
			if (garfos[i]) {
	  			garfo = "LIVRE";
			} else {
				garfo = "OCUPADO";
			}
			System.out.print(garfo + " ");
		}
		System.out.println("]");
	}

	/* Imprimindo as tentativas de comer dos dos fil�sofos */
	private void imprimeTentativasParaComer () {
		System.out.print("Tentou comer = [ ");
		for (int i = 0; i < QUANT_FILOSOFOS; i++) {
			System.out.print(filosofos[i] + "  ");
		}
		System.out.println("]");
	}
}