package threads.threadExtendsThread;

public class AplicacaoThreads {

	public static void main (String[] args) {
		new ThreadSimples("Michelle").start();
		new ThreadSimples("Junior").start();
		System.out.println(Thread.MIN_PRIORITY);
		System.out.println(Thread.NORM_PRIORITY);
		System.out.println(Thread.MAX_PRIORITY);


	}
}