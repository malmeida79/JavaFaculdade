package threads.threadExtendsThread;

public class ThreadSimples extends Thread {
	public ThreadSimples (String str) {
		super(str);
	}

	public void run() {
		long espera;
		for (int i = 0; i < 10; i++) {
			System.out.println(getName() + " " + i);
			try {
				espera = (long) (Math.random()*1000);
				sleep(espera);
			} catch (InterruptedException e) {
				System.out.println("Erro : " + e.getMessage());
			}
		}
		System.out.println("Thread " + getName() + " terminada");
	}
}