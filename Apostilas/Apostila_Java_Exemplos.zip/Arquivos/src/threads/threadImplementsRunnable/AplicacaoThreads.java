package threads.threadImplementsRunnable;

public class AplicacaoThreads {
	public static void main (String[] args) {
		new ThreadSimples("Junior").start();
		new ThreadSimples("Michelle").start();
	}
}