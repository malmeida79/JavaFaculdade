package threads.threadImplementsRunnable;

public class ThreadSimples implements Runnable {
	private Thread thread = null;
		public ThreadSimples (String threadName) {
			if (thread == null) {
				thread = new Thread(this, threadName);
			}
		}

	public void start() {
		if (thread != null) {
			thread.start();
		}
	}

	public void run () {
		long espera;
		for (int i = 0; i < 10; i++) {
			System.out.println(thread.getName() + " " + i);
				espera = (long) (Math.random()*1000);
				thread.yield(); //leep(espera);
		}
		System.out.println("Thread " + thread.getName() + " terminada");
	}
}