package futebol;

/**
 * Title:        Projeto Futebol
 * Description:  Projeto demonstra��o
 * Copyright:    Copyright (c) 2001
 * Company:      InfoNet
 * @author Jos� Maria
 * @version 1.0
 */

public class Jogador extends Pessoa implements Comparable {
  private int numero;
  private String posicao;

  public Jogador (String cpf, String nome,
                  int numero, String posicao ) {
    super(cpf, nome);
    this.setNumero(numero);
    this.setPosicao(posicao);
  }

  public void setNumero (int numero) {
    this.numero = numero;
  }

  public void setPosicao (String posicao) {
    this.posicao = posicao;
  }

  public int getNumero (){
    return this.numero;
  }

  public String getPosicao () {
    return this.posicao;
  }

  public boolean equals ( Object obj ) {
    Jogador jogador = null;
    boolean resp = false;
    try {
      jogador = (Jogador) obj;
      resp = this.getCpf().equals(jogador.getCpf());
    } catch ( Exception e ) {
    }
    return resp;
  }

  public int compareTo (Object obj) {
    Jogador jogador = (Jogador) obj;
    return this.getNome().compareTo(jogador.getNome());
  }

  public String toString () {
    return "[" + this.getCpf() + "," + this.getNome() + "," +
           this.getNumero() + "," + this.getPosicao()+ "]";
  }

  public static void main(String[] args) {
    Jogador jogador1 = new Jogador("66176433568", "Z� Maria", 10, "Centro-Avante");
    Jogador jogador2 = new Jogador("6617643568", "Maria", 12, "Lateral");
    System.out.println(jogador1);
    System.out.println(jogador2);
    System.out.println(jogador1.equals(jogador2));
  }
}