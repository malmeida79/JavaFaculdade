package futebol;

import java.util.Vector;
import java.util.Collections;

/**
 * Title:        Projeto Futebol
 * Description:  Projeto demonstra��o
 * Copyright:    Copyright (c) 2001
 * Company:      InfoNet
 * @author Jos� Maria
 * @version 1.0
 */

public class Time {
  private String nome;
  private String cores;
  private Vector jogadores;

  public Time(String nome, String cores) {
    this.setNome(nome);
    this.setCores(cores);
    jogadores = new Vector();
  }

  public void setNome (String nome) {
    this.nome = nome;
  }
  public void setCores (String cores) {
    this.cores = cores;
  }

  public String getNome ()  {
    return this.nome;
  }

  public String getCores () {
    return this.cores;
  }

  public void insereJogador (Jogador jogador) {
    this.jogadores.addElement(jogador);
  }

  public String toString () {
    StringBuffer resp = new StringBuffer();
    Collections.sort(this.jogadores);
    resp.append("[" + this.getNome() + "," + this.getCores() + "]\n");
    for (int i = 0; i < this.jogadores.size(); i++) {
      resp.append(jogadores.get(i).toString() + "\n");
    }
    return resp.toString();
  }
  public static void main(String[] args) {
    Time time = new Time("Flamengo","Preto/Vermelho/Branco");
    time.insereJogador(new Jogador("99999999999", "J�nior", 8, "Lateral"));
    time.insereJogador(new Jogador("88888888888", "Zico", 4, "Lateral"));
    time.insereJogador(new Jogador("33333333333", "Binho", 7, "Lateral"));
    time.insereJogador(new Jogador("22222222222", "Paulo", 1, "Lateral"));
    time.insereJogador(new Jogador("77777777777", "Cabelo", 6, "Lateral"));
    time.insereJogador(new Jogador("66666666666", "Falcao", 15, "Lateral"));
    time.insereJogador(new Jogador("55555555555", "Jorginho", 13, "Lateral"));
    time.insereJogador(new Jogador("44444444444", "Dada", 1, "Lateral"));
    System.out.println(time);
  }
}