/**
 * Title:        <p> ComandoFor
 * Description:  <p> Aplica��o demonstrando o comando for
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package comandos;

import util.Keyboard;

public class ComandoFor {

	public static void main(String[] args) {
		final int inicio = 10;
		final int fim = 10;
		int resultado = 0;
		System.out.print("Tabuada de (+ x) : ");
		char tabuada = Keyboard.readChar();

		for (int i = 0; i <= inicio; i++ ) {
			for (int j = 0; j <= fim; j++) {
				switch (tabuada) {
					case '+' :
						resultado = i + j;
						break;
					case 'x' :
						resultado = i * j;
						break;
				}
				System.out.print(i + " " + String.valueOf(tabuada) + " " + j +
								   " = " + resultado + "\t");
			}
			System.out.println();
		}
    }
}