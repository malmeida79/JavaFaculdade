/**
 * Title:        <p> ComandoBreakContinue
 * Description:  <p> Aplica��o demonstrando os comandos break e continue
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package comandos;

public class ComandoBreakContinue {

	public static void main(String[] args) {
		for (int i = 0; i <= 1000 ; i++ ) {
			if ( i == 10 )
				break;
			System.out.print(i + " ");
		}
		System.out.println();

		for (int i = 0; i <= 20 ; i++) {
			if ( i <= 10 )
				continue;
			System.out.print(i + " ");
		}
    }
}