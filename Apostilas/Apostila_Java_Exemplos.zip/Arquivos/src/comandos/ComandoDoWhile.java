/**
 * Title:        <p> ComandoDoWhile
 * Description:  <p> Aplica��o demonstrando o comando do while
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package comandos;

import java.lang.String;
import util.Keyboard;

public class ComandoDoWhile {

	public static void main(String[] args) {
		int numero;
		int fatorial;
		System.out.println("Calculo do fatorial (flag = 0)");
		do {
			System.out.print("N�mero : ");
			numero = Keyboard.readInt();
			fatorial = 1;
			while (numero > 1) {
				fatorial *= numero;
				numero--;
			}
			System.out.println("Fatorial : " + fatorial);
		} while (numero != 0);
    }
}