/**
 * Title:        <p> ComandoIF
 * Description:  <p> Aplica��o demonstrando o comando if
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package comandos;

import util.Keyboard;

public class ComandoIF {

	public static void main(String[] args) {
		/* Validando uma data */
		int dia, mes, ano;
		System.out.print("Dia : ");
		dia = Keyboard.readInt();
		System.out.print("M�s : ");
		mes = Keyboard.readInt();
		System.out.print("Ano : ");
		ano = Keyboard.readInt();
		boolean data = false;
		/* meses de 30 dias */
		if ( mes == 4 || mes == 6 || mes == 9 || mes == 11) {
			if ( dia >= 1 && dia <= 30 ) {
				data = true;
			}
		} else {
			/* meses de 31 dias */
			if ( mes == 1 || mes == 3  || mes == 5 || mes == 7 ||
				 mes == 8 || mes == 10 || mes == 12 ) {
				if ( dia >= 1 && dia <= 31 ) {
					data = true;
				}
			} else {
				/* fevereiro */
				if ( mes == 2 ) {
					if ( dia >= 1 && dia <= 28 ) {
						data = true;
					} else {
						/* 29 de fevereiro */
						if ( dia == 29 ) {
							/* Ano bissexto */
							boolean bissexto = ( (ano % 4 == 0) &&
												 (ano % 100 != 0) ) ||
											   (ano % 400 == 0);
							if ( bissexto ) {
								data = true;
							}
						}
					}
				}
			}
		}
		System.out.print(dia + "/" + mes + "/" + ano + " : ");
		if ( data )
			System.out.println("Data V�lida");
		else
			System.out.println("Data Inv�lida");
	}
}