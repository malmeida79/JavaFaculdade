/**
 * Title:        <p> ComandoWhile
 * Description:  <p> Aplica��o demonstrando o comando while
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package comandos;

import util.Keyboard;

public class ComandoWhile {

	public static void main( String[] args ) {
		int numero;
		int fatorial;
		System.out.println("Calculo do fatorial (flag < 0)");
		System.out.print("N�mero : ");
		numero = Keyboard.readInt();
		while ( numero >= 0 ) {
			fatorial = 1;
			while ( numero > 1 ) {
				fatorial *= numero;
				numero--;
			}
			System.out.println( "Fatorial : " + fatorial );
			System.out.print( "N�mero : ");
			numero = Keyboard.readInt();
		}
		System.out.println( "Fim" );
    }
}