/**
 * Title:        <p> ComandoSwitch
 * Description:  <p> Aplica��o demonstrando o comando switch
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package comandos;

import util.Keyboard;

public class ComandoSwitch {

	public static void main(String[] args) {
		/* Validando uma data */
		int dia, mes, ano;
		System.out.print("Dia : ");
		dia = Keyboard.readInt();
		System.out.print("M�s : ");
		mes = Keyboard.readInt();
		System.out.print("Ano : ");
		ano = Keyboard.readInt();
		boolean data = false;
		switch (mes) {
			/* meses de 30 dias */
			case 4  :
			case 6  :
			case 9  :
			case 11 :
				if ( dia >= 1 && dia <= 30 )
					data = true;
				break;
			/* meses de 31 dias */
			case 1  :
			case 3  :
			case 5  :
			case 7  :
			case 8  :
			case 10 :
			case 12 :
				if ( dia >= 1 && dia <= 31 )
					data = true;
				break;
			/* fevereiro */
			case 2 :
				if ( dia >= 1 && dia <= 28 ) {
					data = true;
				} else {
					/* 29 de fevereiro */
					if ( dia == 29 ) {
						/* Ano bissexto */
						boolean bissexto = ( (ano % 4 == 0)&&
											 (ano % 100 != 0) ) ||
											 (ano % 400 == 0);
						if ( bissexto ) {
							data = true;
						}
					}
				}
                        break;
			default : data = false;
		}

		System.out.print(dia + "/" + mes + "/" + ano + " : ");
		if ( data )
			System.out.println("Data V�lida");
		else
			System.out.println("Data Inv�lida");
	}
}
