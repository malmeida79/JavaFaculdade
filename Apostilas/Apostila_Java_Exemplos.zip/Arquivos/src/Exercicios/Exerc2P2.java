package ZeMaria;

import util.Keyboard;;

public class Exerc2P2 {
	public static void main (String[] args) {
		System.out.print("Sal�rio : ");
		float salario = Keyboard.readFloat();
		float percReajuste = 0;

		if ( salario <=  1000) {
		    percReajuste = 0.3f;
		} else if (salario <= 2000) {
			percReajuste = 0.2f;
		} else {
			percReajuste = 0.1f;
		}
//		float aumento = salario * percReajuste;
//		salario += aumento;
		salario = salario * (1 + percReajuste);
//		System.out.println("Aumento : " + aumento);
		System.out.println("Novo Sal�rio : " + salario);
	}
}