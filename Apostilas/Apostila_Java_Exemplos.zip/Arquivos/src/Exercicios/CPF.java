package ZeMaria;

public class CPF {
	private String cpf;
	private String dv;

	public CPF() {
	}

	public CPF(String cpf) {
		cpf(cpf);
	}

	private void cpfDV (String cpf) {
		this.cpf = cpf.substring(0,9);
		this.dv = cpf.substring(9,11);
	}

	public void cpf (String cpf) {
		if ( valida(cpf) ) {
			cpfDV(cpf);
		}
	}

	public String cpf () {
		return this.toString();
	}

	public static boolean valida (String cpf) {
		int[] numBase = {11,10,9,8,7,6,5,4,3,2};
		boolean res = false;
		int soma = 0;
		for (int i = 0; i < 9; i++) {
			int digCPf = Integer.parseInt(String.valueOf(cpf.charAt(i)));
			int digNumBase = numBase[i+1];
			soma += ( digCPf * digNumBase );
		}
		int dv1 = 11 - (soma % 11);
		if (dv1 == 10 || dv1 == 11) {
			dv1 = 0;
		}
		cpf = cpf + dv1;

		soma = 0;
		for (int i = 0; i < 10; i++) {
			int digCPf = Integer.parseInt(String.valueOf(cpf.charAt(i)));
			int digNumBase = numBase[i];
			soma += ( digCPf * digNumBase );
		}
		int dv2 = 11 - (soma % 11);
		if (dv2 == 10 || dv2 == 11) {
			dv2 = 0;
		}
		System.out.println(dv1 + "" + dv2);
		return res;
	}

	public String toString() {
		return cpf + "-" + dv;
	}

	public static void main(String[] args) {
		CPF cpf = new CPF("66176433568");
		System.out.println(cpf);
	}
}