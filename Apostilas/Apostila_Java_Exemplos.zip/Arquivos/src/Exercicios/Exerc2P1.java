package ZeMaria;

import util.Keyboard;

public class Exerc2P1 {
	public static void main (String[] args) {
		int[] notas = {100, 50, 10, 5, 1}; // valores das c�dulas

		System.out.print("Saque : ");
		int saque = Keyboard.readInt();

		/* Verificando quantas notas de cada valor */
		for (int i = 0; i < notas.length; i++) {
			/* quantidades de notas */
			int n = saque / notas[i];
			System.out.println(n + " notas de " + notas[i]);
			/* resto do saque */
			saque %= notas[i];
		}
	}
}