/**
 * Programa solu�ao do exerc�cio 2, problema 7
 */

package ZeMaria;

import java.util.Random;

public class Exerc2P7 {

	public static void main(String[] args) {
		final int LINHAS = 5;
		final int COLUNAS = 5;

		int[][] mat = new int[LINHAS][COLUNAS]; //matriz
		int[] vet = new int[LINHAS * COLUNAS]; // vetor
		int posVet =  0;

		/* Inicializando a matriz */
		/*
		mat[0][0] = 1; mat[0][1] = 2; mat[0][2] = 7; mat[0][3] = 3; mat[0][4] = 9;
		mat[1][0] = 4; mat[1][1] = 2; mat[1][2] = 6; mat[1][3] = 3; mat[1][4] = 7;
		mat[2][0] = 6; mat[2][1] = 7; mat[2][2] = 2; mat[2][3] = 8; mat[2][4] = 5;
		mat[3][0] = 6; mat[3][1] = 8; mat[3][2] = 0; mat[3][3] = 9; mat[3][4] = 2;
		mat[4][0] = 7; mat[4][1] = 1; mat[4][2] = 8; mat[4][3] = 3; mat[4][4] = 0;
		*/

		/* Preenchendo a matriz com n�mero aleat�rios no intervalo 0 .. 9*/
		Random sorteio = new Random();
		for (int i = 0; i < mat.length; i++)
			for (int j = 0; j < mat[0].length; j++)
				mat[i][j] = sorteio.nextInt(10);

		/* Passando por todos os elementos da matriz */
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat[0].length; j++) {
				/* Verificando se o elemento j� est� no vetor ,
				 * caso n�o esteja, ser� colocado
				 */
				boolean achou = false;
				int k = 0; // �ndice para o vetor
				/* Procurando no vetor */
				while ( !achou && k < posVet ) {
					if ( mat[i][j] == vet[k] ) {
						achou = true;
					}
					k++;
				}
				if ( !achou ) {
					vet[posVet] = mat[i][j];
					posVet++;
				}
			}
		}

		/* Imprimindo a matriz */
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat[0].length; j++) {
				System.out.print(mat[i][j] + "\t");
			}
			System.out.println();
		}

		/* Contando quantas vezes cada elemento do vetor aparece na matriz */
		for (int k = 0; k < posVet; k++) {
			System.out.print(vet[k] + " => ");
			int cont = 0;
			for (int i = 0; i < mat.length; i++) {
				for (int j = 0; j < mat[0].length; j++) {
					if ( vet[k] == mat[i][j] ) {
						cont++;
					}
				}
			}
			System.out.println(cont);
		}
	}
}