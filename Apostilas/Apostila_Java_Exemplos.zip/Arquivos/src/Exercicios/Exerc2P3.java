package ZeMaria;

import util.Keyboard;;

public class Exerc2P3 {
	public static void main (String[] args) {
		System.out.print("Lado 1 : ");
		float l1 = Keyboard.readFloat();

		System.out.print("Lado 2 : ");
		float l2 = Keyboard.readFloat();

		System.out.print("Lado 3 : ");
		float l3 = Keyboard.readFloat();

		/* Verificando se os valores pode forma um tri�ngulo */
		if ( ( l1 >= l2 + l3) || ( l2 >= l1 + l3) || (l3 >= l1 + l2) ) {
			System.out.print("Valores n�o podem formar um tri�ngulo");
		} else {
			if ( l1 == l2 && l1 == l3 ) {
				System.out.print("Equil�tero");
			} else if ( l1 == l2 || l1 == l3 || l2 == l3 ) {
				System.out.print("Is�rceles");
			} else {
				System.out.print("Escaleno");
			}
		}
	}
}