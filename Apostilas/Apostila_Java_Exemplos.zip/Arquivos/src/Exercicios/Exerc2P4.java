package ZeMaria;

public class Exerc2P4 {

    public static void main(String[] args) {
    }
}