
/**
 * Title:        <p>
 * Description:  <p>
 * Copyright:    Copyright (c) <p>
 * Company:      <p>
 * @author
 * @version 1.0
 */
package ZeMaria;

public class Teste {

	public static void main(String[] args) {
		System.out.println(compara(10,10));
	}

	static String compara (int a, int b) {
		if ( a == b )
			return "Iguais";
		else
			return "Diferentes";
	}
}