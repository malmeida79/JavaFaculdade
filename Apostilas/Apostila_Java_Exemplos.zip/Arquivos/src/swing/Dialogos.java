/**
 * Title:        <p> Dialogos
 * Description:  <p> Aplica��o demonstrando o uso de di�logos swing
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package swing;

import javax.swing.JOptionPane;

public class Dialogos {

	public static void main (String[] args) {
		String tituloDialogo = "T�tulo da caixa de Di�logo";
		String msg = "Mensagem";
		JOptionPane.showMessageDialog(null, msg);
		JOptionPane.showMessageDialog(null, msg, tituloDialogo,
									  JOptionPane.PLAIN_MESSAGE);
		JOptionPane.showMessageDialog(null, msg, tituloDialogo,
									  JOptionPane.INFORMATION_MESSAGE);
		JOptionPane.showMessageDialog(null, msg, tituloDialogo,
									  JOptionPane.WARNING_MESSAGE);
		JOptionPane.showMessageDialog(null, msg, tituloDialogo,
									  JOptionPane.ERROR_MESSAGE);
		msg = "Voc� gosta de Java";
		Object[] opcoes = {"Sim","N�o","Mais ou Menos"};
		int resp = 	JOptionPane.showOptionDialog(null, msg,
						"Pergunta",
						JOptionPane.YES_NO_CANCEL_OPTION,
						JOptionPane.QUESTION_MESSAGE,
						null,
						opcoes,
						opcoes[2]
					);
		System.out.println("Resposta : " + opcoes[resp].toString());

		String nome = JOptionPane.showInputDialog("Digite o seu nome : ");
		System.out.println( "nome : " + nome );

		System.exit( 0 );
	}
}