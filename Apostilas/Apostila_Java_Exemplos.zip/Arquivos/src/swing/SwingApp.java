package swing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class SwingApp extends JFrame {
	JPanel jPanel1 = new JPanel();
	JButton jButton1 = new JButton();

	public static void main(String[] args) {
		SwingApp swingApp = new SwingApp();
	}

	public SwingApp() {
		try {
			jbInit();
			this.pack();
			this.show();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		jButton1.setText("jButton1");
		jButton1.addActionListener(new java.awt.event.ActionListener() {

		public void actionPerformed(ActionEvent e) {
			jButton1_actionPerformed(e);
			}
		});
		this.getContentPane().add(jPanel1, BorderLayout.CENTER);
		jPanel1.add(jButton1, null);
	}

	void jButton1_actionPerformed(ActionEvent e) {
		System.out.println( "Resposta ao evento" );
	}
}