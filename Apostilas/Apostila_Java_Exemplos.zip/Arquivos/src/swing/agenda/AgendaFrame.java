/**
 * Title:        <p> AgendaFrame
 * Description:  <p> Aplica��o swing de Agenda Eletr�nica
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package swing.agenda;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;


public class AgendaFrame extends JFrame {
	/*
	 * Vari�vel indicando se o item atual deve ser inserido ou atualizado.
	 * Caso o botao Novo tenha sido pressionado o valor ser� false
	 * Quando o botao confirma for pressiona volta ao estado padrao : true
	 */
	private boolean atualizacao = true;

	/* Arquivo para salvar os itens da Agenda */
	String nomeArquivo = "D:\\MeusDocumentos\\CursoDeJava\\Standard\\Fontes\\" +
	"src\\swing\\agenda\\Agenda.dat";
	/* Itens da Agenda */
	ItensAgenda itensAgenda = new ItensAgenda( nomeArquivo );

	/* Componentes swing, criados automaticamente pelo JBuilder */
    JPanel jPanel = new JPanel();
    JMenuBar jMenuBar = new JMenuBar();
    JMenu jMenuArquivo = new JMenu();
    JMenuItem jMenuSair = new JMenuItem();
    JMenu jMenuAjuda = new JMenu();
    JMenuItem jMenuSobre = new JMenuItem();
    TitledBorder titledBorder1;
    JLabel jLabelNome = new JLabel();
    JTextField jTextFieldNome = new JTextField();
    JLabel jLabelTelefone = new JLabel();
    JTextField jTextFieldTelefone = new JTextField();
    JLabel jLabelEmail = new JLabel();
    JTextField jTextFieldEmail = new JTextField();
    JPanel jPanelBotoes = new JPanel();
    JButton jButtonNovo = new JButton();
    JButton jButtonConfirmar = new JButton();
    JButton jButtonUltimo = new JButton();
    JButton jButtonProximo = new JButton();
    JButton jButtonAnterior = new JButton();
    JButton jButtonPrimeiro = new JButton();
    JButton jButtonApagar = new JButton();
    JButton jButtonProcurar = new JButton();
    JMenu jMenu1 = new JMenu();
	/* Agrupando os itens de r�dio do menu para a escolha do LookAndFeel*/
	ButtonGroup lookAndFeelButtonGroup;
    JRadioButtonMenuItem jRadioButtonMenuItemMetal = new JRadioButtonMenuItem();
    JRadioButtonMenuItem jRadioButtonMenuItemMotif = new JRadioButtonMenuItem();
    JRadioButtonMenuItem jRadioButtonMenuItemWindows = new JRadioButtonMenuItem();

    public static void main(String[] args) {
		AgendaFrame agenda = new AgendaFrame();
		agenda.setSize( 420,250 );
		agenda.show();
    }

    public AgendaFrame() {
		/* Inicializando os itens da agenda a partir do arquivo */
		try {
			itensAgenda.abrir( nomeArquivo );
			ItemAgendaParaJTextFields( itensAgenda.getItemCorrente() );
		} catch ( Exception e ) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Aviso",
										  JOptionPane.WARNING_MESSAGE);
		}

        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        titledBorder1 = new TitledBorder("");
        jPanel.setLayout(null);
        this.setDefaultCloseOperation(3);
        this.setJMenuBar(jMenuBar);
        this.setResizable(false);
        this.setTitle("Agenda");
        jMenuArquivo.setText("Arquivo");
        jMenuSair.setText("Sair");
        jMenuSair.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jMenuSair_actionPerformed(e);
            }
        });
        jMenuAjuda.setText("Ajuda");
        jMenuSobre.setText("Sobre");
        jPanel.setBorder(BorderFactory.createEtchedBorder());
        jLabelNome.setText("Nome");
        jLabelNome.setBounds(new Rectangle(7, 16, 41, 17));
        jTextFieldNome.setNextFocusableComponent(jTextFieldTelefone);
        jTextFieldNome.setToolTipText("Nome");
        jTextFieldNome.setBounds(new Rectangle(67, 14, 332, 21));
        jLabelTelefone.setText("Telefone");
        jLabelTelefone.setBounds(new Rectangle(4, 45, 52, 17));
        jTextFieldTelefone.setNextFocusableComponent(jLabelEmail);
        jTextFieldTelefone.setToolTipText("Telefone");
        jTextFieldTelefone.setBounds(new Rectangle(67, 44, 332, 21));
        jLabelEmail.setText("Email");
        jLabelEmail.setBounds(new Rectangle(5, 75, 41, 17));
        jTextFieldEmail.setNextFocusableComponent(jLabelNome);
        jTextFieldEmail.setToolTipText("Email");
        jTextFieldEmail.setBounds(new Rectangle(67, 75, 332, 20));
        jPanelBotoes.setBorder(BorderFactory.createEtchedBorder());
        jPanelBotoes.setBounds(new Rectangle(5, 126, 395, 61));
        jPanelBotoes.setLayout(null);
        jButtonNovo.setToolTipText("insere novo item");
        jButtonNovo.setText("Novo");
        jButtonNovo.setBounds(new Rectangle(3, 3, 99, 27));
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonNovo_actionPerformed(e);
            }
        });
        jButtonConfirmar.setToolTipText("Confirma opera��o");
        jButtonConfirmar.setText("Confirmar");
        jButtonConfirmar.setBounds(new Rectangle(100, 3, 99, 27));
        jButtonConfirmar.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonConfirmar_actionPerformed(e);
            }
        });
        jButtonUltimo.setToolTipText("�ltimo");
        jButtonUltimo.setText("�ltimo");
        jButtonUltimo.setBounds(new Rectangle(294, 30, 99, 27));
        jButtonUltimo.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonUltimo_actionPerformed(e);
            }
        });
        jButtonProximo.setToolTipText("Pr�ximo");
        jButtonProximo.setText("Pr�ximo");
        jButtonProximo.setBounds(new Rectangle(197, 30, 99, 27));
        jButtonProximo.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonProximo_actionPerformed(e);
            }
        });
        jButtonAnterior.setToolTipText("Anterior");
        jButtonAnterior.setText("Anterior");
        jButtonAnterior.setBounds(new Rectangle(100, 30, 99, 27));
        jButtonAnterior.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonAnterior_actionPerformed(e);
            }
        });
        jButtonPrimeiro.setToolTipText("Primeiro");
        jButtonPrimeiro.setText("Primeiro");
        jButtonPrimeiro.setBounds(new Rectangle(3, 30, 99, 27));
        jButtonPrimeiro.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonPrimeiro_actionPerformed(e);
            }
        });
        jButtonApagar.setText("Apagar");
        jButtonApagar.setBounds(new Rectangle(294, 3, 99, 27));
        jButtonApagar.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonApagar_actionPerformed(e);
            }
        });
        jMenu1.setText("Exibir");
        jRadioButtonMenuItemMetal.setSelected(true);
        jRadioButtonMenuItemMetal.setText("Metal");
        jRadioButtonMenuItemMetal.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jRadioButtonMenuItemMetal_actionPerformed(e);
            }
        });
        jRadioButtonMenuItemMotif.setText("Motif");
        jRadioButtonMenuItemMotif.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jRadioButtonMenuItemMotif_actionPerformed(e);
            }
        });
        jRadioButtonMenuItemWindows.setText("Windows");
        jRadioButtonMenuItemWindows.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jRadioButtonMenuItemWindows_actionPerformed(e);
            }
        });
		/* Agrupando os r�dio buttons do menu */
		lookAndFeelButtonGroup = new ButtonGroup();
		jButtonProcurar.setText("Procurar");
        jButtonProcurar.setBounds(new Rectangle(197, 3, 99, 27));
        jButtonProcurar.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonProcurar_actionPerformed(e);
            }
        });
        lookAndFeelButtonGroup.add( jRadioButtonMenuItemMetal );
		lookAndFeelButtonGroup.add( jRadioButtonMenuItemMotif );
		lookAndFeelButtonGroup.add( jRadioButtonMenuItemWindows );

        jMenuBar.add(jMenuArquivo);
        jMenuBar.add(jMenu1);
        jMenuBar.add(jMenuAjuda);
        jMenuArquivo.addSeparator();
        jMenuArquivo.add(jMenuSair);
        jMenuAjuda.add(jMenuSobre);
        jMenu1.add(jRadioButtonMenuItemMetal);
        jMenu1.add(jRadioButtonMenuItemMotif);
        jMenu1.add(jRadioButtonMenuItemWindows);
        this.getContentPane().add(jPanel, BorderLayout.CENTER);
        jPanel.add(jTextFieldTelefone, null);
        jPanel.add(jTextFieldNome, null);
        jPanel.add(jLabelNome, null);
        jPanel.add(jLabelTelefone, null);
        jPanel.add(jLabelEmail, null);
        jPanel.add(jTextFieldEmail, null);
        jPanel.add(jPanelBotoes, null);
        jPanelBotoes.add(jButtonConfirmar, null);
        jPanelBotoes.add(jButtonApagar, null);
        jPanelBotoes.add(jButtonPrimeiro, null);
        jPanelBotoes.add(jButtonNovo, null);
        jPanelBotoes.add(jButtonAnterior, null);
        jPanelBotoes.add(jButtonProximo, null);
        jPanelBotoes.add(jButtonUltimo, null);
        jPanelBotoes.add(jButtonProcurar, null);
    }

    void jMenuSair_actionPerformed(ActionEvent e) {
		try {
			itensAgenda.salvar();
		} catch ( Exception exc ) {
			JOptionPane.showMessageDialog(null, exc.getMessage(), "Aviso",
										  JOptionPane.WARNING_MESSAGE);
		}
		System.exit( 0 );
    }

	private void limparJTextFields() {
		jTextFieldNome.setText("");
		jTextFieldEmail.setText("");
		jTextFieldTelefone.setText("");
	}

	private void jTextFieldsParaItemAgenda( ItemAgenda itemAgenda ) {
		if ( itemAgenda != null )  {
			if ( ! jTextFieldNome.getText().equals( "" )) {
				itemAgenda.setNome( jTextFieldNome.getText() );
			}
			itemAgenda.setTelefone( jTextFieldTelefone.getText() );
			itemAgenda.setEmail( jTextFieldEmail.getText() );
		}
	}

	private void ItemAgendaParaJTextFields( ItemAgenda itemAgenda ) {
		if ( itemAgenda != null )  {
			jTextFieldNome.setText( itemAgenda.getNome() );
			jTextFieldTelefone.setText( itemAgenda.getTelefone() );
			jTextFieldEmail.setText( itemAgenda.getEmail() );
		}
	}

    void jButtonConfirmar_actionPerformed(ActionEvent e) {
		jButtonNovo.setEnabled( true );
		botoesAcoes( true );
		botoesNavegacao( true );
		if ( atualizacao ) {
			jTextFieldsParaItemAgenda( itensAgenda.getItemCorrente() );
		} else {
			ItemAgenda itemAgenda = new ItemAgenda();
			jTextFieldsParaItemAgenda( itemAgenda );
			if ( ! itensAgenda.existe( itemAgenda ) ) {
				itensAgenda.insere( itemAgenda );
			} else {
				String msg = "Item j� cadastrado.";
				String pergunta = "Deseja substiruir ?";
				Object[] opcoes = {"Sim","N�o"};
				int resp = 	JOptionPane.showOptionDialog(null, pergunta,
								msg,
								JOptionPane.YES_NO_OPTION,
								JOptionPane.QUESTION_MESSAGE,
								null,
								opcoes,
								opcoes[1]
							);
				if ( resp == 0 ) {
					itensAgenda.insere( itemAgenda );
				}
			}
		}
		atualizacao = true ;
		this.exibirItemCorrente();
		System.out.println( "Agenda = " + itensAgenda);
		System.out.println( "Item Corrente = " +
							itensAgenda.getItemCorrente() );
    }

	private void botoesAcoes ( boolean situacao ) {
		jButtonApagar.setEnabled( situacao );
		jButtonProcurar.setEnabled( situacao );
	}

	private void botoesNavegacao ( boolean situacao ) {
		jButtonPrimeiro.setEnabled( situacao );
		jButtonAnterior.setEnabled( situacao );
		jButtonProximo.setEnabled( situacao );
		jButtonUltimo.setEnabled( situacao );
	}

	private void exibirItemCorrente () {
		if ( itensAgenda.getItemCorrente() == null ) {
			this.limparJTextFields();
		}
		ItemAgendaParaJTextFields( itensAgenda.getItemCorrente() );
	}

    void jRadioButtonMenuItemMetal_actionPerformed(ActionEvent e) {
		lookAndFeel ( 0 );
    }

    void jRadioButtonMenuItemMotif_actionPerformed(ActionEvent e) {
		lookAndFeel ( 1 );
    }

    void jRadioButtonMenuItemWindows_actionPerformed(ActionEvent e) {
		lookAndFeel ( 2 );
    }

	private void lookAndFeel ( int lf ) {
		UIManager.LookAndFeelInfo[] lookAndFeel;
		lookAndFeel = UIManager.getInstalledLookAndFeels();
		try {
			UIManager.setLookAndFeel(
				lookAndFeel[lf].getClassName());
			SwingUtilities.updateComponentTreeUI(this);
		} catch ( Exception e ) {
			System.out.println( "Problemas na altera��o do LookAndFeel :" +
								e.hashCode() );
		}
	}

	private void escreveAgenda () {
		System.out.println( "Agenda = " + itensAgenda);
		System.out.println( "Item Corrente = " +
							itensAgenda.getItemCorrente() );
	}

    void jButtonNovo_actionPerformed(ActionEvent e) {
		atualizacao = false;
		limparJTextFields();
		botoesAcoes( false );
		botoesNavegacao( false );
		jButtonNovo.setEnabled( false );
		jTextFieldNome.requestFocus();
    }

    void jButtonProcurar_actionPerformed(ActionEvent e) {
		String nome = JOptionPane.showInputDialog(null,"Nome : ",
												  "Procura por nome",
												  JOptionPane.PLAIN_MESSAGE);
		if ( nome != null ) {
			itensAgenda.procuraAproximadaPorNome( nome );
			this.exibirItemCorrente();
		}
		this.escreveAgenda();
    }

    void jButtonApagar_actionPerformed(ActionEvent e) {
		itensAgenda.apaga( );
		exibirItemCorrente();
		this.escreveAgenda();
    }

    void jButtonPrimeiro_actionPerformed(ActionEvent e) {
		this.itensAgenda.primeiro();
		this.exibirItemCorrente();
		this.escreveAgenda();
    }

    void jButtonAnterior_actionPerformed(ActionEvent e) {
		this.itensAgenda.anterior();
		this.exibirItemCorrente();
		this.escreveAgenda();
    }

    void jButtonProximo_actionPerformed(ActionEvent e) {
		this.itensAgenda.proximo();
		this.exibirItemCorrente();
		this.escreveAgenda();
    }

    void jButtonUltimo_actionPerformed(ActionEvent e) {
		this.itensAgenda.ultimo();
		this.exibirItemCorrente();
		this.escreveAgenda();
    }
}