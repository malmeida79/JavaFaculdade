/**
 * Title:        <p> ItensAgenda
 * Description:  <p> Classe para armazenar os itens da Agenda
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package swing.agenda;

import java.util.Vector;
import java.util.Collections;
import java.io.*;

/**
 * Classe para armazenar uma cole�ao de items da Agenda
 */
public class ItensAgenda {
	/** Vector para armazenar os itens da Agenda */
	private Vector itensAgenda;
	/**
	 * Posi�ao do item corrente da Agenda
	 */
	private int posItemCorrente;
	/** Nome do arquivo para salvar/carregar o Vector dos itens da agenda */
	private String arquivo;

	/**
	 * Construtor
	 * @param nome do arquivo para salvar/carregar a cole�ao de itens
	 */
	public ItensAgenda( String arquivo ) {
		this.posItemCorrente = -1;
		this.itensAgenda = new Vector();
		this.setArquivo( arquivo );
	}

	private void setArquivo ( String arquivo ) {
		this.arquivo = arquivo;
	}

	public String getArquivo () {
		return arquivo;
	}

	public void salvar () throws Exception {
		FileOutputStream fos;
		ObjectOutputStream oos;
		try {
			fos = new FileOutputStream( getArquivo() );
			oos = new ObjectOutputStream( fos );
			oos.writeObject( itensAgenda );
			oos.flush();
			oos.close();
			fos.close();
		} catch ( NotSerializableException e ) {
			String msg = "Objeto n�o serializ�vel : " + e.getMessage();
			throw new NotSerializableException( msg );
		} catch ( IOException e ) {
			String msg = "Erro de I/O : " + e.getMessage();
			throw new IOException( msg );
		}
	}

	public void abrir ( String arquivo )  throws Exception {
		this.setArquivo( arquivo );

		FileInputStream fis;
		ObjectInputStream ois;
		try {
			fis = new FileInputStream( arquivo );
			ois = new ObjectInputStream( fis );
			itensAgenda = ( Vector ) ois.readObject();
		} catch ( FileNotFoundException e ) {
			String msg = "Arquivo n�o encontrado : " + e.getMessage();
			throw new FileNotFoundException( msg );
		} catch ( IOException e ) {
			String msg = "Erro de I/O : " + e.getMessage();
			throw new IOException( msg );
		} catch ( ClassNotFoundException e ) {
			String msg = "Classe n�o encontrada : " + e.getMessage();
			throw new ClassNotFoundException( msg );
		}
		posItemCorrente = 0;
	}

	public ItemAgenda getItemCorrente() {
		if ( itensAgenda.isEmpty() ) {
			return null;
		} else {
			return ( ItemAgenda ) itensAgenda.get( posItemCorrente );
		}
	}

	public void primeiro () {
		posItemCorrente = 0;
	}

	public void proximo () {
		if ( posItemCorrente < itensAgenda.size() - 1 ) {
			posItemCorrente++;
		}
	}

	public void anterior () {
		if ( posItemCorrente > 0 ) {
			posItemCorrente--;
		}
	}

	public void ultimo () {
		posItemCorrente = itensAgenda.size() - 1;
	}

	public boolean existe ( ItemAgenda itemAgenda ) {
		int pos = itensAgenda.indexOf( itemAgenda );
		if ( pos == -1 ) {
			return false;
		} else {
			return true;
		}
	}

	public void procuraAproximadaPorNome ( String nome ) {
		posItemCorrente = itensAgenda.size() - 1;
		System.out.println( "Nome : " + nome );
		for ( int i = 0 ; i < itensAgenda.size() ; i++ ) {
			ItemAgenda itemAgenda = ( ItemAgenda ) itensAgenda.get( i );
			String nomeAux = itemAgenda.getNome();
			if ( nomeAux.toUpperCase().startsWith( nome.toUpperCase() ) ) {
				posItemCorrente = i;
				break;
			}
		}
	}

	public void insere ( ItemAgenda itemAgenda ) {
		if (  ! itemAgenda.getNome().equals( "" ) ) {
			int pos = itensAgenda.indexOf( itemAgenda );
			if ( pos != -1 ) {
				itensAgenda.remove( pos );
			}
			itensAgenda.addElement( itemAgenda );
			Collections.sort( itensAgenda );
			posItemCorrente = itensAgenda.indexOf( itemAgenda );
		}
	}

	public void apaga ( ) {
		itensAgenda.remove( getItemCorrente() );
		anterior();
	}

	public int quantidade () {
		return itensAgenda.size();
	}

	public String toString () {
		return itensAgenda.toString();
	}
}