/**
 * Title:        <p> ItemAgenda
 * Description:  <p> Item a ser armazenado na Agenda
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package swing.agenda;

import java.lang.Comparable;
import java.io.Serializable;

/**
 * Classe representando um item a ser armazenado na agenda
 */
public class ItemAgenda	implements Comparable, Serializable {
	private String nome;
	private String telefone;
	private String email;

	/**
	 * Construtor padr�o
	 */
	public ItemAgenda ( ) {
	}

	/**
	 * Construtor inicializando todos os atributos
	 * @param nome Nome
	 * @param telefone Telefone
	 * @param email Email
	 */
	public ItemAgenda ( String nome, String telefone, String email ) {
		setNome( nome );
		setTelefone ( telefone );
		setEmail ( email );
	}

	/**
	 * Atribui o nome
	 * @param nome Nome
	 */
	public void setNome ( String nome ) {
		/* nome n�o pode ser nulo */
		if ( ! nome.equals( "" ) ) {
			this.nome = nome;
		}
	}

	/**
	 * Atribui o telefone
	 * @param telefone Telefone
	 */
	public void setTelefone ( String telefone ) {
		this.telefone = telefone;
	}

	/**
	 * Atribui o Email
	 * @param email Email
	 */
	public void setEmail ( String email ) {
		this.email = email;
	}

	/**
	 * Retorna o nome
	 * @result Nome
	 */
	public String getNome () {
		return nome;
	}

	/**
	 * Retorna o Telefone
	 * @result Telefone
	 */
	public String getTelefone () {
		return telefone;
	}

	/**
	 * Retorna o email
	 * @result Email
	 */
	public String getEmail () {
		return email;
	}

	/**
	 * Retorna a representa�ao String do Objeto
	 * @result representa��o String do Objeto
	 */
	public String toString () {
		return "[" + nome + "]";
	}

	/**
	 * Redefini�ao do m�todo java.Object.equals()
	 * @see java.lang.Object.equals()
	 */
	public boolean equals ( Object obj) {
		/* o nome determina a igualdade */
		ItemAgenda itemAgenda = ( ItemAgenda ) obj;
		return getNome().endsWith( itemAgenda.getNome() );
	}

	/**
	 * Redefini�ao do m�todo java.Comparable.compareTo()
	 * @see java.lang.Comparable.compareTo();
	 */
	public int compareTo ( Object obj ) {
		ItemAgenda itemAgenda = ( ItemAgenda ) obj;
		return getNome().compareTo( itemAgenda.getNome() );
	}
}