package swing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.border.*;

public class SwingDemo extends JFrame {
    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu jMenu1 = new JMenu();
    JMenuItem jMenuItem1 = new JMenuItem();
    JMenuItem jMenuItem2 = new JMenuItem();
    JMenuItem jMenuItem3 = new JMenuItem();
    JMenuItem jMenuItem4 = new JMenuItem();
    JMenu jMenu2 = new JMenu();
    JMenuItem jMenuItem5 = new JMenuItem();
    JMenuItem jMenuItem6 = new JMenuItem();
    JMenuItem jMenuItem7 = new JMenuItem();
    JPanel jPanel1 = new JPanel();
    JPanel jPanel2 = new JPanel();
    JRadioButton jRadioButton1 = new JRadioButton();
    JRadioButton jRadioButton2 = new JRadioButton();
    JRadioButton jRadioButton3 = new JRadioButton();
	ButtonGroup buttonGroup1 = new ButtonGroup();
    JButton jButton1 = new JButton();
    JPanel jPanel3 = new JPanel();
    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    JTextField jTextField1 = new JTextField();
    JTextField jTextField2 = new JTextField();
    JButton jButton2 = new JButton();
	String[] itemJComboBox1 = {"Item 1","Item 2","Item 3"};
    JComboBox jComboBox1 = new JComboBox(itemJComboBox1);
    JPanel jPanel4 = new JPanel();
    JCheckBox jCheckBox1 = new JCheckBox();
    JCheckBox jCheckBox2 = new JCheckBox();
    JProgressBar jProgressBar1 = new JProgressBar();
    JButton jButton3 = new JButton();
    JSlider jSlider1 = new JSlider();
    JPasswordField jPasswordField1 = new JPasswordField();
    JButton jButton4 = new JButton();
    JPanel jPanel5 = new JPanel();
    TitledBorder titledBorder1;
	Object[][] dadosJTabela1 = {{"Campo11","Campo12","Campo13"},
								{"Campo21","Campo22","Campo23"},
								{"Campo31","Campo32","Campo33"}
							   };
	String[] colunasJTabela1 = {"Coluna1","Coluna2",",Coluna3"};
    JTable jTable1 = new JTable(dadosJTabela1, colunasJTabela1);
    GridLayout gridLayout1 = new GridLayout();
    JPanel jPanel6 = new JPanel();
    TitledBorder titledBorder2;
    JButton jButton5 = new JButton();
    JButton jButton6 = new JButton();
    JButton jButton7 = new JButton();
    JButton jButton8 = new JButton();

	public static void main(String[] args) {
		SwingDemo swingDemo = new SwingDemo();
	}

    public SwingDemo() {
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
		this.pack();
		this.show();
    }

    private void jbInit() throws Exception {
        titledBorder1 = new TitledBorder("");
        titledBorder2 = new TitledBorder("");
        jMenu1.setText("Arquivo");
        jMenuItem1.setText("Op��o 1");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jMenuItem1_actionPerformed(e);
            }
        });
        jMenuItem2.setText("Op��o 2");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jMenuItem2_actionPerformed(e);
            }
        });
        jMenuItem3.setText("Op��o 3");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jMenuItem3_actionPerformed(e);
            }
        });
        jMenuItem4.setText("Sair");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jMenuItem4_actionPerformed(e);
            }
        });
        jMenu2.setText("Configura�ao");
        jMenuItem5.setText("Configura�ao 1");
        jMenuItem6.setText("Configura�ao 2");
        jMenuItem7.setText("Configura�ao 3 ");
        this.setDefaultCloseOperation(3);
        this.setJMenuBar(jMenuBar1);
        this.setResizable(false);
        this.setTitle("Demonstra�ao dos Componentes Swing");
        jPanel1.setLayout(null);
        jPanel2.setBorder(BorderFactory.createLineBorder(Color.black));
        jPanel2.setBounds(new Rectangle(3, 2, 393, 63));
        jPanel2.setLayout(null);
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setPreferredSize(new Dimension(400, 400));
        jRadioButton1.setText("Op��o 1");
        jRadioButton1.setActionCommand("Op��o 1");
        jRadioButton1.setBounds(new Rectangle(4, 4, 104, 25));
        jRadioButton2.setText("Op��o 2");
        jRadioButton2.setActionCommand("Op��o 2");
        jRadioButton2.setBounds(new Rectangle(112, 4, 104, 25));
        jRadioButton3.setText("Op��o 3");
        jRadioButton3.setBounds(new Rectangle(232, 4, 104, 25));
        jPanel3.setBorder(BorderFactory.createLoweredBevelBorder());
        jPanel3.setBounds(new Rectangle(4, 76, 391, 56));
        jPanel3.setLayout(null);
        jLabel1.setText("jLabel1");
        jLabel1.setBounds(new Rectangle(6, 6, 48, 17));
        jLabel2.setText("jLabel2");
        jLabel2.setBounds(new Rectangle(6, 29, 41, 17));
        jTextField1.setText("jTextField1");
        jTextField1.setBounds(new Rectangle(52, 5, 167, 21));
        jTextField2.setText("jTextField2");
        jTextField2.setBounds(new Rectangle(52, 27, 167, 21));
        jButton2.setText("jButton2");
        jButton2.setBounds(new Rectangle(233, 14, 81, 27));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                jButton2_mouseClicked(e);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jComboBox1_actionPerformed(e);
            }
        });
        jPanel4.setBorder(BorderFactory.createRaisedBevelBorder());
        jPanel4.setBounds(new Rectangle(5, 135, 389, 73));
        jPanel4.setLayout(null);
        jComboBox1.setBounds(new Rectangle(6, 5, 67, 26));
        jCheckBox1.setText("jCheckBox1");
        jCheckBox1.setBounds(new Rectangle(93, 32, 93, 25));
        jCheckBox2.setText("jCheckBox2");
        jCheckBox2.setBounds(new Rectangle(192, 33, 93, 25));
        jProgressBar1.setBounds(new Rectangle(87, 4, 148, 14));
        jButton3.setText("Clique Aqui");
        jButton3.setBounds(new Rectangle(118, 41, 97, 27));
        jButton3.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButton3_actionPerformed(e);
            }
        });
        jSlider1.setValue(0);
        jSlider1.setPaintTicks(true);
        jSlider1.setPaintLabels(true);
        jSlider1.setBorder(BorderFactory.createLoweredBevelBorder());
        jSlider1.setBounds(new Rectangle(93, 21, 136, 20));
        jSlider1.addChangeListener(new javax.swing.event.ChangeListener() {

            public void stateChanged(ChangeEvent e) {
                jSlider1_stateChanged(e);
            }
        });
        jPasswordField1.setBounds(new Rectangle(273, 7, 83, 21));
        jButton4.setText("Senha");
        jButton4.setBounds(new Rectangle(274, 33, 81, 27));
        jButton4.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButton4_actionPerformed(e);
            }
        });
        jPanel5.setBorder(titledBorder1);
        jPanel5.setBounds(new Rectangle(6, 341, 386, 91));
        jPanel5.setLayout(gridLayout1);
        jPanel6.setBorder(titledBorder2);
        jPanel6.setBounds(new Rectangle(6, 218, 387, 120));
        jButton5.setText("Enable");
        jButton5.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButton5_actionPerformed(e);
            }
        });
        jButton6.setText("Disable");
        jButton6.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButton6_actionPerformed(e);
            }
        });
        jButton7.setText("jButton7");
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                jButton7_mouseClicked(e);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButton7_actionPerformed(e);
            }
        });
        jButton8.setText("jButton8");
        jButton8.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButton8_actionPerformed(e);
            }
        });
        buttonGroup1.add(jRadioButton1);
		buttonGroup1.add(jRadioButton2);
		buttonGroup1.add(jRadioButton3);
        jButton1.setText("Escolha");
        jButton1.setBounds(new Rectangle(3, 31, 81, 27));
		jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                jButton1_mouseClicked(e);
            }
        });
        jMenuBar1.add(jMenu1);
        jMenuBar1.add(jMenu2);
        jMenu1.add(jMenuItem1);
        jMenu1.add(jMenuItem2);
        jMenu1.add(jMenuItem3);
        jMenu1.addSeparator();
        jMenu1.add(jMenuItem4);
        jMenu2.add(jMenuItem5);
        jMenu2.add(jMenuItem6);
        jMenu2.addSeparator();
        jMenu2.add(jMenuItem7);
        this.getContentPane().add(jPanel1, BorderLayout.EAST);
        jPanel1.add(jPanel2, null);
        jPanel2.add(jRadioButton1, null);
        jPanel2.add(jRadioButton2, null);
        jPanel2.add(jRadioButton3, null);
        jPanel2.add(jButton1, null);
        jPanel2.add(jCheckBox1, null);
        jPanel2.add(jCheckBox2, null);
        jPanel1.add(jPanel3, null);
        jPanel3.add(jLabel1, null);
        jPanel3.add(jTextField1, null);
        jPanel3.add(jTextField2, null);
        jPanel3.add(jLabel2, null);
        jPanel3.add(jButton2, null);
        jPanel1.add(jPanel4, null);
        jPanel4.add(jComboBox1, null);
        jPanel4.add(jProgressBar1, null);
        jPanel4.add(jSlider1, null);
        jPanel4.add(jButton3, null);
        jPanel4.add(jPasswordField1, null);
        jPanel4.add(jButton4, null);
        jPanel1.add(jPanel5, null);
        jPanel5.add(jTable1, null);
        jPanel1.add(jPanel6, null);
        jPanel6.add(jButton5, null);
        jPanel6.add(jButton6, null);
        jPanel6.add(jButton7, null);
        jPanel6.add(jButton8, null);
    }

    void jMenuItem1_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(null, "Op��o 1");
    }

    void jMenuItem4_actionPerformed(ActionEvent e) {
		System.exit( 0 );
    }

    void jMenuItem2_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(null, "Op��o 2");
    }

    void jMenuItem3_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(null, "Op��o 3");
    }

    void jButton1_mouseClicked(MouseEvent e) {
		String msg = buttonGroup1.getSelection().getActionCommand();
		JOptionPane.showMessageDialog(null, msg);
    }

    void jButton2_mouseClicked(MouseEvent e) {
		String msg = jTextField1.getText() + "\n" +
					 jTextField2.getText();
		JOptionPane.showMessageDialog(null, msg);
    }

    void jComboBox1_actionPerformed(ActionEvent e) {
		String msg = jComboBox1.getSelectedItem().toString();
		JOptionPane.showMessageDialog(null, msg);
    }

    void jButton3_actionPerformed(ActionEvent e) {
		if ( jProgressBar1.getValue() == 100 ) {
			jProgressBar1.setValue( 0 );
		}
		jProgressBar1.setValue(jProgressBar1.getValue() + 10);
    }

    void jSlider1_stateChanged(ChangeEvent e) {
		jProgressBar1.setValue(jSlider1.getValue());
    }

    void jButton4_actionPerformed(ActionEvent e) {
		String msg = new String(jPasswordField1.getPassword());
		JOptionPane.showMessageDialog(null, msg);
	}

    void jButton5_actionPerformed(ActionEvent e) {
		jButton7.setEnabled( false );
		jButton8.setEnabled( false );
    }

    void jButton6_actionPerformed(ActionEvent e) {
		jButton7.setEnabled( true );
		jButton8.setEnabled( true );
    }

    void jButton7_actionPerformed(ActionEvent e) {
		System.out.println( "jButton7" );
    }

    void jButton8_actionPerformed(ActionEvent e) {
		System.out.println( "jButton8" );

    }

    void jButton7_mouseClicked(MouseEvent e) {
		System.out.println( "MouseClicked" );
    }
}