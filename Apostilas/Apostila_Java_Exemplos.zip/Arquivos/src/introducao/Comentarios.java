/**
 * Descri�ao: <p>Aplica��o java demonstrando os tipos de coment�rios
 * Empresa:   <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

//Defini��o do pacote
package introducao;

//Defini��o de classe
public class Comentarios {

	/**
  	 * M�todo main da Aplica��o
     * @param args par�metros da linha de comando
  	 */
    public static void main(String[] args) {

		/*
		 * O la�o abaixo ir� passar por todos os par�metros fornecidos na linha
		 * de comando e ir� escrev�-los na sa�da padr�o
		 */
		int i = 0; // Vari�vel inteira
		System.out.print("Par�metros : ");
		while (i < args.length) {
			/* Ecreve posi��o i do array args na sa�da padr�o */
			System.out.print(args[i] + " ");
			i++; // Incrementa a vari�vel i de 1 unidade
		}
	}
}