/**
 * Application para testes
 */

package introducao;



import util.Keyboard;

public class Teste {

  public static void main(String[] args) {

    int soma = 20;
    int cont = 3;
    System.out.println((float)soma/cont);
  }

}