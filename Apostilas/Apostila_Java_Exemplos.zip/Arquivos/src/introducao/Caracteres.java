package introducao;

import java.io.IOException;

public class Caracteres {

    static private String keyboardRead () {
		int in = 0;
		char chr;
		StringBuffer Valor = new StringBuffer("");
		do {
	    	try {
 				in = System.in.read();
				chr = (char) in;
				if ((in != 10) & (in != 13)) {
						System.out.println(in);
				}
	    	} catch (IOException e) {}
		} while (in != 10);
		return Valor.toString();
    }

	public static void main (String[] args) {

		for (int i = 1 ; i <= 50; i++)
			keyboardRead();
	}
}