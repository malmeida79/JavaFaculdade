/**
 * Title:        <p> ClasseJava
 * Description:  <p> Demonstra��o de classe java
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

/* Defini��o do pacote */
package introducao;

/* Defini��o da classe (O mesmo nome do arquivo fonte) */
public class ClasseJava {

	/* Corpo da Classe */

	/* Atributos */

	/* Construtore(s) */
	public ClasseJava ( /* Par�metros */ ) {
		/* procedimentos de inicializa��o da classe */
	}

	/* Finalizador */
	protected void finalize () {
		/* procedimentos de finaliza��o da classe */
	}

	/* M�todos */
}