/**
 * Title:        <p> Operadores
 * Description:  <p> Aplica��o demonstrando o uso dos operadores
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package introducao;

import util.Keyboard;

public class Operadores {

	public static void main(String[] args) {

		/* declarando e inicializando 3 vari�veis inteiras */
		int i1 = 7;
		int i2 = 3;
		int i3;
		i3 = i1 + i2; // adi��o
		i3 = i1 - i2; // subtra��o
		i3 = i1 * i2; // multiplica��o
		i3 = i1 / i2; // divis�o inteira, pois n1 e n2 s�o do tipo int
		i3 = i1 % i2; // resto da divis�o inteira

		/* declarando e inicializando 3 vari�veis float */
		float f1 = 12.8f; // convers�o expl�cita para float
		float f2 = 6.4f;
		float f3;
		f3 = i1 * f2; // convers�o impl�cita para float
		f3 = f2 / i2; // divis�o float, pois o numerador � float

		f3++; // incremento
		f3--; // decremento
		f1 = ++f2 + f3; // a vari�vel i2 ser� incrementada antes da atribui��o
		f1 = f2++ + f3; // a vari�vel i2 ser� incrementada ap�s a atribui��o

		/* Operador relacional */
		System.out.println( f1 > f2 ? f1 : f2 );
		System.out.println( "f1 = " + f1 );
		System.out.println( "f2 = " + f2 );

		/* Calculo do pre�o de venda um produto baseado no pre�o de compra e
		   e no percentual de lucro */

		float pre�oCompra;
		float percentualLucro;
		System.out.print( "Pre�o de Compra : " );
		pre�oCompra = Keyboard.readFloat();
		System.out.print("Percentual de Lucro : ");
		percentualLucro = Keyboard.readFloat();
		float lucro = pre�oCompra * (percentualLucro/100);
		float pre�oVenda = pre�oCompra + lucro;
		System.out.println("Pre�o de Compra : " + pre�oCompra +
						   "\nPercentual de Lucro : " + percentualLucro +
						   "\nLucro : " + lucro +
						   "\nPre�o de Venda : " + pre�oVenda);

		int i = 10;
		System.out.println( " i " + i );
		i = i << 1;
		System.out.println( " i " + i );
		i = i >> 2;
		System.out.println( " i " + i );
		int a = 5;
		int b = 10;
		int c = a | b;
		int d = a & b;
		System.out.println( "a = " + a + "\nb = " + b +
							"\nc = " + c + "\nd = " + d);
	}
}