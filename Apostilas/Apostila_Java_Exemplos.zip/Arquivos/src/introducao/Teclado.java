/**
 * Title:        <p> Teclado
 * Description:  <p> Aplica��o demonstrando o uso da classe Keyboard
 * @author Jos� Maria Rodrigues Santos Junior / zemaria@infonet.com.br
 */

package introducao;

import util.Keyboard;

public class Teclado {

	public static void main (String[] args) {

		/* Lendo uma Vari�vel int */
		System.out.print("int : ");
		int i = Keyboard.readInt();
		System.out.println(i);

		/* Lendo uma Vari�vel float */
		System.out.print("float : ");
		float f = Keyboard.readFloat();
		System.out.println(f);

		/* Lendo uma Vari�vel char */
		System.out.print("char : ");
		char c = Keyboard.readChar();
		System.out.println(c);
	}
}