/**
 * Demonstra��o de um Application Java
 */

/* Defini��o do pacote */
package introducao;

/* Defini��o da classe */
public class Aplicacao {

	/* M�todo main, o qual define um application */
	public static void main(String[] args) {

		/* Escrevendo os par�metros passados na saida padrao */
		for (int i = 0; i < args.length; i++ ) {
			System.out.println( args[i] );
		}
    }
}