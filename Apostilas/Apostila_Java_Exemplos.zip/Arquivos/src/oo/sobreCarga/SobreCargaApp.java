/**
 * Classe com o objeto de demonstrar a sobrecarga de m�todos
 */

package oo.sobreCarga;

public class SobreCargaApp {
	public static void main (String[] args) {
		System.out.println( SobreCarga.media( 5, 7 ) );
		System.out.println( SobreCarga.media( 5, 7, 3 ) );
		System.out.println( SobreCarga.media( 8f, 2f ) );
		System.out.println( SobreCarga.media( 5.3f, 7.9f, 3.1f ) );
		/* Convers�o explicita pra float */
		System.out.println( SobreCarga.media( 8f, 4 ) );
	}

}