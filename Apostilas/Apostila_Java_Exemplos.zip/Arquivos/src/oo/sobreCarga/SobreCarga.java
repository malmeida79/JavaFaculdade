/**
 * Classe com o objeto de demonstrar a sobrecarga de m�todos
 */

package oo.sobreCarga;

public class SobreCarga {


	public static float media (int a, int b) {
		return ( a + b ) / 2;
	}

	public static float media (float a, float b) {
		return ( a + b ) / 2;
	}

	public static float media (int a, int b, int c) {
		return ( a + b + c ) / 3;
	}

	public static float media ( float a, float b, float c ) {
		return ( a + b + c ) / 3;
	}

	/* N�o � poss�vel ter um m�todo com apenas o tipo de retorno diferente */
/*
	public static double media ( float a, float b, float c ) {
		return ( a + b + c) / 3;
	}
*/
}