/**
 * Classe que tentar herdar de String, mas n�o � poss�vel, pois
 * String � final e n�o pode ser superclasse
 * Ser� gerado erro de compila��o
 */

package oo.classeFinal;

public class MinhaString /* extends String */ {

    public MinhaString() {
    }
}