/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.produto;

import oo.controleDeEstoque.util.Registro;

/**
 * Classe representando um produto
 * @see oo.controleDeEstoque.util.Registro
 */
public class Produto extends Registro {
	/** pre�o do produto */
	private float preco;
	/** estoque */
	private int estoque;
	/** estoque m�nimo */
	private int estoqueMin;

	/**
	 * Construtor da classe
	 * @param cod c�digo do produto
	 * @param desc descri��o do produto
	 * @param preco pre�o do produto
	 * @param estoque estoque do produto
	 * @param estoqueMin estoque m�nimo do produto
	 */
	public Produto (int cod, String desc,
			 		float preco, int estoque, int estoqueMin) {
		super(cod,desc);
		this.preco 		= preco;
		this.estoque	= estoque;
		this.estoqueMin	= estoqueMin;
	}

	/**
	 * atribui o pre�o do produto
	 * @param preco pre�o do produto
	 *
	 */
	public void preco (float preco) {
		this.preco = preco;
	}

	/**
	 * atribui o estoque do produto
	 * @param estoque estoque do produto
	 *
	 */
	public void estoque (int estoque) {
		this.estoque = estoque;
	}

	/**
	 * atribui o estoque m�nimo do produto
	 * @param estoqueMin estoque m�nimo do produto
	 *
	 */
	public void estoqueMin (int estoqueMin) {
		this.estoqueMin = estoqueMin;
	}

	/**
	 * obt�m o pre�o do produto
	 * @retunr pre�o do produto
	 *
	 */
	public float preco () {
		return preco;
	}

	/**
	 * obt�m o estoque do produto
	 * @return estoque do produto
	 *
	 */
	public int estoque () {
		return estoque;
	}

	/**
	 * obt�m o estoque m�nimo  do produto
	 * @return estoque m�nimo do produto
	 *
	 */
	public int estoqueMin () {
		return estoqueMin;
	}

	/**
	 * Retorna a representa��o string do objeto
	 * @return objeto como string
	 */
	public String toString () {
		return "[" + chave() + ", " + desc() + ", " + preco +
			   ", " + estoque + ", " + estoqueMin + "]";
	}
}