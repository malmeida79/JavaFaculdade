/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.produto;

import oo.controleDeEstoque.produto.Produto;
import oo.controleDeEstoque.util.Arquivo;

/**
 * Classe representando um cole��o de produtos
 * armazenado num vetor
 * @see oo.controleDeEstoque.produto.Produto
 */
public class Produtos extends Arquivo {

	/** Construtor */
	public Produtos() {
		super();
	}
}