/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.fornece;

import java.io.Serializable;

/**
 * Classe representando um fornecimento
 */
public class Fornece implements Serializable {
	/** c�digo do fornecedor */
	private int codForn;
	/** c�digo do produto */
	private int codPro;
	/** prazo de entrega */
	private int prazoEnt;
	/** pre�o */
	private float preco;

	/**
	 * Construtor da classe
	 * @param codForn c�digo do fornecedor
	 * @param codPro c�digo do produto
	 * @param prazo prazo de entrega
	 * @param preco preco do produto
	 */
	public Fornece (int codForn, int codPro, int prazo, float preco) {
		this.codForn 	= codForn;
		this.codPro 	= codPro;
		this.prazoEnt	= prazo;
		this.preco		= preco;
	}

	/**
	 * obtem o c�digo do fornecedor
	 * @return c�digo do fornecedor
	 */
	public int codForn () {
		return codForn;
	}

	/**
	 * obtem o c�digo do produto
	 * @return c�digo do produto
	 */
	public int codPro () {
		return codPro;
	}

	/**
	 * Compara com o c�digo do fornecedor
	 * @param codForn c�digo do fornecedor
	 * @return resultado da compara��o
	 */
	public boolean comparaCodFor(int codForn) {
		return (this.codForn == codForn);
	}

	/**
	 * Compara com o c�digo do produto
	 * @param codPro c�digo do produto
	 * @return resultado da compara��o
	 */
	public boolean comparaCodPro(int codPro) {
		return (this.codPro == codPro);
	}

	/**
	 * Compara com o c�digo do fornecedor e c�digo produto
	 * @param codForn do fornecedor
	 * @param codPro do produto
	 * @return resultado da compara��o
	 */
	public boolean comparaChave(int codForn, int codPro) {
		return (this.codForn == codForn && this.codPro == codPro);
	}

	/**
	 * Retorna a representa��o string do objeto
	 * @return objeto como string
	 */
	public String toString () {
		return "[" + codForn + "-" + codPro + "] \t= " +  prazoEnt +
			   "\t - " + preco + "\n";
	}
}