/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.fornece;

import java.util.Vector;
import oo.controleDeEstoque.util.Arquivo;

/**
 * Classe representando um cole��o de fornece
 * armazenado num vetor
 * @see controleDeEstoque.fornece.Fornece
 */
public class Fornecimentos extends Arquivo {
	/**
	 * Construtor da classe
	 */
	public Fornecimentos () {
		super();
	}

	/**
	 * Obtem a posi��o de um fornecimento no vetor
	 * @param codForn c�digo do fornecedor
	 * @param CodPro c�digo do produto
	 * @return posi��o onde a chave foi encontrada ou -1 se n�o encontrar
	 */
	private int procuraPosicao (int codForn, int CodPro) {
		int pos 	= 0;
		int i 		= 0;
		boolean achou 	= false;
		Fornece reg 	= null;
		while (!achou && i < v.size()) {
			reg = (Fornece) v.get(i);
			if (reg.comparaChave(codForn, CodPro)) {
				achou = true;
				pos = i;
			}
			i++;
		}
		if (achou) {
			return pos;
		} else {
			return -1;
		}
	}

	/**
	 * Obtem o fornecimento
	 * @param codForn c�digo do fornecedor
	 * @param codPro c�digo do produto
	 * @return fornecimento procurado ou null se n�o encontrar
	 */
	public Fornece pesquisa (int codForn, int codPro) {
		int pos = procuraPosicao(codForn, codPro);
		if (pos != -1) {
			return (Fornece) v.get(pos);
		} else {
			return null;
		}
	}

	/**
	 * Obtem o fornecimento
	 * @param reg fornecimento
	 * @return fornecimento procurado ou null se n�o encontrar
	 */
	public boolean insere (Fornece reg) {
		if (pesquisa(reg.codForn(), reg.codPro()) == null) {
			v.addElement(reg);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * remove o fornecimento
	 * @param codForn c�digo do fornecedor
	 * @param codPro c�digo do produto
	 * @return o sucesso da remo��o
	 */
	public boolean remove (int codForn, int codPro) {
		int pos = procuraPosicao(codForn, codPro);
		if (pos != -1) {
			v.remove(pos);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * remove todos fornecimentos para o produto
	 * @param codPro c�digo do produto
	 * @return quantos fornecimentos foram removidos
	 */
	public int removeProduto (int codPro) {
		int cont = 0;
		for (int i = v.size() - 1; i >= 0; i--) {
			Fornece fornece = (Fornece) v.get(i);
			if (fornece.comparaCodPro(codPro)) {
				v.removeElementAt(i);
				cont++;
			}
		}
		return cont;
	}

	/**
	 * remove todos fornecimentos para o fornecedor
	 * @param codFor c�digo do fornecedor
	 * @return quantos fornecimentos foram removidos
	 */
	public int removeFornecedor (int codFor) {
		int cont = 0;
		for (int i = v.size() - 1; i >=0 ; i--) {
			Fornece fornece = (Fornece) v.get(i);
			if (fornece.comparaCodFor(codFor)) {
				v.removeElementAt(i);
				cont++;
			}
		}
		return cont;
	}

	public String lista (char tipoPesq, int cod) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < v.size(); i++) {
			Fornece fornece = (Fornece) v.get(i);
			if (tipoPesq == 'F' ) {
				if (fornece.comparaCodFor(cod)) {
					sb.append(fornece);
				}
			} else if (tipoPesq == 'P') {
				if (fornece.comparaCodPro(cod)) {
					sb.append(fornece);
				}
			}
		}
		return sb.toString();
	}

	/**
	 * obt�m a lista de todos os fornecimentos de um fornecedor
	 * @param codFor c�digo do fornecedor
	 * @return lista de fornecimentos
	 */
	public String listaProdutos (int codFor) {
		return lista('F', codFor);
	}

	/**
	 * obt�m a lista de todos os fornecimentos de um produto
	 * @param codPro c�digo do produto
	 * @return lista de fornecimentos
	 */
	public String listaFornecedores (int codPro) {
		return lista('P', codPro);
	}
}