/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@unitnet.com.br / www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.util;

import java.io.Serializable;

public class Endereco implements Serializable {
	private String rua;
	private int num;
	private String bairro;
	private String comp;
	private String cep;

	public Endereco ( ) {
		super();
	}

	public Endereco (String rua, int num, String bairro,
					 String comp, String cep ) {
		this.rua 		= rua;
		this.num 		= num;
		this.bairro 	= bairro;
		this.comp 		= comp;
		this.cep 		= cep;
	}

	public String toString () {
		return "[" + rua + ", " + num + ", " + bairro + ", " + comp +
		       ", " + cep + "]";
	}

	public void rua (String rua) {
		this.rua = rua;
	}

	public void numero (int num) {
		this.num = num;
	}

	public void bairro (String bairro) {
		this.bairro = bairro;
	}

	public void complemento (String comp) {
		this.comp = comp;
	}

	public void cep (String cep) {
		this.cep = cep;
	}

	public String rua () {
		return  rua;
	}

	public int numero () {
		return  num;
	}

	public String bairro () {
		return  bairro;
	}

	public String complemento () {
		return  comp;
	}

	public String cep () {
		return  cep;
	}
}