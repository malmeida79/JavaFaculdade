/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@unitnet.com.br / www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.util;

import java.util.Vector;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.NotSerializableException;

public class Arquivo {
	protected Vector v;

	public Arquivo () {
		v = new Vector();
	}

	public Registro get (int i) {
		return (Registro) v.get(i);
	}

	public int size () {
		return v.size();
	}

	public String toString() {
		return "[" + v.size() + "]\n" + v.toString();
	}

	private int procuraPosicao (int chave) {
		int pos = 0;
		int i = 0;
		boolean achou = false;
		Registro reg = null;
		while (!achou && i < v.size()) {
			reg = (Registro) v.get(i);
			if (reg.comparaChave(chave)) {
				achou = true;
				pos = i;
			}
			i++;
		}
		if (achou) {
			return pos;
		} else {
			return -1;
		}
	}

	public Registro pesquisa (int chave) {
		int pos = procuraPosicao(chave);
		if (pos != -1) {
			return (Registro) v.get(pos);
		} else {
			return null;
		}
	}

	public boolean insere (Registro reg) {
		if (pesquisa(reg.chave()) == null) {
			v.addElement(reg);
			return true;
		} else {
			return false;
		}
	}

	public boolean remove (int chave) {
		int pos = procuraPosicao(chave);
		if (pos != -1) {
			v.remove(pos);
			return true;
		} else {
			return false;
		}
	}

	public String lista (String desc) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < v.size(); i++) {
			Registro reg = (Registro) v.get(i);
			if (reg.comparaDesc(desc)) {
				sb.append(reg + "\n");
			}
		}
		return sb.toString();
	}

	public void salvar (String arqNome) {
		File arq = new File(arqNome);
		try {
			FileOutputStream 	fos = new FileOutputStream(arq);
			ObjectOutputStream	oos = new ObjectOutputStream(fos);
			oos.writeObject(v);
			oos.flush();
			fos.close();
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo n�o encontrado : " +
							   e.getMessage());
		} catch (NotSerializableException e) {
			System.out.println("Objeto n�o serializ�vel : " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Erro de I/O : " + e.getMessage());
		}
	}

	public void abrir (String arqNome) {
		File arq = new File(arqNome);
		try {
			FileInputStream fis = new FileInputStream(arqNome);
			ObjectInputStream	ois = new ObjectInputStream(fis);
			v = (Vector) ois.readObject();
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo n�o encontrado");
		} catch (IOException e) {
			System.out.println("Erro de I/O");
		} catch (ClassNotFoundException e) {
			System.out.println("Classe n�o encontrada");
		}
	}
}
