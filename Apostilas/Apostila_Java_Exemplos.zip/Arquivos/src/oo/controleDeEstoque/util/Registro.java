/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@unitnet.com.br / www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.util;

import java.io.Serializable;

public class Registro implements Serializable {
	private int chave;
	private String desc;

	public Registro (int chave) {
		this.chave	= chave;
	}

	public Registro (int chave, String desc) {
		this.chave	= chave;
		this.desc	= desc;
	}

	public boolean comparaChave (int chave) {
		return this.chave == chave;
	}

	public boolean comparaDesc (String desc) {
		return this.desc.toUpperCase().startsWith(desc.toUpperCase());
	}

	public void chave (int chave) {
		this.chave = chave;
	}

	public int chave () {
		return chave;
	}

	public void desc (String desc) {
		this.desc = desc;
	}

	public String desc () {
		return desc;
	}
}