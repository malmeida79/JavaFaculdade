/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */

package oo.controleDeEstoque.cliente;

import oo.controleDeEstoque.util.Registro;
import oo.controleDeEstoque.util.Endereco;

/**
 * Classe representando um cliente
 * @see oo.controleDeEstoque.util.Registro
 * @see oo.controleDeEstoque.util.Endereco
 * @see oo.controleDeEstoque.cliente.DataAniversario
 */
public class Cliente extends Registro {
	/** data de anivers�rio */
	public	DataAniversario aniv;
	/** telefone */
	private String fone;
	/** observacao */
	private String obs;
	/** endere�o */
	public  Endereco end;

	/**
	 * Construtor da classe
	 * @param cod c�digo do cliente
	 * @param nome nome do cliente
	 * @param end endere�o do cliente
	 * @param aniv data de anivers�rio
	 * @param fone telefone
	 * @param obs observa��o
	 */
	public Cliente (int cod, String nome, Endereco end,
					DataAniversario aniv,
					String fone, String obs) {

		super(cod,nome);
		this.end 	= end;
		this.aniv 	= aniv;
		this.fone 	= fone;
	}

	/**
	 * atribui o nome
	 * @param nome nome do cliente
	 */
	public void nome (String nome) {
		desc(nome);
	}

	/**
	 * obtem o nome
	 * @return nome do cliente
	 */
	public String nome () {
		return super.desc();
	}

	/**
	 * obtem a data de anivers�rio
	 * @return data de anivers�rio
	 * @see controleDeEstoque.cliente.DataAniversario
	 */
	public DataAniversario dataAniversario () {
		return aniv;
	}

	/**
	 * Retorna a representa��o string do objeto
	 * @return objeto como string
	 */
	public String toString () {
		return "[" + chave() + ", " + desc() + ", " + end + ", " + aniv +
				", " + fone + "]";
	}
}