/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.cliente;

import java.io.Serializable;

/**
 * Classe representando data de anivers�rio
 */
public class DataAniversario implements Serializable {
	/** dia */
	private int dia;
	/** m�s */
	private int mes;

	/**
	 * Construtor
	 * @param dia dia do anivers�rio
	 * @param mes m�s do anivers�rio
	 */
	public DataAniversario (int dia, int mes) {
		this.dia = dia;
		this.mes = mes;
	}

	/**
	 * atribui o dia
	 * @param dia dia do anivers�rio
	 */
	public void dia (int dia) {
		this.dia = dia;
	}

	/**
	 * obtem o o dia
	 * @return dia do anivers�rio
	 */
	public int dia () {
		return dia;
	}

	/**
	 * atribui o m�s
	 * @param mes m�s do anivers�rio
	 */
	public void mes (int mes) {
		this.mes = mes;
	}

	/**
	 * obtem o o m�s
	 * @return m�s do anivers�rio
	 */
	public int mes () {
		return mes;
	}

	/**
	 * compara com m�s de anivers�rio
	 * @param mes m�s a ser comparado
	 * @return resultado da compara��o
	 */
	public boolean comparaMes (int mes) {
		return this.mes == mes;
	}

	/**
	 * Retorna a representa��o string do objeto
	 * @return objeto como string
	 */
	public String toString() {
		return (dia + "/" + mes);
	}
}