/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.cliente;

import oo.controleDeEstoque.util.Arquivo;

/**
 * Classe representando um cole��o de clientes
 * armazenado num vetor
 * @see oo.controleDeEstoque.cliente.Cliente
 */
public class Clientes extends Arquivo {

	/** Construtor */
	public Clientes() {
		super();
	}

	/**
	 * rela��o de aniversriantes do m�s
	 * @param mes m�s
	 * @return String com a rela��o de aniversariante do m�s
	 */
	public String aniversariantes(int mes) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < size(); i++ ) {
			Cliente cli = (Cliente) get(i);
			if (cli.dataAniversario().comparaMes(mes)) {
				sb.append(cli + "\n");
			}
		}
		return sb.toString();
	}
}