/**
 * @author 	Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 * @version	1.0.0
 *
 * Aplica��o para testar as classes importadas
 * As quais implemtentam o cl�ssico modelo Cliente/Fornecedor/Fornece/Produto
 */

package oo.controleDeEstoque;

import java.util.Random;

import oo.controleDeEstoque.cliente.DataAniversario;
import oo.controleDeEstoque.cliente.Cliente;
import oo.controleDeEstoque.cliente.Clientes;
import oo.controleDeEstoque.fornecedor.Fornecedor;
import oo.controleDeEstoque.fornecedor.Fornecedores;
import oo.controleDeEstoque.produto.Produto;
import oo.controleDeEstoque.produto.Produtos;
import oo.controleDeEstoque.fornece.Fornece;
import oo.controleDeEstoque.fornece.Fornecimentos;
import oo.controleDeEstoque.util.Endereco;


public class CliForPro {
	/** M�todo main da aplica��o */
	public static void main (String[] args) {
		/* Inserindo e testando 10 clientes */
		testaClientes("clientes.dat", 20);
		/* Inserindo e testando 10 fornecedores */
		testaFornecedores("fornecedores.dat", 20);
		/* Inserindo e testando 10 produtos */
		testaProdutos("produtos.dat", 100);
		/* Inserindo e testando 200 fornecimentos */
		testaFornecimentos("fornecimentos.dat",200);
	}

	/** Teste das classes Cliente, Clientes, Endere�o e DataNascmiento */
	public static void testaClientes (String arq, int quant ) {
		Cliente cliente;
		Endereco end;
		Clientes clientes = new Clientes();
		clientes.abrir(arq);
		System.out.println("Clientes lidos" + clientes);
		DataAniversario aniv;
		Random r = new Random();
		for (int i = 1; i <= quant; i++) {
			end = new Endereco("Rua_"+i,i,"Bairro_"+i,"","");
			int dia = r.nextInt(31);
			int mes = r.nextInt(12);
			aniv = new DataAniversario(dia,mes);
			cliente = new Cliente(i,"Cliente_" + i,end,aniv,"","");
			clientes.insere(cliente);
		}
		for (int i = 1; i <= quant/2; i++) {
			clientes.remove(r.nextInt(quant));
		}
		System.out.println("Clientes" + clientes);
		clientes.salvar(arq);
	}

	/** Teste das classes Fornecedor, Fornecedores, Endere�o */
	public static void testaFornecedores (String arq, int quant ) {
		Fornecedor fornecedor;
		Endereco end;
		Fornecedores fornecedores = new Fornecedores();
		fornecedores.abrir(arq);
		System.out.println("Fornecedores lidos" + fornecedores);
		Random r = new Random();
		for (int i = 1; i <= quant; i++) {
			end = new Endereco("Rua_"+i,i,"Bairro_"+i,"","");
			fornecedor = new Fornecedor(i,"Fornecedor_" + i,end);
			fornecedores.insere(fornecedor);
		}
		System.out.println("Fornecedores" + fornecedores);
		fornecedores.salvar(arq);
	}

	/** Teste das classes Produto, Produtos */
	public static void testaProdutos (String arq, int quant ) {
		Produto produto;
		Produtos produtos = new Produtos();
		produtos.abrir(arq);
		System.out.println("Produtos lidos" + produtos);
		Random r = new Random();
		for (int i = 1; i <= quant; i++) {
			produto = new Produto(i,"Produto_" + i, r.nextFloat() * 1000,
								  r.nextInt(100), r.nextInt(20));
			produtos.insere(produto);
		}
		System.out.println("Produtos" + produtos);
		produtos.salvar(arq);
	}

	/** Teste das classes Fornece e Fornecimentos */
	public static void testaFornecimentos (String arq, int quant ) {
		Fornece fornece;
		Fornecimentos fornecimentos = new Fornecimentos();
		fornecimentos.abrir(arq);
		System.out.println("Fornecimentos lidos \n" + fornecimentos);
		Random r = new Random();
		/* Inserindo fornecimentos */
		for (int i = 1; i <= quant; i++) {
			fornece = new Fornece(r.nextInt(20),r.nextInt(100),
								  r.nextInt(160),r.nextFloat() * 1000);
			fornecimentos.insere(fornece);
		}
		for (int i = 1; i <= quant/2; i++) {
			fornecimentos.remove(r.nextInt(quant/10),r.nextInt(quant/10));
		}
		System.out.println("Listanto Produtos do Fornecedor 13");
		System.out.println(fornecimentos.listaProdutos(13));
		System.out.print("Removendo Fornecedor 13 : ");
		System.out.println(fornecimentos.removeFornecedor(13));
		System.out.println("Listanto Fornecedores do Produto 13");
		System.out.println(fornecimentos.listaFornecedores(13));
		System.out.print("Removendo Produto 13 	: ");
		System.out.print(fornecimentos.removeProduto(13));
		System.out.println();
		System.out.println("Fornecimentos \n" + fornecimentos);
		fornecimentos.salvar(arq);
	}
}