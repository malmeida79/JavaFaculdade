/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.fornecedor;

import oo.controleDeEstoque.util.Endereco;
import oo.controleDeEstoque.util.Registro;

/**
 * Classe representando um fornecedor
 * @see oo.controleDeEstoque.util.Registro
 * @see oo.controleDeEstoque.util.Endereco
 */
public class Fornecedor extends Registro {
	/** endere�o */
	public  Endereco end;
	/**
	 * Construtor da classe
	 * @param cod c�digo do fornecedor
	 * @param nome nome do fornecedor
	 * @param end endere�o do fornecedor
	 */
	public Fornecedor (int cod, String nome, Endereco end) {
		super(cod,nome);
		this.end 	= end;
	}

	/**
	 * Retorna a representa��o string do objeto
	 * @return objeto como string
	 */
	public String toString () {
		return "[" + chave() + ", " + desc() + ", " + end + "]";
	}
}