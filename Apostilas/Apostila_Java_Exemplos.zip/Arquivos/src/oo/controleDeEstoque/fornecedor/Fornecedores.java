/**
 * @author Jos� Maria Rodrigues Santos Junior
 * zemaria@infonet.com.br - www.unit.br/zemaria
 *
 */
package oo.controleDeEstoque.fornecedor;

import oo.controleDeEstoque.util.Arquivo;

/**
 * Classe representando um cole��o de fornecedores
 * armazenado num vetor
 * @see oo.controleDeEstoque.fornecedor.Fornecedor
 */
public class Fornecedores extends Arquivo {

	/** Construtor */
	public Fornecedores() {
		super();
	}
}