/**
 * Classe para demonstrar membros est�ticos
 */

package oo.membrosEstaticos;

public class MembrosEstaticos {

	/* Atributo est�tico */
	private static int contObjetos = 0;

	public MembrosEstaticos () {
		contObjetos++;
	}

	/* M�todo est�tico */
	public static void numeroDeOjetos () {
		System.out.println("N�mero de objetos instanciados : " + contObjetos);
	}
}