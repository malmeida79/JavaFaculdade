/**
 * Application para demonstrar membros est�ticos
 */

package oo.membrosEstaticos;

public class MembrosEstaticosApp {

	public static void main (String[] args) {
		for (int i = 1; i <= 10; i++) {
			MembrosEstaticos me = new MembrosEstaticos();
			/* chamada ao m�todo est�tico */
			me.numeroDeOjetos();
		}

		/* chamada ao m�todo est�tico */
		MembrosEstaticos.numeroDeOjetos();
	}
}