package oo.tratamentoDeExcecoes.arrayDeInteiros;

public class DivideByZeroException extends ArithmeticException {

	public DivideByZeroException() {
		super("Divis�o por zero.");
	}

	public DivideByZeroException(String msg) {
		super(msg);
	}
}