/**
 * Classe representando um array de inteiros, com o objetivo de demonstrar
 * Tratamento de Exce��es
 */

package oo.tratamentoDeExcecoes.arrayDeInteiros;

import java.lang.NegativeArraySizeException;
import java.lang.ArrayIndexOutOfBoundsException;
import java.lang.ArithmeticException;


public class ArrayDeInteiros {

	private int[] array;
	int posNovo ;

	public ArrayDeInteiros() {
		posNovo = 0;
		array = new int[10];
	}

	/* Obrigando o usu�rio do m�todo a capturar e tratar a exce��o */
	public ArrayDeInteiros( int tam ) throws NegativeArraySizeException {
		posNovo = 0;
		array = new int[tam];
	}

	public ArrayDeInteiros( int[] array ) {
		this.array = array;
	}

	/* Personalizando a mensagem da exce��o e lan�ando-a */
	public void insere ( int pos, int valor )
				throws ArrayIndexOutOfBoundsException {
		try {
			array[pos] = valor;
		} catch ( ArrayIndexOutOfBoundsException e ) {
			String msg =  " Erro-> Posi��o inv�lida do array : " + pos;
			throw new ArrayIndexOutOfBoundsException(msg);
		}
	}

	/* Personalizando a mensagem da exce��o e lan�ando-a */
	public void insere ( int valor )
				throws ArrayIndexOutOfBoundsException {
		try {
			array[posNovo] = valor;
			posNovo++;
		} catch ( ArrayIndexOutOfBoundsException e ) {
			String msg = e.getMessage() +
			" Erro-> quantidade m�xima de elementos encontrada " + array.length;
			throw new ArrayIndexOutOfBoundsException(msg);
		}
	}

	/* Capturando e tratando a exce��o */
	public float media (int posInicial, int posFinal)
						throws ArrayIndexOutOfBoundsException,
							   ArithmeticException {
		float soma = 0;
		float media = 0;
		int quantElementos = (posFinal - posInicial + 1);

		if ( quantElementos == 0 ) {
			throw new DivideByZeroException();
		}

		try {
			for (int i = posInicial; i <= posFinal; i ++) {
				soma += array[i];
			}
			media = ( soma / quantElementos );
		} catch (ArrayIndexOutOfBoundsException e1 ) {
			String msg = "Erro: Intervalo[" + posInicial + "..." + posFinal +
						 "] Inv�lido";
			throw new ArrayIndexOutOfBoundsException(msg);
		} catch ( ArithmeticException e2 ) {
			String msg = "Divisao por zero";
			throw new ArrayIndexOutOfBoundsException(msg);
		}

		return media;
	}

	public float media () {
		try {
			return media(0, array.length - 1);
		} catch ( DivideByZeroException e ) {
			System.out.println("Erro :" + e.getMessage());
		} finally {
			return 0;
		}
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for (int i = 0; i < (array.length - 1); i ++) {
			sb.append(array[i] + ",");
		}

		/* Caso o tamanho do array seja 0 */
		try {
			sb.append(array[array.length - 1]);
		} catch (ArrayIndexOutOfBoundsException e) {
			/* */
		};
		sb.append("]");

		return sb.toString();
	}

	public void escreve () {
		System.out.println( toString() );
	}

	/* Exemplo de throws com uma exce��o que obriga o seu tratamento*/
	public void preenche (int valor) throws Exception {
		for (int i = 0; i < array.length; i ++) {
			array[i] = valor;
		}
	}
}