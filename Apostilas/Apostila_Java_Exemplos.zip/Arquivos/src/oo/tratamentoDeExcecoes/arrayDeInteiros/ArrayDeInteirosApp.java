/**
 * Application demonstrando o uso da classe ArrayDeInteiros
 */

package oo.tratamentoDeExcecoes.arrayDeInteiros;

public class ArrayDeInteirosApp {

    public static void main(String[] args) {
		int[] n = {6,1,2,3,4,5,6,7,8,9} ;

		ArrayDeInteiros inteiros = new ArrayDeInteiros( n );

		inteiros.escreve();
		try {
			inteiros.insere(0,0);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println( e.getMessage() );
		}
		inteiros.escreve();
		try {
			inteiros.insere(-1,0);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println( e.getMessage() );
		}
		try {
			System.out.println(inteiros.media(2,1));
		} catch ( Exception e ) {
			System.out.println( e.getMessage() );
		}

		try {
			inteiros.preenche(5);
		} catch (Exception e) {}
		inteiros.escreve();
    }
}