/**
 * Classe Funcoinario
 * Subclasse da classe abstrata Pessoa
 */

package oo.classeAbstrata;

public class Funcionario extends Pessoa {

	private String cargo;
	private float salario;

	public Funcionario (String mat, String nome, String dNasc,
						char sexo, String cargo, float sal) {
		super(mat, nome, dNasc, sexo);
		this.cargo = cargo;
		this.salario = sal;
	}

	public void matricula (String mat) {
		this.id(mat);
	}

	public void cargo (String cargo) {
		this.cargo = cargo;
	}

	public void salario (float salario) {
		this.salario = salario;
	}

	public String matricula () {
		return this.id();
	}

	public String cargo () {
		return cargo;
	}

	public float salario () {
		return salario;
	}

	public String toString () {
		return("Funcionario : " + super.toString() +
			   "  |" + cargo + " | " + salario);
	}
}