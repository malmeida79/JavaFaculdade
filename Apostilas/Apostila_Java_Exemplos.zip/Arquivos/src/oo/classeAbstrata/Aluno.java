/**
 * Classe Aluno
 * Subclasse da classe abstrata Pessoa
 */

package oo.classeAbstrata;

import java.text.DecimalFormat;

public class Aluno extends Pessoa implements SituacaoAcademica {

	private String matricula;
	private String curso;
	private float[] notas;
	private int faltas;

	public Aluno (String mat, String nome, String dNasc,
						char sexo, String curso) {
		super(mat, nome, dNasc, sexo);
		this.curso = curso;
		notas = new float[3];
	}

	public void matricula (String mat) {
		this.id(mat);
	}

	public void curso (String curso) {
		this.curso = curso;
	}

	public String matricula () {
		return this.id();
	}

	public String curso () {
		return curso;
	}

	public String toString () {
		DecimalFormat df = new DecimalFormat( "0.0" );

		return("Aluno : " + super.toString() + " | " + curso + " | " +
			   nota1() + " | " + nota2() + " | " + nota3() + " | " + faltas() +
			   " | " + df.format(media()) + " | " + situacaoFinal());
	}

	public String situacaoFinal () {
		if ( faltas() > FALTAS) {
			return RF;
		} else if ( media() < MEDIA) {
			return RM;
		} else {
			return AP;
		}
	}

	public float media () {
		float med = ( notas[0] + notas[1] + notas[2] ) / 3;

		return med;
	}

	public int faltas () {
		return faltas;
	}

	public void faltas (int f) {
		faltas = f;
	}

	public void notas (float n1, float n2, float n3) {
		nota1(n1);
		nota2(n2);
		nota3(n3);
	}

	public void nota1(float n){
		notas[0] = n;
	}

	public void nota2(float n){
		notas[1] = n;
	}

	public void nota3(float n){
		notas[2] = n;
	}
	public float nota1(){
		return notas[0];
	}

	public float nota2(){
		return notas[1];
	}

	public float nota3(){
		return notas[2];
	}
}