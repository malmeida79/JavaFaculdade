/**
 * Classe asbstrata pessoa
 */

package oo.classeAbstrata;

public abstract class Pessoa {

	private String identificacao;
	private String nome;
	private String dataNascimento;
	private char sexo;

	public Pessoa (String id, String nome, String datNasc, char sexo) {
		this.nome = nome;
		this.dataNascimento = datNasc;
		this.sexo = sexo;
	}

	public void id (String id) {
		this.identificacao = id;
	}

	public void nome (String nome) {
		this.nome = nome;
	}

	public void dataNascimento (String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public void sexo (char sexo) {
		this.sexo = sexo;
	}

	public String id () {
		return identificacao;
	}

	public String nome () {
		return nome;
	}

	public String dataNascimento () {
		return dataNascimento;
	}

	public char sexo () {
		return sexo;
	}

	public String toString () {
		return(nome + " | " + dataNascimento + " | " + sexo);
	}
}