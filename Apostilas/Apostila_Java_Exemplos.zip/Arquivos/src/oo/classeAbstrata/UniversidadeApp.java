/**
 * Application para demonstar o uso de classes abstratas
 */

package oo.classeAbstrata;

public class UniversidadeApp {

	public static void main(String[] args) {
		Funcionario funcionario;
		Aluno aluno;
		funcionario = new Funcionario("999999", "Josias",
									  "31/07/1972", 'M', "Professor", 5000);
		aluno = new Aluno("111111", "Josiana", "10/02/1980",'F',"Turismo");
		System.out.println(funcionario);
		System.out.println(aluno);

		/* Alinha abaixo ir� gerar um erro de compila��o, pois
		 * classes abstratas n�o podem ser estanciadas
		 */
//		Pessoa pessoa = new Pessoa("000000", "Pessoa", "31/07/1972", 'M');

		aluno.notas(7.5f, 9.3f, 3.9f);
		aluno.faltas(15);
		System.out.println(aluno.toString());
	}
}