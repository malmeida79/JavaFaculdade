/**
 * Interface modelando as opera��es de verifica��o da situa��o final
 * de alunos
 */

package oo.classeAbstrata;

public interface SituacaoAcademica {
	public static final float MEDIA = 5.0f;
	public static final int FALTAS = 18;
	public static final String AP = "Aprovado";
	public static final String RF = "Reprovado por Falta";
	public static final String RM = "Reprovado por M�dia";

	public abstract void faltas (int faltas);
	public abstract void notas (float n1, float n2, float n3);
	public abstract void nota1 (float n);
	public abstract void nota2 (float n);
	public abstract void nota3 (float n);

	public abstract String situacaoFinal ();
	public abstract float media ();
	public abstract int faltas ();
	public abstract float nota1 ();
	public abstract float nota2 ();
	public abstract float nota3 ();

}