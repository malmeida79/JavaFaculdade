/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Classe Modelando uma cole��o de Objetos
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public class Cole��o {
	/** array de Objects, permitindo armazenar qualquer objeto */
	private Object[] itens;
	/** Posi��o onde o novo item ser� inserido */
	private int posNovoItem = 0;

	/**
	 * Construtor
	 * @param quant n�mero m�ximos de elementos a serem armazenados
	 */

	public Cole��o(int quant) {
		itens = new Object[quant];
	}

	/**
	 * Insere um novo item, at� o m�ximo permitido
	 * @param obj Objeto a ser inserido
	 * @exception ArrayIndexOutOfBoundsException
	 * 			  Caso o limite m�ximo seja ultrapassado
	 */
	public void insere (Object obj) throws ArrayIndexOutOfBoundsException {
		try {
			itens[posNovoItem] = obj;
			posNovoItem++;
		} catch (ArrayIndexOutOfBoundsException e) {
			String msg = "N�mero m�ximo de itens atingido";
			throw new ArrayIndexOutOfBoundsException( msg );
		}
	}

	/**
	 * Insere, de forma circular, um novo item. Ou seja, quando o final do
	 * array for atingido, os novos objetos ser�o inserido no in�cio
	 * @param obj Objeto a ser inserido
	 */
	public void insereCircular (Object obj) {
		itens[posNovoItem] = obj;
		posNovoItem++;
		if ( posNovoItem == itens.length ) {
		  posNovoItem = 0;
		}
	}

	/**
	 * Retorno o objeto armazenado em uma determinada posi��o
	 * @param pos posi��o do objeto a ser retornado
	 * @return objeto na posi��o especificada
	 * @exception ArrayIndexOutOfBoundsException
	 * 			  Caso a posi��o seja inv�lida
	 */
	public Object item (int pos) throws ArrayIndexOutOfBoundsException {
		try {
			return itens[pos];
		} catch (ArrayIndexOutOfBoundsException e) {
			String msg = "Posi��o Inv�lida";
			throw new ArrayIndexOutOfBoundsException( msg );
		}
	}

	/**
	 * Retorna uma <code>String</code> representando toda a cole��o.
	 * Para isso chama o m�todo <code>toString()</code> de cada objeto
	 * armazenado. Dessa forma, os objetos a serem armazenados devem redefinir
	 * o m�todo <code>toString</code>, caso contr�rio o m�todo
	 * <code>toString</code> herdado de "Object" ser� chamado.
	 * @return String representando a Cole��o
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < posNovoItem; i++) {
			sb.append(itens[i].toString() + "\n");
		}

		return sb.toString();
	}
}