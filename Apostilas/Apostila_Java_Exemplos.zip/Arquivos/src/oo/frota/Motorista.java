/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Classe Modelando um Motorista
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public class Motorista {
	private String matricula;
	private String nome;
	private boolean correcaoVisual;
	private String validadeHabilita��o;
	private char tipoHabilita��o;

	public Motorista(String matricula, String nome,
					 boolean correcaoVisual,
					 String validadeHabilita��o,
					char tipoHabilita��o) {
		this.matricula = matricula;
		this.nome = nome;
		this.correcaoVisual = correcaoVisual;
		this.validadeHabilita��o = validadeHabilita��o;
		this.tipoHabilita��o = tipoHabilita��o;
	}

	public String toString() {
		String msg = "Motorista [" + nome + "]";

		return msg;
	}
}