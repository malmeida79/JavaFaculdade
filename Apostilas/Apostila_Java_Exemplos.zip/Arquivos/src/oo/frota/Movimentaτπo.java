/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Classe Modelando uma Movimenta��o de Ve�culo
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public class Movimenta��o {
	private int kmInicial;
	private int kmFinal;
	private String data;
	public Motorista motorista;

	public Movimenta��o(Motorista motorista, int kmInicial, int kmFinal,
						String data ) {
		this.motorista = motorista;
		this.kmInicial = kmInicial;
		this.kmFinal = kmFinal;
		this.data = data;
	}

	public String toString() {
		String msg = "Movimenta��o [" + motorista + " | " + data + " | " +
					 kmInicial + " | " + kmFinal + "]";

		return msg;
	}
}