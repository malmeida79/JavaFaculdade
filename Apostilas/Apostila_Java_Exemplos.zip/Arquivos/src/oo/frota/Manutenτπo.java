/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Classe Modelando uma Manute��o de Ve�culo
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public class Manuten��o {
	private String descri��o;
	private String data;

	/**
	 * Construtor
	 */
	public Manuten��o(String descri��o, String data) {
		this.descri��o = descri��o;
		this.data = data;
	}

	/**
	 * Retorn uma String representando a manuten��o
	 * @return String representando a manuten��o
	 */
	public String toString() {
		return "Manuten��o [" + descri��o + " | " + data + "]";
	}
}