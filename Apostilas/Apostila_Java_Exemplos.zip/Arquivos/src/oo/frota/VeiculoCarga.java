/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Classe Modelando um Ve�culo de Carga
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public class VeiculoCarga extends Veiculo {

	private int carga;
	public VeiculoCarga (String placa, String chassi, String marca,
						 String modelo, Revendedor rev,
						 int carga) {
		super(placa, chassi, marca, modelo, rev);
		this.carga = carga;
	}

	public String toString() {
		StringBuffer msg = new StringBuffer();
		msg.append("Ve�culo Carga [" + placa() + " | " +
				   carga + "]\n");
		msg.append("Movimenta��es:\n");
		msg.append(movimenta��es);
		msg.append("Manuten��es:\n");
		msg.append(manuten��es);

		return msg.toString();
	}
}