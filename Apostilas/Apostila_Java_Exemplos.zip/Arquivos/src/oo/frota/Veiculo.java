/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Classe Modelando um Ve�culo
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public abstract class Veiculo {
		private String placa;
		private String chassi;
		private String marca;
		private String modelo;
		public Revendedor revendedor;
		public Cole��o manuten��es;
		public Cole��o movimenta��es;

	public Veiculo(String placa, String chassi, String marca, String modelo,
				   Revendedor rev) {
		this.placa = placa;
		this.chassi = chassi;
		this.marca = marca;
		this.modelo = modelo;
		this.revendedor = rev;
		manuten��es = new Cole��o(5);
		movimenta��es = new Cole��o(5);
	}

	public void placa (String placa) {
		this.placa = placa;
	}

	public void chassi (String chassi) {
		this.chassi = chassi;
	}

	public void marca (String marca) {
		this.marca = marca;
	}

	public void modelo (String modelo) {
		this.modelo = modelo;
	}

	public void revendedor (Revendedor revendedor) {
		this.revendedor = revendedor;
	}

	public String placa () {
		return placa;
	}

	public String chassi () {
		return chassi;
	}

	public String marca () {
		return marca;
	}

	public String modelo () {
		return modelo;
	}

	public Revendedor revendedor () {
		return revendedor;
	}

	public abstract String toString();
}