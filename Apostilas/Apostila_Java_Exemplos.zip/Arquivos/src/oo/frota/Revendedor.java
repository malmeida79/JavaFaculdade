/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Classe Modelando um Revendedor
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public class Revendedor {
	private String nome;
	private String endere�o ;
	private String telefone;

	public Revendedor(String nome, String endere�o, String telefone) {
		this.nome = nome;
		this.endere�o = endere�o;
		this.telefone = telefone;
	}

	public String toString() {
		String msg = "Revendedor [" + nome + " | " + telefone + "]";

		return msg;
	}
}