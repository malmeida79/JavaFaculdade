/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Classe Modelando um Ve�culo de Passeio
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public class VeiculoPasseio extends Veiculo {
	int velocidadeMaxima;
	int passageiros;

	public VeiculoPasseio (String placa, String chassi, String marca,
						   String modelo, Revendedor rev,
						   int vMax, int pass) {
		super(placa, chassi, marca, modelo, rev);
		this.velocidadeMaxima = vMax;
		this.passageiros = pass;
	}

	public String toString() {
		StringBuffer msg = new StringBuffer();
		msg.append("Ve�culo Passeio [" + placa() + " | " +
				   velocidadeMaxima + " | " + passageiros + "]\n");
		msg.append("Movimenta��es:\n");
		msg.append(movimenta��es);
		msg.append("Manuten��es:\n");
		msg.append(manuten��es);

		return msg.toString();
	}
}