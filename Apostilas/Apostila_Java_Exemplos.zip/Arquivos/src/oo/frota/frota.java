/**
 * Title:        <p>Aplica��o Frota
 * Description:  <p>Application demonstrando a hierarquia de classe frota
 * Company:      <p>Infonet
 * @author Jos� Maria Rodrigues Santos Junior
 * @version 1.0
 */

package oo.frota;

public class frota {

	public static void main(String[] args) {

//		Cole��o revendedores = new Cole��o(5);
		Cole��o revendedores = new Cole��o(5);
		Cole��o veiculos = new Cole��o(10);
		Cole��o motoristas = new Cole��o(5);
		motoristas.insere(new Motorista("0001", "Motorista A", true,
										"21/02/2001", 'A'));
		motoristas.insere(new Motorista("0002", "Motorista B", true,
										"21/02/2002", 'B'));
		motoristas.insere(new Motorista("0003", "Motorista C", true,
										"21/02/2003", 'C'));
		System.out.println(motoristas);

		revendedores.insere(new Revendedor("Saman", "End. da Saman",
										 "Telefone da Samam"));
		revendedores.insere(new Revendedor("Cimavel", "End. da Cimavel",
										 "Telefone da Cimavel"));
		revendedores.insere(new Revendedor("Transvemaza", "End. da Transvemaza",
										 "Telefone da Transvemaza"));

		System.out.println(revendedores.toString());

		veiculos.insere(new
			VeiculoPasseio("HZD-5273", "88309934-0449", "Wolkswagem","Gol",
						   (Revendedor) revendedores.item(0), 200, 4));

		Veiculo v = (Veiculo) veiculos.item(0);
		Movimenta��o mov;
		mov = new Movimenta��o((Motorista) motoristas.item(0),
											1000, 2000,"07/07/2000");
		v.movimenta��es.insereCircular(mov);
		mov = new Movimenta��o((Motorista) motoristas.item(1),
											2000, 2500,"09/07/2000");
		v.movimenta��es.insereCircular(mov);
		mov = new Movimenta��o((Motorista) motoristas.item(0),
											2500, 4500,"17/07/2000");
		v.movimenta��es.insereCircular(mov);

		System.out.println(veiculos);

		veiculos.insere(new
			VeiculoCarga("HZE-1973", "112345-998", "Ford","F1000",
						   (Revendedor) revendedores.item(0), 2000));

		v = (Veiculo) veiculos.item(1);
		mov = new Movimenta��o((Motorista) motoristas.item(1),
											1000, 2000,"010/07/2000");
		v.movimenta��es.insereCircular(mov);
		mov = new Movimenta��o((Motorista) motoristas.item(2),
											2000, 2500,"28/07/2000");
		v.movimenta��es.insereCircular(mov);
		mov = new Movimenta��o((Motorista) motoristas.item(0),
											2500, 4500,"30/07/2000");
		v.movimenta��es.insereCircular(mov);

		Manuten��o manut;
		manut = new Manuten��o("Pneu furado", "10/10/1999");
		v.manuten��es.insereCircular(manut);

		System.out.println(veiculos);
	}
}