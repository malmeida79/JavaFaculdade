package br.gov.se.aracaju.figuras;

public class Circulo extends Figura {

  private Ponto centro;
  private int raio;

  public Circulo(int x, int y, int raio) {
    setCentro(new Ponto(x,y));
    setRaio(raio);
  }

  public void setCentro(Ponto value) {
    centro = value;
  }
  public Ponto getCentro(){
    return centro;
  }

  public void setRaio(int value) {
    raio = value;
  }
  public int getRaio(){
    return raio;
  }

  public String toString () {
    return "[" + getCentro() + "," + getRaio() + "]";
  }
  public void desenhe() {
    System.out.println("Desenhando o Circulo: " + toString());
  }
}