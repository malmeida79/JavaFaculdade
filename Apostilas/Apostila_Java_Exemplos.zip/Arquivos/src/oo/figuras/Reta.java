package br.gov.se.aracaju.figuras;

public class Reta extends Figura {

  private Ponto ponto1;
  private Ponto ponto2;

  public Reta(Ponto p1, Ponto p2) {
    setPonto1(p1);
    setPonto2(p2);
  }

  public Reta(int x1, int y1, int x2, int y2) {
    setPonto1(new Ponto(x1,y1));
    setPonto2(new Ponto(x2,y2));
  }

  public void setPonto1 (Ponto value) {
    ponto1 = value;
  }
  public Ponto getPonto1() {
    return ponto1;
  }

  public void setPonto2 (Ponto value) {
    ponto2 = value;
  }
  public Ponto getPonto2() {
    return ponto2;
  }

  public String toString() {
    return "[" + super.toString() + getPonto1() + "," + getPonto2() + "]";
  }

  public void desenhe() {
    System.out.println("Desenhando a Reta: " + toString());
  }
}