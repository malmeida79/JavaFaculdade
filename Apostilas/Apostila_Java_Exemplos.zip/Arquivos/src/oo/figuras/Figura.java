package br.gov.se.aracaju.figuras;

public abstract class Figura {

  public static final int BRANCO = 0;
  public static final int AMARELO = 1;
  public static final int AZUL = 2;
  public static final int PRETO = 3;

  private int corLinha;
  private int espessuraLinha;
  private int corFundo;

  public Figura() {
    this(PRETO, BRANCO, 1);
  }

  public Figura(int corLinha, int espessuraLinha, int corFundo) {
    setCorFundo(corFundo);
    setCorLinha(corLinha);
    setEspessuraLinha(espessuraLinha);
  }

  public void setCorLinha(int value) {
    corLinha = value;
  }
  public int getCorLinha() {
    return corLinha;
  }

  public void setEspessuraLinha(int value) {
    espessuraLinha = value;
  }
  public int getEspessuraLinha() {
    return espessuraLinha;
  }

  public void setCorFundo(int value) {
    corFundo = value;
  }
  public int getCorFundo() {
    return corFundo;
  }

  public abstract void desenhe();
  public String toString() {
    return "[" + getCorLinha() + "," +
                 getEspessuraLinha() + "," +
                 getCorFundo() + "]";
  }


/*
  public static void main (String[] args) {
    Figura figura = new Figura();
    System.out.println(figura);
    figura = new Figura(Figura.AMARELO, 5, Figura.AZUL);
    System.out.println(figura);
  }
*/
}