package br.gov.se.aracaju.figuras;

public class Ponto {

  private int x;
  private int y;

  public Ponto(int x, int y) {
    setX(x);
    setY(y);
  }

  public void setX(int value) {
    x = value;
  }
  public int getX() {
    return x;
  }

  public void setY(int value) {
    y = value;
  }
  public int getY() {
    return y;
  }

  public String toString() {
    return "[" + getX() + "," + getY() + "]";
  }
}