package br.gov.se.aracaju.figuras;

public class Figuras {
  private Figura[] figuras;
  private int pos;

  public Figuras (int tam) {
    figuras = new Figura[tam];
    pos = 0;
  }

  public void adicionar (Figura value) {
    if ( pos < figuras.length ) {
      figuras[pos] = value;
      pos++;
    }
  }

  public Figura getFigura(int pos) {
    if (pos < figuras.length) {
      return figuras[pos];
    } else {
      return null;
    }
  }

  public void desenhe() {
    System.out.println("Figuras");
    for (int i = 0; i < pos; i++) {
      Figura figura = figuras[i];
      figura.desenhe();
    }
  }
  public void desenheRetas() {
    System.out.println("Retas");
    for (int i = 0 ; i < pos; i++) {
      Figura figura = figuras[i];
      if (figura instanceof br.gov.se.aracaju.figuras.Reta) {
        figura.desenhe();
      }
    }
  }

  public void desenheCirculos() {
    System.out.println("C�rculos");
    for (int i = 0; i < pos; i++) {
      Figura figura = figuras[i];
      if (figura instanceof br.gov.se.aracaju.figuras.Circulo) {
        figura.desenhe();
      }
    }
  }

  public String toString() {
    String resp = "[";
    for (int i = 0; i < figuras.length; i++) {
      resp = resp + figuras[i] + ",";
    }
    resp = resp + "]";
    return resp;
  }
}