package br.gov.se.aracaju.figuras;

public class FigurasApp {
  public static void main(String[] args) {
    Figuras figuras = new Figuras(10);
    Circulo c = new Circulo(10,10,20);
    figuras.adicionar(c);
    c = new Circulo(20,20,40);
    figuras.adicionar(c);
    Reta r = new Reta(10,10,40,40);
    figuras.adicionar(r);
    r = new Reta(20,20,80,80);
    figuras.adicionar(r);
    figuras.desenhe();
    figuras.desenheCirculos();
    figuras.desenheRetas();

    Figura f = figuras.getFigura(2);
    f.desenhe();
    r = (Reta) figuras.getFigura(2);
    r.desenhe();
  }
}