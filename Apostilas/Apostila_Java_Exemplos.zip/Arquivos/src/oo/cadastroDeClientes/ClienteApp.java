/**
 * Application Demonstrandos as classes : Cliente, ClientePF, ClientePJ e
 * Clientes
 */

package oo.cadastroDeClientes;

public class ClienteApp {

	public static void main (String[] args) {
		/* Declarando e instanciando um objeto do tipo Clientes */
		Clientes clientes = new Clientes(50);
		/* Declarando um objeto do tipo Cliente */
		Cliente cliente;
		/*Instanciando um objeto do tipo Cliente */
		cliente = new Cliente(1, "Pel�", '2');
		/* inserindo em clientes */
		clientes.insere(cliente);
		cliente = new Cliente(2, "Guga", '1');
		clientes.insere(cliente);
		cliente = new Cliente(3, "Pop�", '2');
		clientes.insere(cliente);
		cliente = new Cliente(4, "Senna", '2');
		clientes.insere(new Cliente(5,"Anderson",'8'));

		System.out.println(clientes.quantidade() + " Clientes");
		clientes.escreve();

		/* Instanciando um objeto do tipo ClientePF */
		ClientePF clientePF = new ClientePF(5, "Jos� Maria",
										 	'1', "661.764.335-68");
		clientePF.escreve();
		clientes.insere(clientePF);

		/* Instanciando um objeto do tipo ClientePJ */
		ClientePJ clientePJ = new ClientePJ(6, "Infonet",
											 '2', "99.999.999.9999");
		clientePJ.escreve();
		clientes.insere(clientePJ);

		System.out.println("\nTodos os Clientes");

		/*
		 * Exemplo de Polimorfismo, pois os m�todos escreve() de
		 * ClientePF e ClientePJ s�o chamados automaticamente
		 */
		System.out.println(clientes.quantidade() + " Clientes");
		clientes.escreve();

		/* Convers�o expl�cita de Cliente ClientePJ */
		cliente = new ClientePJ(6, "Sefaz",'1', "99.999.999.9999");
		System.out.println(((ClientePJ)cliente).cgc());
	}
}