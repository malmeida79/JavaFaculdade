/**
 * SubClasse de Cliente com o objetico de demonstrar os seguintes conceitos de
 * orienta��o a objetos : Heran�a, Redefini��o de M�todos, Polimorfismo e
 * SobreCarga de M�todos
 */

package oo.cadastroDeClientes;

public class ClientePJ extends Cliente {
	private String cgc;

	public ClientePJ () {
		super();
	}

	public ClientePJ (int matr�cula, String nome, char plano, String cgc) {
		super(matr�cula, nome, plano);
		this.cgc = cgc;
	}

	public void cgc (String cgc) {
		this.cgc = cgc;
	}

	public String cgc () {
		return cgc;
	}

	public void escreve () {
		System.out.println("*****************************");
		System.out.println("Cliente Pessoa Jur�dica");
		super.escreve();
		System.out.println("cgc : " + cgc);
		System.out.println("*****************************");
	}
}