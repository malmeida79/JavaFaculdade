/**
 * Classe modelando cliente com o objetivo de demonstrar os seguintes
 * conceitos de orienta��o a objetos : Classe, Encapsulamento e Membros
 * (Atributos e M�todos)
 */

package oo.cadastroDeClientes;


/* Defini��o da classe */
public class Cliente {
	/* Corpo da classe */

	/* Atributos da classe */
	private int matr�cula;	//Matr�cula do cliente
	private String nome;	//Nome do cliente
	private char plano;		//Plano de assinatura do cliente

	/* M�todos da classe */

	/* Construtor */
	public Cliente() {
		super();
	}

	/* Construtor */
	public Cliente (int matr�cula, String nome, char plano) {
		setMatr�cula(matr�cula);
		setNome(nome);
		setPlano(plano);
	}

	/* M�todos para leitura e escrita dos atributos */

	public void setMatr�cula (int matr�cula) {
		this.matr�cula = matr�cula;
	}

	public void setNome (String nome) {
		this.nome = nome;
	}

	public void setPlano (char plano) {
		this.plano = plano;
	}

	public int getMatr�cula () {
		return matr�cula;
	}

	public String getNome () {
		return nome;
	}

	public char getPlano () {
		return plano;
	}

	/* M�todo que escreve os atributos do cliente na sa�da padr�o */
	public void escreve() {
		System.out.print(matr�cula + " | " + nome);
		if (plano == '1')
			System.out.println(" | 20 horas");
		else if (plano == '2')
			System.out.println(" | Horas livres");
		else
			System.out.println(" | Plano Inv�lido");
	}
}