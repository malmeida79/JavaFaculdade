/**
 * Classe modelando um conjunto de clientes com o objetivo de demonstar os
 * seguintes conceitos de orienta��o a objetos : Objeto e Mensagem
 */

package oo.cadastroDeClientes;

public class Clientes {
	/* Declarando um objeto : array de Cliente */
	private Cliente[] clientes;
	/* Posi��o de inser��o de novos clientes */
	int pos = 0 ;
	/* Constante com a quantidade default de clientes */
	final int QUANT_PADRAO  = 10;

	public Clientes () {
		/* Instanciando um objeto : array de Cliente */
		clientes = new Cliente[QUANT_PADRAO];
	}

	public Clientes (int quant) {
		/* Instanciando um objeto : array de Cliente */
		clientes = new Cliente[quant];
	}

	public void insere (Cliente cliente) {
		try {
			clientes[pos] = cliente;
			pos++;
		} catch ( ArrayIndexOutOfBoundsException e ) {
			System.out.println( "Limite de clientes esgotados." );
		}
	}

	public void escreve () {
		System.out.println("Rela��o de clientes : ");
		for (int i = 0 ; i < pos; i++) {
			/* Chamando um m�todo de Cliente */
			clientes[i].escreve();
		}
	}

	public int quantidade () {
		return pos;
	}
}