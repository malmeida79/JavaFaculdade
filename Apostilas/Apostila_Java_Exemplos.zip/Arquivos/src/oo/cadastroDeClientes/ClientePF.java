/**
 * SubClasse de Cliente com o objetico de demonstrar os seguintes conceitos de
 * orienta��o a objetos : Heran�a, Redefini��o de M�todos, Polimorfismo e
 * SobreCarga de M�todos
 */

package oo.cadastroDeClientes;

public class ClientePF extends Cliente {
	private String cpf;

	/* Construtores */
	public ClientePF () {
		super();
	}

	public ClientePF (int matr�cula, String nome, char plano) {
		/* Chamando o construtor da superclasse (Cliente) */
		super( matr�cula, nome, plano );
	}

	public ClientePF (String cpf) {
		/* Chamando o construtor da superclasse (Cliente) */
		super(0, "", '1');
		setCPF( cpf );
	}

	public ClientePF (int matr�cula, String nome, char plano, String cpf) {
		/* Chamando o construtor da superclasse (Cliente) */
		super(matr�cula, nome, plano);
		setCPF ( cpf );
	}

	/* M�todos para leitura e escrita dos atributos */
	public void setCPF (String cpf) {
		this.cpf = cpf;
	}

	public String getCPF () {
		return cpf;
	}

	/* Redefini��o do m�todo escreve da superclasse Cliente */
	public void escreve () {
		System.out.println("*****************************");
		System.out.println("Cliente Pessoa F�sica");
		/* Chamndo escreve da superclasse */
		super.escreve();
		System.out.println("cpf : " + cpf);
		System.out.println("*****************************");
	}
}