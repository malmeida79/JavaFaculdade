/**
 * Classe Alunos contendo a classe interna Aluno
 */

package oo.classeInterna;

public class Alunos {

	private Aluno[] alunos;
	private int posNovoAluno = 0;

	public Alunos() {
		alunos = new Aluno[10];
	}

	public void insere (int mat, String nome, float n1, float n2, float n3)	{
		alunos[posNovoAluno] = new Aluno(mat, nome, n1, n2,n3);
		posNovoAluno++;
	}

	public void escreve () {
		String linha = "****************************************************";
		System.out.println(linha);
		for (int i = 0; i < posNovoAluno; i++) {
			alunos[i].escreve();
		}
		System.out.println(linha);
	}

	/* Classe Interna : Aluno */
	class Aluno {
		int matricula;
		String nome;
		float nota1, nota2, nota3;

		Aluno (int mat, String nome, float n1, float n2, float n3) {
			this.matricula = mat;
			this.nome = nome;
			this.nota1 = n1;
			this.nota2 = n2;
			this.nota3 = n3;
		}

		void escreve() {
			String linha = "_________________________________________________";
			System.out.println(linha +
							   "\nMatr�cula : \t" + matricula +
							   "\nNome : \t" + nome +
							   "\nNotas : \t" + nota1 + "\t" + nota2 + "\t" +
												nota3 +
							   "\n" + linha);
		}
	}
}