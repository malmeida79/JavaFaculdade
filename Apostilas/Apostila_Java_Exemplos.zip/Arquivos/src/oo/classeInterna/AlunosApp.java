/**
 * Aplica��o demonstrando o uso de classe interna : Alunos/Aluno
 */

package oo.classeInterna;

public class AlunosApp {

    public static void main(String[] args) {
		Alunos alunos = new Alunos();
		alunos.insere(1, "Uguinho", 7.0f, 8.5f, 9.5f);
		alunos.insere(2, "Luizinho", 3.0f, 4.0f, 8.5f);
		alunos.insere(3, "Zezinho", 6.0f, 7.5f, 7.5f);
		alunos.escreve();
    }
}