package api.java.lang;

import java.lang.reflect.Method;

public class JavaLangClass {

	public static void main(String[] args) {
		String s = "";
		StringBuffer sb = new StringBuffer();
		Object o = new Object();
		System.out.println( nomeDaClasse(s) + "\n" + metodos(s ));
		System.out.println( nomeDaClasse(sb) );
		System.out.println( nomeDaClasse(o) );
	}

	public static String nomeDaClasse(Object obj) {
		return obj.getClass().getName();
	}

	public static String metodos(Object obj) {
		StringBuffer resp = new StringBuffer();
		Method[] metodos = obj.getClass().getMethods();
		for (int i = 0; i < metodos.length; i++) {
			resp.append(metodos[i] + "\n");
		}
		return resp.toString();
	}
}