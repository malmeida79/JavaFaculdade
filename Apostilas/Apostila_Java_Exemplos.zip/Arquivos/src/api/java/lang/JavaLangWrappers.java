package api.java.lang;

public class JavaLangWrappers {
	public static void main (String[] args) {
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		int inteiro = 0;
		/* String para inteiro */
		try {
			inteiro = Integer.parseInt("1456");
		} catch ( NumberFormatException e ) {
			System.out.println( "Erro na convers�o :"  + e.getMessage() );
		}
		/* Inteiro para String */
		String str = Integer.toString(inteiro);
		/* String na base 2*/
		str = Integer.toBinaryString(inteiro);
		System.out.println(inteiro + " em bin�rio � " + str);
		/* String na base 8*/
		str = Integer.toOctalString(inteiro);
		System.out.println(inteiro + " em Octal � " + str);
		/* String na base 16*/
		str = Integer.toHexString(inteiro);
		System.out.println(inteiro + " em Hexadecimal � " + str);
		/* Objeto do tipo Interger */
		Integer integer = new Integer(234);
		System.out.println(integer.intValue());
	}
}