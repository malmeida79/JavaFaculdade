package api.java.lang;

import java.lang.Cloneable;

public class JavaLangObject {

	/* Classe demonstrando o m�todo equals */
	static class Objeto implements Cloneable {
		String chave;
		String valor ;
		Objeto ( String ca, String cb ) {
			chave = ca;
			valor = cb;
		}

		public void setChave ( String chave ) {
			this.chave = chave;
		}

		public String getChave () {
			return chave;
		}

		public boolean equals ( Object obj ) {
			String chaveAux = ( ( Objeto ) obj).getChave();
			return chave.equals( chaveAux );
		}

		public String toString () {
			return "[" + chave + ", " + valor + "]";
		}

		public Object clone ( ) {
			Object resp = null;
			try {
				resp = super.clone( );
			} catch ( CloneNotSupportedException e ) {
			}
			return resp;
		}
	}

	public static void main (String[] args) {

		/* Instanciando os objetos exemplos */
		Objeto obj1 = new Objeto( "chave 1", "valor 1" );
		Objeto obj2 = new Objeto( "chave 1", "valor 1" );
		Objeto obj3 = new Objeto( "chave 3", "valor 3" );

		/* Clonando obj3 */
		Objeto obj4 = ( Objeto ) obj3.clone() ;
		obj4.setChave( "chave 4" );

		/* Exibindo os objetos */
		System.out.println( "obj1 : " + obj1 );
		System.out.println( "obj2 : " + obj2 );
		System.out.println( "obj3 : " + obj3 );
		System.out.println( "obj4 : " + obj4 );

		/* Demonstrando == e equals*/
		System.out.println( "obj1.equals( obj2 ) => " + obj1.equals( obj2 ) );
		System.out.println( "obj1.equals( obj3 ) => " + obj1.equals( obj3 ) );
		System.out.println( "obj1 == obj2 => " + ( obj1 == obj2 ) );
		System.out.println( "obj1 == obj4 => " + ( obj1 == obj4 ) );
		System.out.println( "obj3 == obj4 => " + ( obj3 == obj4 ) );
		System.out.println( "obj3.equals(obj4) => " + ( obj1.equals( obj4 ) ) );

		System.out.println( obj1 );

		System.out.println( "hashcode : " + obj1.hashCode() );

		int[] a1 = {1,2,3,4};
		int[] a2 = ( int[] ) a1.clone();
		a2[0] = 0;
		System.out.println( a1[0] );
		System.out.println( a2[0] );
	}
}