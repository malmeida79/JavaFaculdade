package api.java.lang;

public class JavaLangStringStringBuffer {
	public static void main ( String[] args ) {
		/* Opera��es com String */
		//String strA = new String ("   Jos� Maria R S Junior   ");
		String strA = "   Jos� Maria R S Junior   ";
		for ( int i = 0; i < strA.length(); i++ )
			System.out.println( "Posi��o [" + i + "] Caracter + [" +
								strA.charAt(i) + "]" );
		System.out.println( "Jos� : " + strA.indexOf( "Jos�" ) );
		System.out.println( "Junior : " + strA.indexOf( "Junior" ) );
		System.out.println( strA.toLowerCase() );
		System.out.println( strA.toUpperCase() );
		System.out.println( strA.trim() );
		System.out.println( String.valueOf(true) );
		System.out.println( String.valueOf( Math.pow( 3,13 ) ) );
		int tamStrA = strA.length();
		System.out.println( "Tamanho do Nome : " + tamStrA );
		String strB = strA.substring( 8,17 );
		System.out.println( "Caracteres de 8 a 17 : " + strB );

		/* Opera��es com StringBuffer */
		StringBuffer strbA = new StringBuffer( "Jos�" );
		strbA.append( " R S Junior" );
		strbA.insert( 5,"Maria " );
		strbA.replace( 11,12, "Rodrigues Santos" );
		System.out.println(strbA.toString());

		String s1 = new String( "Infonet" );
		String s2 = new String( "Infonet" );
		if ( s1 == s2 ) {
			System.out.println( "( s1 == s2 )" );
		}
		if ( s1.equals( s2 ) ) {
			System.out.println( "( s1.equals( s2 ) )" );
		}

		System.out.println( "Objeto String".length() );
	}
}