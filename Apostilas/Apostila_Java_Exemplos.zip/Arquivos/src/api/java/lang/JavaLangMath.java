package api.java.lang;

public class JavaLangMath {
	public static void main (String[] args) {
		/* Imprimdindo pot�ncias de 2 */
		int a = 2;
		int b = 20;
		for (int i = a; i <= b; i++) {
			System.out.println(a + " elevado a " + i +
								 " = " + (int) (Math.pow(a,i)));
		}
		/* Sorteando um n�mero inteiro */
		System.out.println("N�mero sorteado = " + (int) (Math.random() * 100));
		/* Valor de PI */
		System.out.println("PI = " + Math.PI);
	}
}