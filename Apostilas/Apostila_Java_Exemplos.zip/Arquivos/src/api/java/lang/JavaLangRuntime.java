package api.java.lang;

import java.io.IOException;
import java.util.Properties;
import java.util.Enumeration;

public class JavaLangRuntime {

	public static void main( String[] args ) {
		/* Obtendo o objeto que representa o ambiente de Runtime */
		Runtime rt = Runtime.getRuntime();

		System.out.println( "Total de mem�ria : " + rt.totalMemory() );
		System.out.println( "Mem�ria Livre    : " + rt.freeMemory() );

		/* Executando aplicativos e terminando a execu��o */
		try {
			rt.exec("e:\\winnt\\NOTEPAD.EXE");
			rt.exit( 0 );
			rt.exec("e:\\winnt\\EXPLORER.EXE");
		} catch ( IOException ioe ) {
			System.out.println( "Erro na execu�ao do aplicativo" );
		}
	}
}