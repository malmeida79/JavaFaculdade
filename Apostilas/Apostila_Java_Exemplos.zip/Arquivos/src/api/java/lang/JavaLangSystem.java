/* @author Jos� Maria R S Junior
 * zemaria@unitnet.com.br / www.unit.br/zemaria
 *
 * Aplica��o para demonstrar as principais classes do pacote java.lang
 * Math, Object, String, StringBuffer, System, Execptions e Wrappers
 *
 **/

package api.java.lang;

import java.util.Properties;
import java.util.Enumeration;
import java.io.IOException;

public class JavaLangSystem {
	public static void main (String[] args) {
		/* Classe System */
		/* Imprindo na sa�da padr�o */
		System.out.println("Ol� Mundo");
		/* Obtendo e imprimindo informa��es do Sistema */
		Properties prop = System.getProperties();
		Enumeration nomesProp = prop.propertyNames();
		while (nomesProp.hasMoreElements()) {
			String nomeProp = nomesProp.nextElement().toString();
			String valorProp = System.getProperty(nomeProp);
			System.out.println(nomeProp + " = " + valorProp);
		}
		/* Executando o Garbage Collector */
		System.gc();
	}
}