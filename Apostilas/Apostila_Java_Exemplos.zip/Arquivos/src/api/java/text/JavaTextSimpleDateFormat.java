package api.java.text;

import java.text.SimpleDateFormat;
import java.util.Date;

public class JavaTextSimpleDateFormat {
	public static void main ( String[] args ) {

	 	SimpleDateFormat formatter
	    	= new SimpleDateFormat ( "dd/MM/yyyy" );
		Date currentTime = new Date( System.currentTimeMillis() );
		String dateString = formatter.format( currentTime );
		System.out.println( dateString );
 	}
}