package api.java.text;

import java.text.DecimalFormat;

public class JavaTextDecimalFormat {

	public static void main( String[] args ) {

		/* Definindo o formato */
		String formato = "#,##0.##";
		/* Instanciando o DecimalFormat com o formato definido */
		DecimalFormat df = new DecimalFormat( formato );
		double d = 465980932789.4587312;
		/* Obtendo o formato */
		System.out.println( df.toPattern() );
		/* formatando o double */
		System.out.println( df.format( d ) );
	}
}