package api.java.io;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

public class JavaIOFile {
	public static void main (String[] args) {
		/* Obtendo atributos do sistema de arquivo local */
		System.out.println( "Separator       : " + File.separator );
		System.out.println( "PathSeparador   : " + File.pathSeparator );
		/* Declarando e instanciando um objeto do tipo File */
		File arq = new File( "arquivo.txt" );
		/* Obtendo atributos da classe File */
		System.out.println( "exists           : " + arq.exists() );
		System.out.println( "getAbsolutePath : " + arq.getAbsolutePath() );
		System.out.println( "getName         : " + arq.getName() );
		System.out.println( "getPath         : " + arq.getPath() );
		System.out.println( "isDirectory     : " + arq.isDirectory() );
		System.out.println( "isFile          : " + arq.isFile() );
		System.out.println( "toString        : " + arq.toString() );
		System.out.println( "canWrite        : " + arq.canWrite() );
		System.out.println( "canRead         : " + arq.canRead() );
		System.out.println( "length	         : " + arq.length() );


		/* Criando um novo arquivo no sistema de arquivos host */
		try {
			arq.createNewFile();
		} catch (IOException e) {
			System.out.println( "Erro na cria��o do arquivo : " +
								e.getMessage());
		}
		/* deletando o arquivo criado */
		System.out.println( "delete          : " + arq.delete() );

		System.out.println(  );

		/* Declarando e instanciando um File para p ditet�rio corrente */
		File dirCorrente = new File( "C:\\" );
		System.out.println( "getAbsolutePath 	: " +
							dirCorrente.getAbsolutePath() );
		System.out.println( "isDirectory 		: " +
						   dirCorrente.isDirectory() );
		System.out.println( "isFile 				: " +
							dirCorrente.isFile() );
		/* Listando o conte�do da classe File */
		String[] conteudo = dirCorrente.list();
		System.out.println( "Conte�do : " + dirCorrente.getName() );
		for (int i = 0; i < conteudo.length; i++) {
			System.out.println( conteudo[i] );
		}
		System.out.println(  );
		/* Listando apenas os arquivos do diret�rio corrente */
		File[] diretorios = dirCorrente.listFiles();
		System.out.println( "Diretorios : " + dirCorrente.getName());
		for (int i = 0; i < diretorios.length; i++) {
			if ( diretorios[i].isDirectory() ) {
				System.out.println( diretorios[i] );
			}
		}

	}
}