package api.java.io;

import java.io.RandomAccessFile;
import java.io.File;
import java.io.IOException;

public class JavaIoRandomAccessFile {

	public static void main( String[] args ) {
		File arqOrigem	= new File( "c:\\autoexec.bat" );
		RandomAccessFile arq;
		try {
			arq = new RandomAccessFile ( arqOrigem , "r");
			System.out.println( "Tamanho do arquivo : " + arq.length() );
			long posicaoLeitura = arq.length() - 1;
			int bytesLidos = 0;
			while ( posicaoLeitura >= 0 ) {
				arq.seek( posicaoLeitura );
//				System.out.println(  "FP: " + arq.getFilePointer() );
				System.out.print( ( char ) arq.read() );
				bytesLidos++;
				posicaoLeitura--;
			}
			System.out.println( "\nBytes lidos : " + bytesLidos );
		} catch ( IOException e ) {
			System.out.println( "Erro no acesso ao arquivo" + e.getMessage() );
		}
	}
}