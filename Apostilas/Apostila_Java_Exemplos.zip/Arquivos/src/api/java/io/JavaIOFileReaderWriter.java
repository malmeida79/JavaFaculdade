package api.java.io;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

public class JavaIOFileReaderWriter {
	public static void main (String[] args) {
		/* Criando os objetos do tipo File */
		File arqOrigem	= new File( "c:\\autoexec.bat" );
		File arqDestino	= new File( "c:\\autoexec.bak" );
		try {
			/*
			 * Criando os Stream de leitura e escrita para os arquivos de
			 * origem e destino respectivamente
			 */
			FileReader fr	= new FileReader(arqOrigem);
			FileWriter fw	= new FileWriter(arqDestino);
			System.out.println("Copiando o arquivo " + arqOrigem +
							   " para " + arqDestino);
			/* Verificando permiss�es nos arquivos */
			if ( arqOrigem.canRead() && arqDestino.canWrite() ) {
				int c;
				/* lendo, enquando existir bytes no stream de entrada */
				while ( ( c = fr.read() ) != -1 ) {
					/* escrevendo no stream de saida */
					fw.write(c);
					char caracter = ( char ) c;
					System.out.print(  caracter );
				}
			} else {
				System.out.println("Acesso n�o permitido");
				System.out.println("Origem  : " + arqOrigem.toString());
				System.out.println("Destino : " + arqDestino.toString());
			}
			fr.close();
			fw.close();
		} catch ( FileNotFoundException e ) {
			System.out.println("Arquivo n�o encontrado :" + e.getMessage());
		} catch ( IOException e ) {
			System.out.println("Erro de Entrada/Sa�da : " +
							   e.getMessage());
		}
	}
}