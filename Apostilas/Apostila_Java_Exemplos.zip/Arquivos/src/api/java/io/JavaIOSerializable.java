package api.java.io;

import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.NotSerializableException;
import java.io.OptionalDataException;
import java.io.IOException;
import java.util.Vector;

public class JavaIOSerializable {

	public static void main ( String[] args ) {

		/* Declarando uma classe interna para simular registros num Vector */
		class Registro implements Serializable {
			int codigo;
			String nome;

			public Registro ( int cod, String nome ) {
				this.codigo = cod;
				this.nome = nome;
			}

			public String toString() {
				return "[" + codigo + ", " + nome + "]";
			}
		}

		Vector v = new Vector();
		/* Inserindo 10 registo no Vector */
		for ( int i = 1; i <= 10; i++ ) {
			Registro reg = new Registro( i,"Nome_" + ( i ) );
			v.add(reg);
		}
		System.out.println( "Vetor gerado 	: " + v );
		try {
			/* Criando um stream de escrita de arquivo*/
			FileOutputStream fos = new FileOutputStream( "Vetor.dat" );
			/*
			 * Criando um filtro (Stream) de escrita de objetos e associando-o
			 * ao stream de escrita de arquivo
			 */
			ObjectOutputStream oos = new ObjectOutputStream( fos );
			/* Escrevendo o Vector */
			oos.writeObject( v );
			/* Esvaziando o buffer do stream */
			oos.flush();
			/* Fechando os Streams */
			fos.close();
			/* Limpando o vetor*/
			v.clear();
			System.out.println( "Vetor vazio :" + v );
			/* Criando um stream de leitura de arquivo*/
			FileInputStream fis = new FileInputStream( "Vetor.dat" );
			/*
			 * Criando um Stream de leitura de objetos e associando-o ao
			 * stream de leitura de arquivo
			 */
			ObjectInputStream	ois = new ObjectInputStream( fis );
			/* Lendo o objeto do stream*/
			v = ( Vector ) ois.readObject();
			System.out.println( "Vetor recuperado : " + v );
			/*
			 * Demonstra��o da grava��o e leitura de diversos objetos no arquivo
			 */
			/* Gravando os objetos no arquivo */
			fos = new FileOutputStream( "Objetos.dat" );
			oos = new ObjectOutputStream( fos );
			for ( int i = 0; i < v.size(); i++ ) {
				oos.writeObject( v.get( i ) );
			}
			v.clear();
			oos.flush();
			fis = new FileInputStream( "Objetos.dat" );
			ois = new ObjectInputStream( fis );
			try {
				while ( true ) {
					v.add( ois.readObject() );
				}
			} catch ( IOException e ) {
				System.out.println( "Todos os objetos foram lidos : " +
									e.getMessage() );
			}
			System.out.println( v );
		} catch ( FileNotFoundException e ) {
			System.out.println( "Arquivo n�o encontrado : " +
								e.getMessage() );
		} catch ( NotSerializableException e ) {
			System.out.println( "Objeto n�o serializ�vel : " +
								e.getMessage() );
		} catch ( IOException e ) {
			System.out.println( "Erro de I/O : " + e.getMessage() );
		} catch ( ClassNotFoundException e ) {
			System.out.println( "Classe n�o encontrada : " +
								e.getMessage() );
		}
	}
}