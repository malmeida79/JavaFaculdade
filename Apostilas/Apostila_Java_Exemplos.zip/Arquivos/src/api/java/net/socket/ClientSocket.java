package api.java.net.socket;

import java.io.*;
import java.net.*;
import util.Keyboard;

public class ClientSocket {
	public static void main(String[] args) {
		String server = "localhost"; //Servidor
		int port = 44444; //Porta
		System.out.print("Mensagem : ");
		/* Lendo a mensagem a ser enviado ao servidor */
		String message = Keyboard.readString();
		/* Stream de Entrada */
		BufferedReader in = null;
		/* Stream de sa�da */
		PrintWriter out = null;
		/* socket cliente */
		Socket socket = null;
		try {
			/* Instanciando o socket */
			socket = new Socket( server, port );
			/* Associando os Streams de Entrada e Sa�da ao socket */
			InputStreamReader isr =
				new InputStreamReader( socket.getInputStream() );
			in = new BufferedReader( isr );
			out = new PrintWriter( socket.getOutputStream(), true );
			/* Eviando a mensagem para o socket servidor atrv�s do Stream */
			out.println(message);
			/* Obtendo mensagem do socket servidor */
			String fromServer = in.readLine();
			/* Imprimindo a mensagem recebida do socket servidor */
			System.out.println("Mensagem do servidor socket : " + fromServer);
			/* Fechando os streams */
			out.close();
			in.close();
			/* Fechando o socket */
			socket.close();
		} catch (UnknownHostException e) {
			System.err.println("Servidor n�o encontrado: " + server);
			System.exit( 1 );
		} catch (IOException e) {
			System.err.println("Erro de I/O com o servidor : " + server);
			System.exit( 1 );
		}
	}
}