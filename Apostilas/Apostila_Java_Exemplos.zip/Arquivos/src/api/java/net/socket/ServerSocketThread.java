package api.java.net.socket;

import java.net.*;
import java.io.*;
import util.Keyboard;

public class ServerSocketThread extends Thread {
	/* Socket cliente */
	private Socket socket = null;
	/* Mensagem a ser enviada ao cliente */
	private String msg;

	public ServerSocketThread( Socket socket, String msg ) {
		super("ServerSocketThread");
		this.socket = socket;
		this.msg = msg;
	}

	public void run() {
		try {
			/* Criando e associando os Streams de I/O com o socket cliente */
			PrintWriter out = new PrintWriter( socket.getOutputStream(), true );
			InputStreamReader isr =
				new InputStreamReader( socket.getInputStream() );
			BufferedReader in =	new BufferedReader( isr );
			/* Obtendo e imprimindo a mensagem do socket Cliente */
			String inputLine = in.readLine();
			System.out.println( "Porta do socket associado ao cliente :" +
								socket.getPort() );
			System.out.println( "Mensagem do socket cliente : " + inputLine );
			/* Enviando a mensagem para o socket cliente */
			out.println( msg );
			/* Fechando os Streams */
			out.close();
			in.close();
			/* Fechando o socket cliente */
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}