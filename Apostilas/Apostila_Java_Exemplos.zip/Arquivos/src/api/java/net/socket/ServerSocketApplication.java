package api.java.net.socket;

import java.net.*;
import java.io.*;
import util.Keyboard;

public class ServerSocketApplication {
	public static void main(String[] args) {
		/* Socket servidor */
		ServerSocket serverSocket = null;
		/* Porta */
		int port = 44444;
		System.out.println("Inicializando a aplica��o servidor socket");
		try {
			/* Inicializando o servidor socket */
			serverSocket = new ServerSocket( port );
			/* Mensagem a ser enviado ao cliente */
			System.out.print( "Mensagem : " );
			String msg = Keyboard.readString();
			/* La�o para responder as conex�es dos clientes socket */
			for ( int i = 0; i <= 100; i++ ) {
				/* Criando uma thread para responder ao socket cliente */
				new ServerSocketThread( serverSocket.accept(), msg ).start();
			}
			/* fechando o socket servidor */
			serverSocket.close();
		} catch ( IOException e ) {
			System.err.println("Erro na incializa��o da Porta: " + port);
			System.exit(-1);
		}
	}
}