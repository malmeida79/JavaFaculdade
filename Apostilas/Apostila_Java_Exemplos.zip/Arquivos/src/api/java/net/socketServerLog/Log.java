package socketServerLog;

import java.util.Vector;

public class Log {
	private Vector log;

	public Log () {
		log = new Vector();
	}

	synchronized public void addMessage( String msg ) {
		log.addElement( msg );
	}

	synchronized public String toString () {
		StringBuffer sb = new StringBuffer();
		sb.append("<<<<< Log Inicio >>>>>\n");
		for ( int i = 0 ; i < log.size(); i++ ) {
			sb.append( log.get( i ) + "\n" ) ;
		}
		sb.append("<<<<< Log Fim >>>>>");
		return sb.toString();
	}

	public static void main(String[] args) {
		Log log = new Log();
		log.addMessage( "Mensagem 1" );
		log.addMessage( "Mensagem 2" );
		log.addMessage( "Mensagem 3" );
		log.addMessage( "Mensagem 4" );
		log.addMessage( "Mensagem 5" );
		log.addMessage( "Mensagem 6" );
		System.out.println( log );
	}
}