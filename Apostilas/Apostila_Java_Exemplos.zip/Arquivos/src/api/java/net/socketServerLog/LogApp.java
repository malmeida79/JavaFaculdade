package socketServerLog;

import java.net.ServerSocket;
import java.io.IOException;

public class LogApp {

    public static void main(String[] args) {
		/* Porta */
		int port = 44444;
		/* Socket servidor */
		ServerSocket serverSocket = null;
		try {
			serverSocket = new ServerSocket( port );
		} catch ( IOException e ) {
			System.err.println("Erro na incializa��o da Porta: " + port);
		}
		/* Log */
		Log log = new Log();
		System.out.println("Inicializando a aplica��o servidor socket");
		/* La�o para responder as conex�es dos clientes socket */
		for ( int i = 1; i <= 5; i++ ) {
			try {
				/* Criando uma thread para responder ao socket cliente */
				new ServerSocketLogThread( serverSocket.accept(), log ).start();
			} catch ( IOException e ) {
				System.err.println("Erro : " + e.getMessage() );
			}
		}
		System.out.println( log );
    }
}