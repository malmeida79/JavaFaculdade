package socketServerLog;

import java.net.*;
import java.io.*;

public class ServerSocketLogThread extends Thread {
	/* Mensagem de confirma��o */
	public static String CONFIRMACAO = "Mensagen gravada no log";
	/* Socket cliente */
	private Socket socket;
	/* Objeto representando o log */
	Log log;
	/* Mensagem a ser gravada no log */
	private String msg;

	public ServerSocketLogThread ( Socket socket, Log log ) {
		super("ServerSocketLogThread");
		this.socket = socket;
		this.log = log;
	}

	public void run () {
		try {
			PrintWriter out = new PrintWriter( socket.getOutputStream(), true );
			InputStreamReader isr =
				new InputStreamReader( socket.getInputStream() );
			BufferedReader in =	new BufferedReader( isr );
			String msg = in.readLine();
			System.out.println( "Mensagem : " + msg );
			log.addMessage( msg );
			out.println( CONFIRMACAO );
			out.close();
			in.close();
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}