package api.java.net.url;

import java.io.*;
import java.net.*;
import util.Keyboard;

public class JavaNetUrl {
	public static void main ( String[] args ) {
		try {
			String url = "http://www.unit.br:80/zemaria";
			/* Declarando e instanciando um objeto do tipo URL */
			URL pagina = new URL( url );
			/* Obtendo propriedades do objeto URL */
			System.out.println( "protocolo	= " + pagina.getProtocol() );
			System.out.println( "servidor 	= " + pagina.getHost() );
			System.out.println( "arquivo	= " + pagina.getFile() );
			System.out.println( "porta		= " + pagina.getPort() );
			/* Declarando um objeto do tipo URL */
			URLConnection conexaoUrl;
			/* Declarando um stream de entrada */
			InputStreamReader isr;
			/* Declarando um stream de leitura com buffer para leitura */
			BufferedReader dados;
			/* String para armazenar uma linha lida */
			String linha;
			/* Abrindo a conex�o atrav�s do objeto URL */
			conexaoUrl = pagina.openConnection();
			/* Conectando atrav�s do objeto URLConnection */
			conexaoUrl.connect();
			/* Associando o stream de entrada a conex�o */
			isr = new InputStreamReader( conexaoUrl.getInputStream() );
			/* Associando o stream com buffer ao stream de entrada */
			dados = new BufferedReader( isr );
			/* Lendo linhas do stream */
			while ( ( linha = dados.readLine() ) != null ) {
				System.out.println( linha );
			}
			/* Fechando o stream */
			dados.close();
		} catch ( MalformedURLException e ) {
			System.out.println( "Erro na URL : " + e.getMessage() );
		} catch ( IOException e ){
			System.out.println( "Erro de I/O : " + e.getMessage() );
		}
	}
}