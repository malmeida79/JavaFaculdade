package api.java.util;

public class Item implements Comparable {

	private String chave;
	private String campo;

	public Item ( String chave, String campo ) {
		setChave( chave );
		setCampo( campo );

	}

	public void setChave (String chave ) {
		this.chave = chave;
	}

	public void setCampo (String campo ) {
		this.campo = campo;
	}

	public String getChave () {
		return chave;
	}

	public String getCampo () {
		return campo;
	}

	public String toString () {
		return "[" + chave + ", " + campo + "]";
	}

	/* Redefinindo o m�todo equals() */
	public boolean equals ( Object obj ) {
		Item item = ( Item ) obj;
		return getChave().equals( item.getChave() );
	}
	/* Redefinindo o m�todo compareTo() */
	public int compareTo ( Object obj ) {
		Item item = ( Item ) obj;
		return getChave().compareTo( item.getChave() );
	}

}