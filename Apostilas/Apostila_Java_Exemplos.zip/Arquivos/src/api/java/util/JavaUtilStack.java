package api.java.util;

import java.util.Stack;

public class JavaUtilStack {
	public static void main ( String[] args ) {

		Stack stack = new Stack();
		stack.push( "a" );
		stack.push( "+" );
		stack.push( "b" );
		stack.push( "+" );
		stack.push( "c" );
		StringBuffer expressao = new StringBuffer();
		while ( ! stack.empty() ) {
			String termo = ( String ) stack.pop();
			expressao.append( termo );
		}
		System.out.println( expressao );
	}
}