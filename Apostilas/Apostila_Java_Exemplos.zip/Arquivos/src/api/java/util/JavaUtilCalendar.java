package api.java.util;

import java.util.Date;
import java.util.TimeZone;
import java.util.Calendar;

public class JavaUtilCalendar {
	public static void main (String[] args) {
		TimeZone tz = TimeZone.getTimeZone( "GMT-3:00" );
		Calendar cal = Calendar.getInstance( tz );
		int dia 		= cal.get(Calendar.DAY_OF_MONTH);
		int mes 		= cal.get(Calendar.MONTH);
		int ano 		= cal.get(Calendar.YEAR);
		int hora 		= cal.get(Calendar.HOUR);
		int min 		= cal.get(Calendar.MINUTE);
		int seg 		= cal.get(Calendar.SECOND);
		int miliseg 	= cal.get(Calendar.MILLISECOND);
		int diaSemana 	= cal.get(Calendar.DAY_OF_WEEK);
		System.out.println("Data : " + dia + "/" + mes + "/" + ano);
		System.out.println("Hora : " + hora + ":" + min + ":" +
									   seg  + ":" + miliseg);
		System.out.println("Dia da semana : " + diaSemana);
		System.out.println(cal);
		System.out.println(cal.getTime());

		Date data = new Date( System.currentTimeMillis() );
		cal.setTime( data );
		System.out.println( cal.get( Calendar.HOUR) + ":" +
							cal.get( Calendar.MINUTE ) + ":" +
							cal.get( Calendar.SECOND ) + ":" +
							cal.get( Calendar.MILLISECOND ) );
	}
}