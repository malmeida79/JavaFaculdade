package api.java.util;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Enumeration;

public class JavaUtilHashtable {
	public static void main(String args[]) {


		/* Declarando e Instanciando o Hashtable */
		Hashtable itens = new Hashtable();

		/* Inserindo itens no HashTable */
		Item item;
		item = new Item("0", "Huguinho");
		itens.put( item.getChave(), item );
		item = new Item("1", "Zezinho");
		itens.put( item.getChave(), item );
		item = new Item("2", "Luizinho");
		itens.put( item.getChave(), item );
		item = new Item("3", "Tio Patinhas");
		itens.put( item.getChave(), item );
		item = new Item("4", "Pato Donald");
		itens.put( item.getChave(), item );

		System.out.println( "Quantidade de itens : " + itens.size() );
		System.out.println( "<<< Imprimindo o Hashtable >>> \n" + itens );

		item = new Item("3", "Pluto");
		itens.put( item.getChave(), item );

		System.out.println( "Quantidade de itens : " + itens.size() );
		System.out.println( "<<< Imprimindo o Hashtable >>> \n" + itens );

		System.out.println( "<<< Imprindo as chaves e os objetos >>>" );
		/* O m�todo keys() retorna um Enumeration com as chaves */
		Enumeration e = itens.keys();
		while(e.hasMoreElements()) {
			Object chave = e.nextElement();
			System.out.println( chave + " = " + itens.get( chave ) );
		}

		System.out.println( "<<< Imprindo os objetos >>>" );
		/* O metodo values() retorna um collection com os objetos */
		Iterator valores = itens.values().iterator();
		while ( valores.hasNext() ) {
			System.out.println( valores.next() );
		}
  	}
}