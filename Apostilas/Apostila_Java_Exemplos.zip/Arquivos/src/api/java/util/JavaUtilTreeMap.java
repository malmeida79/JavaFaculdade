package api.java.util;

import java.util.TreeMap;
import java.util.Iterator;


public class JavaUtilTreeMap {

	public static void main(String[] args) {

		TreeMap itens = new TreeMap();

		/* Inserindo itens no TreeSet */
		Item item;
		item = new Item("3", "Mickel Jackson");
		itens.put( item.getChave(), item );
		item = new Item("2", "Maguila");
		itens.put( item.getChave(), item );
		item = new Item("5", "Hebe Camargo");
		itens.put( item.getChave(), item );
		item = new Item("4", "Ratinho");
		itens.put( item.getChave(), item );
		item = new Item("1", "Fernando Henrique");
		itens.put( item.getChave(), item );
		System.out.println( itens );
		item = new Item("1", "Gil Gomes");
		itens.put( item.getChave(), item );
		System.out.println( itens );

		System.out.println("Obtendo um elemento");
		System.out.println( itens.get("3") );

		System.out.println(  "Itens" );

		Iterator keys = itens.keySet().iterator();
		while ( keys.hasNext() ) {
			System.out.println( itens.get( keys.next() ) );
		}

	}
}