package api.java.util;

import java.util.Vector;
import java.util.Collections;

public class JavaUtilVector {
	public static void main (String[] args) {
		/* Declarando e instanciando o vetor */
		Vector itens = new Vector();

		/* Inserindo itens no vetor */
		Item item;
		item = new Item("2", "Punisher");
		itens.addElement( item );
		item = new Item("4", "Wiseman");
		itens.addElement( item );
		item = new Item("1", "Airamez");
		itens.insertElementAt(item,1);
		item = new Item("3", "P4tinh0");
		itens.addElement( item );
		item = new Item("0", "Rampage");
		itens.addElement( item );

		System.out.println( "Quantidade de itens : " + itens.size() );
		System.out.println( itens );
		/*
		 * Ordenando o Vector, para isso os objetos armazenados
		 * devem implementar a interface Comparable e consequentemente
		 * redefinir o m�todo compareTo();
		 */
		Collections.sort( itens );
		System.out.println( "Vector ordenado : " + itens );

		System.out.println( "Elemento da posi�ao 3 : " + itens.get(3) );

		item = new Item( "1", "Jos�" );
		System.out.println( item + " est� na posi�ao : " +
							itens.indexOf( item ) );
		System.out.println( "Removendo : " + item + " : " +
							itens.remove( item ) );
		System.out.println( itens );
 		System.out.println( "Removendo : " + item + " : " +
							itens.remove( item ) );
		System.out.println( itens );
		System.out.println( "Removendo : "  + itens.remove( 2 ) );
		System.out.println( itens );
		itens.clear();
		System.out.println( "Itens : " + itens );
	}
}