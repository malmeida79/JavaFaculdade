package api.java.util;

import java.io.*;
import java.lang.StringBuffer;
import java.lang.NumberFormatException;
import java.util.Random;
import util.Keyboard;

public class JavaUtilRandom {

    public static void main ( String args[] ) {
		int limiteInferior = 1;
		int limiteSuperior = 100;
		Random r = new Random();
		int numeroSorteado = r.nextInt( 100 );
		int chute;
		int tentativas = 0;

		do {
	    	System.out.print( "Digite um n�mero entre " + limiteInferior +
							  " e " + limiteSuperior + " = > " );
	    	chute = Keyboard.readInt();
	    	if ( (chute >= limiteInferior) && (chute <= limiteSuperior) ) {
				if ( chute > numeroSorteado ) {
		    		limiteSuperior = chute - 1;
				} else {
		    		limiteInferior = chute + 1;
				}
	    	} else {
	    		System.out.println( "N�mero digitado fora do intervalo" );
	    	}
	    	tentativas++;
		} while ( chute != numeroSorteado );

		System.out.println( "Parabens !!, acertou em " + tentativas +
							" tentativas");
    }
}