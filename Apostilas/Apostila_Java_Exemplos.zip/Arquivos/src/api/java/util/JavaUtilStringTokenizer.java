package api.java.util;

import java.util.StringTokenizer;

public class JavaUtilStringTokenizer {
	public static void main (String[] args) {
		StringTokenizer st = new StringTokenizer("Jos�    Maria  R   S Junior");
		System.out.println(st.countTokens());
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		st = new StringTokenizer("Campo1,Campo2,,,,Campo3,  Campo4" , ",");
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		st = new StringTokenizer("Campo1##Campo#Campo3###Campo4#" , "#");
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
	}
}