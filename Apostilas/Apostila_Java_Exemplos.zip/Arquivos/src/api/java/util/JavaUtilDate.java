package api.java.util;

import java.util.Date;
import java.util.Calendar;
import java.text.DateFormat;

public class JavaUtilDate {

	public static void main(String[] args) {
		Date data1 = new Date( System.currentTimeMillis() );
		Date data2 = new Date( System.currentTimeMillis() + 600000) ;
		Date data3 = new Date( System.currentTimeMillis() - 600000 );
		System.out.println( data1 );
		System.out.println( data2 );
		System.out.println( data3 );
		if ( data1.before( data2 ) ) {
			System.out.println( data1 + " � menor que " + data2 );
		}
	}
}