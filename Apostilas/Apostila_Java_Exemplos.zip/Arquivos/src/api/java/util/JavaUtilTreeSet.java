package api.java.util;

import java.util.TreeSet;
import java.util.Iterator;
import java.util.SortedSet;

public class JavaUtilTreeSet {

	public static void main(String[] args) {

		TreeSet itens = new TreeSet();

		/* Inserindo itens no TreeSet */
		Item item;
		item = new Item("3", "Junior Baiano");
		itens.add( item );
		item = new Item("2", "Naza");
		itens.add( item );
		item = new Item("5", "Alem�o");
		itens.add( item );
		item = new Item("4", "Casa Grande");
		itens.add( item );
		item = new Item("1", "Rocha");
		itens.add( item );

		/* Obtendo os elementos do TreeSet */
		Iterator iterator = itens.iterator();
		while ( iterator.hasNext() ) {
			System.out.println( iterator.next() );
		}

		/* Obtendo elementos de um intervslo do TreeSet */
		SortedSet itensNoIntervalo = itens.subSet(new Item("2",""),
												  new Item("5",""));
		System.out.println("Intervalo");
		iterator = itensNoIntervalo.iterator();
		while ( iterator.hasNext() ) {
			System.out.println( iterator.next() );
		}


	}
}