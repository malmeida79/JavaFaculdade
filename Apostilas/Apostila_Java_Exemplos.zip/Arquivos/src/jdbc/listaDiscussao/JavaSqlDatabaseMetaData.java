package jdbc.listaDiscussao;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class JavaSqlDatabaseMetaData implements DataBaseConstantes {

	public static void main(String[] args) {
		Connection con = null;
		try {
			con = DataBaseConnection.getConnection( DRV, URL, USUARIO, SENHA );
		} catch ( ClassNotFoundException cnfe ) {
			System.out.println( cnfe.getMessage() );
		} catch ( SQLException sqle ) {
			System.out.println( sqle.getMessage() );
		}

		try {
			/* Obtendo objeto com metadados do banco de dados */
			DatabaseMetaData dbmd = con.getMetaData();
			ResultSet rs = null;
			/* Obtendo metadados do banco de dados */

			System.out.println( "DriverName = " + dbmd.getDriverName() );
			System.out.println( "DriverVersion = " + dbmd.getDriverVersion() );
			/* tipos de tabelas a serem obtidas */
			String[] tableTypes = {"TABLE", "VIEW"};
			/* Obtendo todas as tabelas dos tipos especificados */
			rs = dbmd.getTables(null, null, "%", tableTypes );
			System.out.println( "Tabelas do banco : " );
			imprimeResultSet( rs );
			/* Obtendo as chaves prim�rias de uma tabela */
			rs = dbmd.getPrimaryKeys(null, null, "TB_MEM_MEMBRO");
			System.out.println( "Chave prim�ria" );
			imprimeResultSet( rs );
      /* Obtendo os campos �nicos de uma tabela */
      rs = dbmd.getIndexInfo(null, null, "TB_MEM_MEMBRO", true, false);
      System.out.println("Campos �nicos da tabela TB_MEM_MEMBRO");
      imprimeResultSet(rs);
		} catch ( SQLException sqle ) {
		System.out.println( "Erro obtendo metadata." );
		}
	}

	public static void imprimeResultSet ( ResultSet rs ){
		try {
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			while ( rs.next() ) {
				for ( int i = 1 ; i <= columnCount ; i++ ) {
					System.out.print( rs.getString( i ) + "     ");
				}
				System.out.println(  );
			}
		} catch ( Exception e ) {
		}
	}
}