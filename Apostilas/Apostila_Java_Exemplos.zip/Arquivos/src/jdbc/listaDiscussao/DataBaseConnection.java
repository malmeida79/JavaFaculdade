/**
 * Classe com m�todos est�tico permitindo a conex�o com o banco de dados e
 * a obten��o do objeto statement para exexu��o de comandos sql
 */
package jdbc.listaDiscussao;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class DataBaseConnection {

	public static Connection getConnection (String driver, String url,
											                    String usuario, String senha )
		throws ClassNotFoundException, SQLException {

		Connection con = null;
		try {
			Class.forName( driver );
			System.out.println( "Driver JDBC carregado" );
			con = DriverManager.getConnection( url, usuario, senha );
			System.out.println( "Conex�o com o banco de dados estabelecida." );
		} catch ( ClassNotFoundException cnfe ) {
			String msg = "Driver JDBC n�o encontrado : " + cnfe.getMessage();
			throw new ClassNotFoundException( msg );
		} catch ( SQLException sqle ) {
			String msg = "Erro na conex�o ao Bando de Dados : " +
						 sqle.getMessage();
			throw new SQLException( msg );
		}
		return con;
	}

	public static Statement getStatement (String driver, String urlBD,
										                    String usuario, String senha)
		throws ClassNotFoundException, SQLException {

		Connection con = null;
		try {
			con = DataBaseConnection.getConnection( driver,  urlBD ,
													usuario, senha );
		} catch ( ClassNotFoundException cnfe ) {
			throw new ClassNotFoundException( cnfe.getMessage() );
		} catch ( SQLException sqle ) {
			throw new SQLException( sqle.getMessage() );
		}
		return con.createStatement();
	}

}