package jdbc.listaDiscussao;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;

public class JavaSqlStoredProcedure implements DataBaseConstantes {

	public static void main ( String[] args ) {

		Statement stmt = null;
		Connection con = null;
		try {
			stmt = DataBaseConnection.getStatement( DRV, URL, USUARIO, SENHA );
			con = DataBaseConnection.getConnection( DRV, URL, USUARIO, SENHA );
      System.out.println("Conex�o com o Banco de dados estabelecida");
		} catch ( ClassNotFoundException cnfe ) {
			System.out.println( cnfe.getMessage() );
		} catch ( SQLException sqle ) {
			System.out.println( sqle.getMessage() );
		}

		/* Criando as Stored Procedures */
    try {
      System.out.println("Criando Stored Procedured 1");
      criaStoredProcedure1(stmt);
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }

    try {
      System.out.println("Criando Stored Procedured 2");
      criaStoredProcedure2(stmt);
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }

    /* Executando as Stored Procedures */
    try {
      System.out.println("Executando Stored Procedured 1");
      executaStoredProcedure1(con, stmt);
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
    try {
      System.out.println("Executando Stored Procedured 2");
      executaStoredProcedure2(con, stmt);
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }

  	/* Fechando a conex�o */
		try {
			con.close();
			System.out.println( "Conex�o com o banco de dados fechada" );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro no fechamento da conex�o : " +
								sqle.getMessage() );
		}
	}

  private static void criaStoredProcedure1 (Statement stmt) {
		/* Comando sql para cria��o da strored procedure */
		String storedProcedure =
			"CREATE PROCEDURE INSERE_MEMBRO" +
			"(@codigo VARCHAR(10), @nome VARCHAR(50), @email VARCHAR(50), @senha VARCHAR(10))" +
			"AS " +
			"  INSERT INTO TB_MEM_MEMBRO (MEM_CD_MEMBRO, MEM_NM_MEMBRO, MEM_EMAIL , MEM_SENHA)" +
			"    VALUES (@codigo, @nome, @email, @senha)";
		try {
			/* Executando o comando sql de cria��o da stored procedure */
			stmt.executeUpdate( storedProcedure );
			System.out.println( "Stored Procedure criada" );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro criando a Stored Procedure :" +
								sqle.getMessage() );
		}

  }
  private static void criaStoredProcedure2 (Statement stmt) {
		/* Exemplo de Stored Procedure que retorna valores */
		String storedProcedure =
			"CREATE PROCEDURE MEMBRO_LOGIN" +
			"(@codigo VARCHAR(10))" +
			"AS" +
			" SELECT MEM_EMAIL, MEM_SENHA" +
      "   FROM TB_MEM_MEMBRO " +
			"   WHERE MEM_CD_MEMBRO = @codigo";

		try {
			stmt.executeUpdate( storedProcedure );
			System.out.println( "Stored Procedure criada" );
		} catch ( SQLException sqle ) {
			System.out.println("Erro criando a Stored Procedure :" +
								         sqle.getMessage() +
                         "ErrorCode: " + sqle.getErrorCode());
		}
  }

  private static void executaStoredProcedure1 (Connection con, Statement stmt) {
		/* Excetudando a Stored Procedure */
		try {
			/* String com a chamada a stored procedure */
			String storedProcedureCall = "{call INSERE_MEMBRO(?,?,?,?)}";
			/* Preparando chamada � estored procedure */
			CallableStatement cstmt = con.prepareCall( storedProcedureCall );
			/* Setando os par�metros da stored procedure */
			String codigo = "90";
			String nome = "Zagallo";
			String email = "zagallo@flamengo.com.br";
			String senha = "4x0";
			cstmt.setString(1, codigo);
			cstmt.setString(2, nome);
			cstmt.setString(3, email);
			cstmt.setString(4, senha);
			/* Executando a stotred procedure */
			cstmt.executeUpdate();
			System.out.println("Stored Procedure Executada.");
		} catch ( SQLException sqle ) {
			System.out.println("Erro executando a Stored Procedure: " +
								         sqle.getMessage() +
                         "ErrorCode: " + sqle.getErrorCode());
		}
  }

  private static void executaStoredProcedure2 (Connection con, Statement stmt) {
		/* Preparando, excetudando e retornando valores da Stored Procedure */
		try {
			String storedProcedureCall = "{call MEMBRO_LOGIN(?)}";
			CallableStatement cstmt = con.prepareCall( storedProcedureCall );
			String codigo = "90";
			cstmt.setString(1, codigo);
//			cstmt.execute();
			/* Executando a stored procedure e obtendo o seu retorno */
			ResultSet rs = cstmt.executeQuery();
			if ( rs.next() ) {
				String email = rs.getString(1);
				String senha = rs.getString(2);
				System.out.println("Email : " + email);
				System.out.println("Senha : " + senha);
			}
			System.out.println( "Stored Procedure Executada." );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro executando a Stored Procedure : " +
								         sqle.getMessage() +
                         "ErrorCode: " + sqle.getErrorCode());
		}
  }
}