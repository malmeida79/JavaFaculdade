package jdbc.listaDiscussao;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class JavaSqlResultSetMetaData implements DataBaseConstantes {

	public static void main(String[] args) {
		Statement stmt = null;
		try {
			stmt = DataBaseConnection.getStatement(DRV,URL , USUARIO, SENHA );
		} catch ( ClassNotFoundException cnfe ) {
			System.out.println( cnfe.getMessage() );
		} catch ( SQLException sqle ) {
			System.out.println( sqle.getMessage() );
		}

		try {
			/* Comando sql a ser executado */
			String query = "SELECT * FROM TB_LST_LISTA";
			/* Executando o comando sql */
			ResultSet rs = stmt.executeQuery( query );
			/* Obtendo objeto com metadados do resultado da execu��o */
			ResultSetMetaData rsmd = rs.getMetaData();
			System.out.println( "[ ColumnLabel , ColumnName, " +
								"ColumnType , ColumnTypeName ]" );
			/* Obtendo metados */
			for ( int i = 1 ; i <= rsmd.getColumnCount() ; i++ ) {
				System.out.print( 	rsmd.getColumnLabel( i ) + " , " );
				System.out.print( 	rsmd.getColumnName( i ) + " , " );
				System.out.print(	rsmd.getColumnType( i ) + " , " );
				System.out.println( rsmd.getColumnTypeName( i ) );
			}
		} catch ( SQLException sqle ) {
			System.out.println( "Erro obtendo metadadata :" +
								sqle.getMessage() );
		}
	}
}