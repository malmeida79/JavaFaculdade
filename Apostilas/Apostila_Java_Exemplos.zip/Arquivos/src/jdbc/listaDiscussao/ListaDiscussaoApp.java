package jdbc.listaDiscussao;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;


public class ListaDiscussaoApp implements DataBaseConstantes {

	public static void main(String[] args) {

		/* Carregando o driver JDBC para um determinado SGBD*/
		try {
			/* Instanciando a classe do driver atrav�s do seu nome */
			Class.forName( DRV );
			System.out.println( "Driver JDBC carregado" );
		} catch ( ClassNotFoundException cnfe ) {
			System.out.println( "Driver JDBC n�o encontrado : " +
							   cnfe.getMessage() );
		}

		/* Criando conex�o com o banco de dados */
		Connection con = null;
		try {
			/* Obtendo a conex�o com o banco de dados */
			con = DriverManager.getConnection( URL, USUARIO, SENHA );
			System.out.println( "Conex�o com o banco de dados estabelecida." );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro na conex�o ao Bando de Dados : " +
							            sqle.getMessage() );
		}

		/* Obtendo objeto para executar comandos sql */
		Statement stmt = null;
		try {
			stmt = con.createStatement();
			System.out.println( "Prepara��o para execu��o de comandos sql." );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro no acesso ao Bando de Dados : " +
								          sqle.getMessage() );
		}

		/* Executando comandos SQL */

		/* criando tabelas */
    try {
  		criaTabelas( stmt );
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }


		/* Inserindo dados nas tabelas */
    try {
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }

		/* Consultando as tabelas */
			consultaTabelas( stmt );

		/* fechando a conex�o com o SGBD */
		try {
			con.close();
			System.out.println( "Conex�o com o banco de dados fechada" );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro no fechamento da conex�o : " );
		}
	}

	public static void criaTabelas ( Statement stmt ) throws SQLException {

		/* Comandos sql para cria��o das tabelas */
		final String TB_MEM_MEMBRO =
			"CREATE TABLE TB_MEM_MEMBRO (" +
				"MEM_CD_MEMBRO VARCHAR(10) NOT NULL," +
				"MEM_NM_MEMBRO VARCHAR(50) NOT NULL, " +
				"MEM_EMAIL VARCHAR(50) NOT NULL UNIQUE," +
				"MEM_SENHA VARCHAR(10) NOT NULL," +
				"PRIMARY KEY (MEM_CD_Membro)" +
			");";

		final String TB_LST_LISTA =
			"CREATE TABLE TB_LST_LISTA (" +
				"LST_CD_LISTA VARCHAR(10) NOT NULL," +
				"LST_NN_LISTA VARCHAR(40) NOT NULL UNIQUE," +
				"LST_OBJETIVO VARCHAR(30) NOT NULL," +
				"LST_DT_CRIACAO DATETIME NOT NULL," +
				"PRIMARY KEY (LST_CD_LISTA)" +
			");";

		final String TB_ML_MEMBRO_LISTA =
			"CREATE TABLE TB_ML_MEMBRO_LISTA (" +
				"ML_CD_MEMBRO VARCHAR(10) NOT NULL," +
				"ML_CD_LISTA VARCHAR(10) NOT NULL," +
				"ML_DT_ENTRADA DATETIME NOT NULL," +
				"ML_DT_SAIDA DATETIME," +
				"PRIMARY KEY (ML_CD_MEMBRO, ML_CD_LISTA)," +
				"FOREIGN KEY (ML_CD_LISTA)" +
					"REFERENCES TB_LST_LISTA," +
				"FOREIGN KEY (ML_CD_MEMBRO)" +
					" REFERENCES TB_MEM_MEMBRO" +
			");";

		final String TB_MSG_MENSAGEM =
			"CREATE TABLE TB_MSG_MENSAGEM (" +
				"MSG_CD_MENSAGEM VARCHAR(10) NOT NULL," +
				"MSG_CD_LISTA VARCHAR(10) NOT NULL," +
				"MSG_TITULO VARCHAR(20) NOT NULL," +
				"MSG_DT_MENSAGEM CHAR(18) NOT NULL," +
				"MSG_MENSAGEM VARCHAR(400) NOT NULL," +
				"PRIMARY KEY (MSG_CD_MENSAGEM)," +
				"FOREIGN KEY (MSG_CD_LISTA) REFERENCES TB_LST_LISTA" +
			");";
		try {
			/* Executando comandos sql de atualiza��o */
			stmt.executeUpdate( TB_MEM_MEMBRO );
			System.out.println( TB_MEM_MEMBRO );

			stmt.executeUpdate( TB_LST_LISTA );
			System.out.println( TB_LST_LISTA );

			stmt.executeUpdate( TB_MSG_MENSAGEM );
			System.out.println( TB_MSG_MENSAGEM );

			stmt.executeUpdate( TB_ML_MEMBRO_LISTA );
			System.out.println( TB_ML_MEMBRO_LISTA );

			System.out.println( "<<<<< TABELAS CRIADAS >>>>>" );
		} catch ( SQLException sqle ) {
			throw new SQLException("Erro na cria�ao das tabelas : " +
								          "getMessage()   = " + sqle.getMessage() +
								          "\ngetErrorCode() = " +  sqle.getErrorCode() );
		}
	}

	public static void insereDadosTabelas ( Statement stmt ) throws SQLException {
		try {
			String insert;
			/* Inserindo na tabela de membros */
			insert = "INSERT INTO TB_MEM_MEMBRO VALUES " +
					 "('1', 'Bill Gates', 'bill@micrososoft.com', 'windows')";
			System.out.println( insert );
			stmt.executeUpdate(insert);
			insert = "INSERT INTO TB_MEM_MEMBRO VALUES " +
					 "('2', 'Pel�', 'pele@futebol.com.br', 'gol')";
			System.out.println( insert );
			stmt.executeUpdate(insert);
			insert = "INSERT INTO TB_MEM_MEMBRO VALUES " +
					 "('3', 'Senna', 'senna@f1.com.br', 'galisteu')";
			System.out.println( insert );
			stmt.executeUpdate(insert);
			System.out.println( "Registros de membros inseridos." );

			/* Inserindo na tabela de lista */
			/* Obtendo a hora corrente e formatando para o comando insert */
		 	SimpleDateFormat formatter
		    	= new SimpleDateFormat ( "dd-MMM-yyyy",  Locale.US );
			Date currentTime = new Date( System.currentTimeMillis() );
			String data = formatter.format( currentTime );

			insert = "INSERT INTO TB_LST_LISTA VALUES " +
					 "('1', 'Inform�tica', 'Java', '" + data.toUpperCase() +
					 "')";
			stmt.executeUpdate(insert);
			System.out.println( insert );
			insert = "INSERT INTO TB_LST_LISTA VALUES " +
					 "('2', 'Futebol', 'Futebol', '" + data.toUpperCase() +
					 "');";
			stmt.executeUpdate(insert);
			System.out.println( insert );
			insert = "INSERT INTO TB_LST_LISTA VALUES " +
					 "('3', 'F�rmula 1', 'F1', '" + data.toUpperCase() +
					 "')";
			stmt.executeUpdate(insert);
			System.out.println( insert );
			System.out.println( "Registros de lista inseridos." );
		} catch ( SQLException sqle ) {
			throw new SQLException("Erro inserindo registros : \n" +
								          "getMessage()   = " + sqle.getMessage() +
								          "\ngetErrorCode() = " +  sqle.getErrorCode() );
		}
	}

	public static void consultaTabelas( Statement stmt ) {
		try {
			/* Consultando a tabela de Membros */
			String selectTbMembro = "SELECT * FROM TB_MEM_Membro";
			System.out.println( selectTbMembro );
			/* Executando e obtendo o resultado do comandos sql de consulta */
			ResultSet rs = stmt.executeQuery( selectTbMembro );
			/* Navegando pelo resultado */
			while ( rs.next() ) {
				System.out.print( rs.getString( "MEM_NM_Membro" ) );
				System.out.print( " - " );
				System.out.println( rs.getString( "MEM_Email" ) );
			}

			/* Consultando a tabela de Listas */
			String selectTbLista = "select * from TB_LST_Lista";
			System.out.println( selectTbLista );
			/* Obtendo o resultado do comando SQL */
			rs = stmt.executeQuery( selectTbLista );
			/* Navegando pelo resultado */
			while ( rs.next() ) {
				System.out.print( rs.getString( 2 ) );
				System.out.print( " - " );
				System.out.println( rs.getString( 3 ) );
			}

		} catch ( SQLException sqle ) {
			System.out.println( "Erro executando consulta : " +
								sqle.getMessage() );
		}
	}
}