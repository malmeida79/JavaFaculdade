package jdbc.listaDiscussao;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class JavaSqlTransacao implements DataBaseConstantes {

    public static void main(String[] args) {
		Connection con = null;
		Statement stmt = null;
		try {
			Class.forName( DRV );
			System.out.println( "Driver JDBC carregado" );
			con = DriverManager.getConnection( URL, USUARIO, SENHA );
			System.out.println( "Conex�o com o banco de dados estabelecida." );
			stmt = con.createStatement();
		} catch ( ClassNotFoundException cnfe ) {
			System.out.println( "Driver JDBC n�o encontrado : " +
							   cnfe.getMessage() );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro na conex�o ao Bando de Dados : " +
							   sqle.getMessage() );
		}

		/* Comandos sql da transa��o */
		String comando1 = "INSERT INTO TB_MEM_MEMBRO VALUES " +
					 "('99', 'Luis Amstrong', 'la@musica.com', 'music')";
		String comando2 = "INSERT INTO TB_LST_LISTA VALUES " +
					 "('99', 'M�sica', 'M�sica', '15-JAN-2000')";
		/* Criando a transa�ao */
		try {
			/* Desligando o Commit autom�tico */
			con.setAutoCommit( false );
			/* Executando o primeiro comando da transa��o */
			stmt.executeUpdate( comando1 );
			/* Simulando o acontecimento de uma exce��o */
			if ( true ) {
				throw new SQLException("Erro provocado");
			}
			/* Executando o segundo comando da transa��o */
			stmt.executeUpdate( comando2 );
			/* Efetuando o Commit */
			con.commit();
			System.out.println( "Transa��o realizada" );
		} catch ( SQLException sqle ) {
			/* Desfazendo os comandos */
			try {
				con.rollback();
				System.out.println( "Transa��o n�o realizada" );
			} catch ( SQLException sqlerb ) {
				System.out.println( "Erro na recupera��o das transa��es : " +
									sqlerb.getMessage() );
			}
		} finally {
			/* Ligando o Commit autom�tico */
			try {
				con.setAutoCommit( true );
			} catch ( SQLException e ) {
				System.out.println( "Erro ligando o AutoCommmit" +
									e.getMessage() );
			}
		}
    }
}