package jdbc.listaDiscussao;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class JavaSqlPreparedStatement implements DataBaseConstantes {

	public static void main( String[] args ) {
		Connection con = null;
		try {
			Class.forName( DRV );
			System.out.println( "Driver JDBC carregado" );
			con = DriverManager.getConnection( URL, USUARIO, SENHA );
			System.out.println( "Conex�o com o banco de dados estabelecida." );
		} catch ( ClassNotFoundException cnfe ) {
			System.out.println( "Driver JDBC n�o encontrado : " +
							   cnfe.getMessage() );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro na conex�o ao Bando de Dados : " +
							   sqle.getMessage() );
		}

		/* Executando comandos sql atrav�s do objeto PreparedStatement */
		try {
			/* Selecionando Lista por c�digo */
			String selectLista = "SELECT * FROM TB_LST_LISTA" +
								           "	WHERE LST_CD_LISTA = ?";
			/* Criando o comando sql preparado */
			PreparedStatement ps = con.prepareStatement( selectLista );
			for ( int i = 1; i <= 3 ; i ++ ) {
				/* Substituindo par�metros do comando sql preparado */
				ps.setString( 1, Integer.toString( i ) );
				/* Executando o comandos sql preparado */
				ResultSet rs = ps.executeQuery();
				/* Exibindo os resultados */
				if ( rs.next() ) {
					System.out.println( i + " - " + rs.getString( 2 ) );
				}
			}
		} catch ( SQLException sqle ) {
			System.out.println( "Erro efetuando consulta : " +
								sqle.getMessage() );

		}

		try {
			con.close();
			System.out.println( "Conex�o com o banco de dados fechada" );
		} catch ( SQLException sqle ) {
			System.out.println( "Erro no fechamento da conex�o : " +
								sqle.getMessage() );
		}
	}
}