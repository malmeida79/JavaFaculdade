package jdbc.listaDiscussao;

public interface DataBaseConstantes {
	/* Nomes dos drives JDBC do Interbase, SqlServer e Oracle*/
//	public final static String DRV =	"interbase.interclient.Driver";
//	public final static String DRV =	"oracle.jdbc.driver.OracleDriver";
	public final static String DRV =		"com.microsoft.jdbc.sqlserver.SQLServerDriver";

	/* URLs para o Interbase, SqlServer e Oracle*/
//	public final static String URL =	"jdbc:interbase://localhost/D:/temp/BD.GDB";
//	public final static String URL =	"jdbc:oracle:thin:@localhost:1521:ORCL";
	public final static String URL =	"jdbc:microsoft:sqlserver://localhost:1433";

	/* Usu�rio e senha para conex�o */
	public final static String USUARIO = "ListaDiscussao";
	public final static String SENHA = "ListaDiscussao";
}