package jdbc;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.util.Vector;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import interbase.interclient.Driver;


public class JDBC extends JFrame {
    JPanel jPanelApp = new JPanel();
    JPanel jPanelConfig = new JPanel();
    JPanel jPanelQuery = new JPanel();
    JScrollPane jScrollPaneQuery = new JScrollPane();
    JTable jTableQuery = new JTable();
    JLabel jLabel1 = new JLabel();
	String[] drivers = {"sun.jdbc.odbc.JdbcOdbcDriver",
						"interbase.interclient.Driver",
						"com.inet.tds.TdsDriver"};
    JComboBox jComboBoxDriver = new JComboBox(drivers);
    JLabel jLabel2 = new JLabel();
    JTextField jTextFieldURL = new JTextField();
    JLabel jLabel3 = new JLabel();
    JLabel jLabel4 = new JLabel();
    JTextField jTextFieldUsuario = new JTextField();
    JTextField jTextFieldSenha = new JTextField();
    JTextArea jTextAreaQuery = new JTextArea();
    JButton jButtonExecutar = new JButton();
    JButton jButtonLimpar = new JButton();
    JButton jButtonSair = new JButton();
    JRadioButton jRadioButtonQuery = new JRadioButton();
    JRadioButton jRadioButtonUpdate = new JRadioButton();
    ButtonGroup buttonGroup1 = new ButtonGroup();
    JTable jTableResultado = new JTable();
    BorderLayout borderLayout1 = new BorderLayout();

    public JDBC() {
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        JDBC jdbc = new JDBC();
		jdbc.setSize(530,450);
		jdbc.show();
    }

    private void jbInit() throws Exception {
        jPanelApp.setLayout(null);
        jPanelConfig.setBorder(BorderFactory.createEtchedBorder());
        jPanelConfig.setBounds(new Rectangle(5, 5, 518, 145));
        jPanelConfig.setLayout(null);
        jPanelApp.setBorder(BorderFactory.createLineBorder(Color.black));
        jPanelQuery.setBorder(BorderFactory.createEtchedBorder());
        jPanelQuery.setBounds(new Rectangle(7, 154, 515, 264));
        jPanelQuery.setLayout(borderLayout1);
        jScrollPaneQuery.setAutoscrolls(true);
        jLabel1.setText("Driver");
        jLabel1.setBounds(new Rectangle(4, 5, 41, 17));
        jComboBoxDriver.setBounds(new Rectangle(60, 5, 448, 20));
		jComboBoxDriver.setSelectedIndex(1);
        jComboBoxDriver.addItemListener(new java.awt.event.ItemListener() {

            public void itemStateChanged(ItemEvent e) {
                jComboBoxDriver_itemStateChanged(e);
            }
        });

		String bd = "jdbc:interbase://localhost/D:/MeusDocumentos/CursoDeJava" +
				"/Standard/Fontes/src/jdbc/listaDiscussao/LISTADISCUSSAO.GDB";
        jTextFieldURL.setText(bd);
        jLabel2.setText("URL");
        jLabel2.setBounds(new Rectangle(6, 34, 30, 17));
        jTextFieldURL.setBounds(new Rectangle(60, 36, 451, 19));
        jLabel3.setText("Usu�rio");
        jLabel3.setBounds(new Rectangle(8, 60, 55, 17));
        jLabel4.setText("Senha");
        jLabel4.setBounds(new Rectangle(8, 86, 41, 17));
        jTextFieldUsuario.setBounds(new Rectangle(60, 59, 84, 21));
        jTextFieldUsuario.setText("SYSDBA");
        jTextFieldSenha.setBounds(new Rectangle(60, 83, 84, 21));
        jTextFieldSenha.setText("masterkey");
        jTextAreaQuery.setBorder(BorderFactory.createLineBorder(Color.black));
		String qry = "SELECT * FROM TB_MEM_MEMBRO ORDER BY MEM_NM_MEMBRO";
        jTextAreaQuery.setText( qry );
        jTextAreaQuery.setBounds(new Rectangle(150, 56, 360, 54));
        jButtonExecutar.setText("Executar");
        jButtonExecutar.setBounds(new Rectangle(10, 111, 91, 27));
        jButtonExecutar.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                jButtonExecutar_mouseClicked(e);
            }
        });
        jButtonLimpar.setText("Limpar");
        jButtonLimpar.setBounds(new Rectangle(108, 112, 94, 26));
        jButtonLimpar.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                jButtonLimpar_mouseClicked(e);
            }
        });
        jButtonSair.setText("Sair");
        jButtonSair.setBounds(new Rectangle(210, 113, 74, 25));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(ActionEvent e) {
                jButtonSair_actionPerformed(e);
            }
        });
        jRadioButtonQuery.setText("Query");
		jRadioButtonQuery.setSelected(true);
        jRadioButtonQuery.setBounds(new Rectangle(290, 112, 59, 25));
        jRadioButtonUpdate.setText("Update");
        jRadioButtonUpdate.setBounds(new Rectangle(355, 113, 66, 25));
		this.setDefaultCloseOperation(3);
        this.setResizable(false);
        this.setTitle("SQL");
        buttonGroup1.add(jRadioButtonQuery);
		buttonGroup1.add(jRadioButtonUpdate);
        this.getContentPane().add(jPanelApp, BorderLayout.CENTER);
        jPanelApp.add(jPanelConfig, null);
        jPanelConfig.add(jLabel1, null);
        jPanelConfig.add(jLabel2, null);
        jPanelConfig.add(jLabel3, null);
        jPanelConfig.add(jLabel4, null);
        jPanelConfig.add(jComboBoxDriver, null);
        jPanelConfig.add(jTextFieldURL, null);
        jPanelConfig.add(jTextFieldUsuario, null);
        jPanelConfig.add(jTextFieldSenha, null);
        jPanelConfig.add(jTextAreaQuery, null);
        jPanelConfig.add(jButtonExecutar, null);
        jPanelConfig.add(jButtonLimpar, null);
        jPanelConfig.add(jButtonSair, null);
        jPanelConfig.add(jRadioButtonQuery, null);
        jPanelConfig.add(jRadioButtonUpdate, null);
        jPanelApp.add(jPanelQuery, null);
        jPanelQuery.add(jScrollPaneQuery, BorderLayout.CENTER);
    }
    void jButtonSair_actionPerformed(ActionEvent e) {
		System.exit( 0 );
    }

    void jComboBoxDriver_itemStateChanged(ItemEvent e) {
		String interbase 	= "jdbc:interbase";
		String odbc 		= "jdbc:odbc:odbc";
		String complemento	= "://Servidor:BancoDeDados";
		if ( jComboBoxDriver.getSelectedIndex() == 1 ) {
			jTextFieldURL.setText(interbase + complemento);
		} else {
			jTextFieldURL.setText(odbc + complemento);
		}
    }

    void jButtonExecutar_mouseClicked(MouseEvent e) {
		executarConsulta();
    }

	private void executarConsulta () {
		try {
			/* Carregando o driver de banco de dados */
			Class.forName(jComboBoxDriver.getSelectedItem().toString());
			/* Conectando ao banco de dados */
			Connection connection
				= DriverManager.getConnection(jTextFieldURL.getText(),
											  jTextFieldUsuario.getText(),
											  jTextFieldSenha.getText());
			/* Obtendo objeto para execu��o de comandos sql */
			Statement stmt = connection.createStatement();
			if (jRadioButtonQuery.isSelected()) {
				/* Executando comando sql */
				ResultSet rs = stmt.executeQuery(jTextAreaQuery.getText());
				/* Obtendo metadada do ResultSet : Colunas */
				ResultSetMetaData rsmd = rs.getMetaData();
				Vector colunas = colunas (rsmd);
				/* Obtendo dados do ResultSet */
				Vector linhas = new Vector();
				while (rs.next()) {
					linhas.addElement(linha(rs,rsmd));
				}
				/* Inserindo os dados no Objeto jTable */
				jTableResultado = new JTable(linhas, colunas);
		        jScrollPaneQuery.getViewport().add(jTableResultado, null);
			} else {
				stmt.executeUpdate(jTextAreaQuery.getText());
			}
			connection.close();
		} catch (ClassNotFoundException classEx) {
			String msg = "Erro ao carregar o driver";
			JOptionPane.showMessageDialog(null, msg + "\n" +
										  classEx.getMessage(), "Erro",
										  JOptionPane.ERROR_MESSAGE);
		} catch (SQLException sqlEx) {
			String msg = "Erro na conex�o ao banco de dados";
			JOptionPane.showMessageDialog(null, msg + "\n" +
										  sqlEx.getMessage(), "Erro",
										  JOptionPane.ERROR_MESSAGE);
		} catch (Exception ex) {
			String msg = "Erro Geral" + ex.getMessage();
			JOptionPane.showMessageDialog(null, msg + "\n" +
										  ex.getMessage(), "Erro",
										  JOptionPane.ERROR_MESSAGE);
		}
	}

	private Vector colunas (ResultSetMetaData rsmd) {
		Vector colunas = new Vector();
		try {
			for (int i = 1 ; i <= rsmd.getColumnCount(); i++ ) {
				colunas.addElement(rsmd.getColumnName(i));
			}
		} catch (SQLException e) {}

		return colunas;
	}

	private Vector linha (ResultSet rs, ResultSetMetaData rsmd)
						  throws SQLException {
		Vector linha = new Vector();
		/* Obtendo os valores dos campos e inserindo-os no Vector*/
		for ( int i = 1 ; i <= rsmd.getColumnCount(); i++ ) {
			/* Verificando no ResultSetMetaData o tipo do campo,
			 * para utilizar o m�todo ResultSet.getXXXX(int) adequado
			 */
			switch ( rsmd.getColumnType(i) ) {
				case Types.CHAR:
				case Types.VARCHAR:
				case Types.LONGVARCHAR:
					linha.addElement( rs.getString(i) );
					break;
				case Types.DECIMAL:
				case Types.NUMERIC:
					linha.addElement( new Float( rs.getFloat(i) ) );
					break;
				case Types.BIT:
					linha.addElement( new Boolean ( rs.getBoolean(i) ) );
					break;
				case Types.TINYINT:
				case Types.SMALLINT:
				case Types.INTEGER:
					linha.addElement( new Long( rs.getLong(i) ) );
					break;
				case Types.FLOAT:
				case Types.DOUBLE:
	                linha.addElement( new Double ( rs.getDouble(i) ) );
					break;
				case Types.DATE:
					linha.addElement( rs.getDate(i) );
					break;
				case Types.TIME:
					linha.addElement( rs.getTime(i) );
					break;
				default :
					linha.addElement( " Tipo n�o Tratado" );
			}
		}
		return linha;
	}

    void jButtonLimpar_mouseClicked(MouseEvent e) {
		jTextAreaQuery.setText("");
    }
}