import java.awt.*;
import java.awt.event.*;

/* Classe para exemplificar o uso do AWT */

public class GUIWindow extends Frame implements ActionListener {
	boolean inAnApplet = true;
	final String FILEDIALOGMENUITEM = "File Dialog...";
	
	public GUIWindow() {
		Panel bottomPanel = new Panel();
		Panel centerPanel = new Panel();
		setLayout(new BorderLayout());
		
		// MenuBar
		MenuBar mb = new MenuBar();
		Menu m = new Menu("menu");
		m.add(new MenuItem("Menu Item 1"));
		m.add(new CheckboxMenuItem("Menu Item 2"));
		m.add(new MenuItem("Menu Item 3"));
		m.add(new MenuItem("-"));
		
		MenuItem fileMenuItem = new MenuItem(FILEDIALOGMENUITEM);
		fileMenuItem.addActionListener(this);
		
		mb.add(m);
		setMenuBar(mb);
		
		// Componentes na parte inferior
		bottomPanel.add(new TextField("TextField"));
		bottomPanel.add(new Button("Button"));
		bottomPanel.add(new Checkbox("CheckBox"));
		Choice c = new Choice();
		c.add("Choice Item 1");
		c.add("Choice Item 2");
		c.add("Choice Item 3");
		bottomPanel.add(c);
		add("South", bottomPanel);
		
		//Componentes no centro
		centerPanel.setLayout(new GridLayout(1,2));
		//Canvas
		centerPanel.add(new Canvas());
		//Label e Text
		Panel p = new Panel();
		p.setLayout(new BorderLayout());
		p.add("North", new Label("Label", Label.CENTER));
		p.add("Center", new TextArea("TextArea", 5, 20));
		centerPanel.add(p);
		add("Center", centerPanel);
		
		/*
		...
		*/
		
		
	}
	
	public void actionPerformed (ActionEvent event) {
		//O �nico evento tratado � o de abertura do FileDialog
		FileDialog fd = new FileDialog(this, "FileDialog");
		fd.setVisible(true);
	}
	
	
	public static void main (String[] args) {
		GUIWindow window = new GUIWindow();
		window.inAnApplet = false;
		
		window.setTitle("Componentes AWT");
		window.pack();
		window.setVisible(true);
	}
	
}