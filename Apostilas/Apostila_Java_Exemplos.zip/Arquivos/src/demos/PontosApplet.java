import java.awt.Graphics;
import java.awt.Color;
import java.awt.Event;

public class PontosApplet extends java.applet.Applet {
	final int MAX_PONTOS = 100;
	int xPontos[] = new int[MAX_PONTOS];
	int yPontos[] = new int[MAX_PONTOS];
	int pontoCorrente = 0;
	
	public void init () {
		setBackground(Color.white);
	}
	
	public boolean mouseDown (Event evt, int x, int y) {
		if (pontoCorrente < MAX_PONTOS) {
			addPonto(x,y);
			return true;
		}
		else {
			System.out.println("Limite de pontos ultrapassados");
			return false;
		}
	}
	
	void addPonto (int x, int y) {

		xPontos[pontoCorrente] = x;
		yPontos[pontoCorrente] = y;
		pontoCorrente++;
		repaint();
	}
	
	public void paint (Graphics g) {

		g.setColor(Color.blue);
		for (int i = 0; i < pontoCorrente; i++) {
			g.fillOval(xPontos[i] - 1, yPontos[i] - 1, 2, 2);
		}
	}
}