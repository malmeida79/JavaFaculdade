/*
 * Infonet	: 19/05/2000
 * @author	: Jos� Maria R Santos Junior
 * email	: zemaria@infonet.com.br
 * www		: www.unit.br/zemaria

 * Classe para representar um n�mero de C�digo de Barras no Padr�o I25.
 * (2 de 5 Intervalado)
 * Permitindo o calculo do digito verificador e a inser��o do mesmo
 * na sua respectiva posi��o (4)
 */
public class BarcodeI25Number {
	/*
	 * A posi��o 4 � o d�gito verificador, sendo que o array de char
	 * com�a na posi��o 0 (zero).
	 */
	private static final int digitoPos 	= 3;
	private static final int compNumero	= 43;

	/** <B>Calcula o d�gito verificador</B>
	 * @return Digito Verificador
	 * @param numero <B>n�mero do c�digo de barras sem o d�gito verificador</B>
	 * @throws NumberFormatException O n�mero deve possuir apenas d�gitos num�ricos
	 */
	public static String digitoVerificador (String numero) 
                                    throws NumberFormatException {

		char[] charNumero = numero.toCharArray();
		int soma 	= 0;		// Soma do produtor
		int fator		= 1;	// Fator de multiplica��o (2 1 2 1 2 1 2 1 ...)
		int sinal		= 1;	// Sinal para permitir a alternancia do fator
		int charI		= 0;	// Caracter da posi��o i
		int produto 	= 0;	// Produto do charI pelo fator
		int resto		= 0;	// Resto do produto por 10
		int digito	= 0;		// Digito verificador

		/*
		 * C�lculo da soma do produtos de cada posi��o pelo fator
		 * i vai da �ltima posi��o do n�mero at� a primeita (43-1),
		 * sendo que a �ltima posi��o de um array � (array.length -1) e
		 * a primeira � 0 (zero)
		 */
		for (int i = (charNumero.length - 1); i >= 0; i-- ) {
			try {
				/* Concatena��o do char com "" para converter em String */
				charI = Integer.parseInt(charNumero[i] + "");
			} catch (NumberFormatException e) {
				String msg = "N�mero fora do padr�o 2 de 5 intercalado. " +
							 "Esse padr�o permite apenas d�gitos num�ricos";
				throw new NumberFormatException(msg);
			}
			/* Altern�ncia 2 1 2 1 2 1 2 1 ... do fator de multiplica��o */
			fator += sinal;
			sinal = -sinal;
			produto = charI * fator;
			if (produto >= 10)  {
				produto = (produto % 10) + (produto / 10);
			}
			soma += produto;
		}
		/* C�lculo do digito */
		resto = soma % 10;
		if (resto == 0)  {
			digito = 0;
		} else {
			digito = ( 10 - (resto) );
		}

		return Integer.toString(digito);
	}

		/** <B>Calcula e insere o d�gito verificador formando o n�mero
	 * completo</B>
	 * @return n�mero com o d�gito verificador
	 * @param numero <B>n�mero do c�digo de barras sem o d�gito verificador</B>
	 * @throws NumberFormatException n�mero deve possui exatamente 43 posi��es
	 */
		public static String numeroCompleto(String numero)
									 throws NumberFormatException {

			if (numero.length() != compNumero){
				String msg = "N�mero fora do padr�o 2 de 5 intercalado" +
							 "O n�mero deve possuir exatamente 43 posi��es";
				throw new NumberFormatException(msg);
			}
			StringBuffer numeroCompleto = new StringBuffer(new String(numero));
			String digVer = digitoVerificador(numero);
			numeroCompleto = numeroCompleto.insert(digitoPos,digVer);

			return (numeroCompleto.toString());
		}
}