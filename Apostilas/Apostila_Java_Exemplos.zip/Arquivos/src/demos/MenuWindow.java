import java.awt.*;
import java.awt.event.*;

public class MenuWindow extends Frame implements ActionListener, ItemListener {
	
}