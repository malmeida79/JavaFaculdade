public class Comandos {
    public static void main (String[] args) {
    	int n = 5;
	int Fat = 1;
	for (; n > 1; n--) {
	    Fat *= n;
	}

	Fat = 1;
	n = 5;
	while (n > 1) {
	    Fat *= n;
	    n--;
	}

        System.out.println(Fat);
    }
}