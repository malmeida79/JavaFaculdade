import java.awt.*;
import java.awt.event.*;

/* Classe para exemplificar o uso do AWT */

public class Beeper extends Frame implements ActionListener {
	
	static final String DISABLE = "disable";
	static final String ENABLE  = "enable";
	Button b;

	public Beeper() {
		
		setLayout(new BorderLayout());
		// Bot�o 1
		b = new Button();
		b.setLabel("Aperte");
				
		//Respostas aos eventos do bot�es 1 e 3
		b.addActionListener(this);
		
		//Adiciona os bot�es usando o padr�o FlowLayout
		add("North");
		
	}
	
	public void actionPerformed (ActionEvent event) {
		Toolkit.getDeafaultToolkit().beep();
			
	}
	
	
	public static void main (String[] args) {
		Beeper window = new Beeper();
		
		window.setTitle("Bot�es");
		window.pack();
		window.setVisible(true);
	}
	
}