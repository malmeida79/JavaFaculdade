class Data {
	public static void main (String[] args) {
		int 			iMes;
		String[] Meses = {"Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"};
		String 	sbMes = new String();
		if (args.length != 0) {
		     	iMes = Integer.parseInt(args[0]);
			
			if ((iMes >= 1) && (iMes <= 12))
				sbMes = Meses[iMes-1];
/*			
			switch (iMes) {
				case 1  : sbMes = new StringBuffer("Jan"); break;
				case 2  : sbMes = new StringBuffer("Fev"); break;
				case 3  : sbMes = new StringBuffer("Mar"); break;
				case 4  : sbMes = new StringBuffer("Abr"); break;
				case 5  : sbMes = new StringBuffer("Mai"); break;
				case 6  : sbMes = new StringBuffer("Jun"); break;
				case 7  : sbMes = new StringBuffer("Jul"); break;
				case 8  : sbMes = new StringBuffer("Ago"); break;
				case 9  : sbMes = new StringBuffer("Set"); break;
				case 10 : sbMes = new StringBuffer("Out"); break;
				case 11 : sbMes = new StringBuffer("Nov"); break;
				case 12 : sbMes = new StringBuffer("Dez"); break;
				default : System.out.println("M�s Inv�lido");
			}
*/
			System.out.println(sbMes.toString());
		}
	}
}