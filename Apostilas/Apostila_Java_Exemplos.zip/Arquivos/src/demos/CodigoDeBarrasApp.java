public class CodigoDeBarrasApp {
	public static void main (String[] args) {
		String numero = "8220000215"+"04820097412"+"322015409829"+"0108605940";
//		String numero = "8360000014"+"13460049005"+"38805003000"+"00000000000";
		
		try {
			System.out.println("N�mero  : " + numero);
			System.out.println("Tamanho : " + numero.length());
			System.out.println("D�gito  : " + BarcodeI25Number.digitoVerificador(numero));
			System.out.println("N�mero  : " + BarcodeI25Number.numeroCompleto(numero));
		} catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		}
	}
}