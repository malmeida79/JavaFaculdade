import java.util.*;
import java.lang.System.*;
import java.util.Properties;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;


class AtributosDoSistema {
	public static void main (String[] args) {

		Properties   p = System.getProperties();
		StringBuffer s;
		for (Enumeration e = p.propertyNames(); e.hasMoreElements() ;) {
         		s = new StringBuffer(String.valueOf(e.nextElement()));
			System.out.println(s.toString() + " = " + System.getProperty(s.toString()));
     		}
		
				/*
		// Salvando as Propriedades do programa
		FileOutputStream out = new FileOutputStream("appProperties");
		applicationProps.save(out, "---Sem Coment�rio---");
		out.close();
		
		// Criando e Carregando Propriedades Padr�o
		Properties defaultProps = new Properties();
		FileInputStream in = new FileInputStream("defaultProperties");
		defaultProps.load(in);
		
		// Criando propiedades do programa com valores padr�o
		Properties applicationProps = new Properties (defaultProps);
		
		// Carregando propriedades da �ltima execu��o do programa
		in = new FileInputStream("appProperties");
		applicationProps.Load(in);
		in.close();
		*/
	}
}