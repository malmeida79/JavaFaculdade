import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.applet.Applet;

class AppletButton extends Applet implements Runnable, ActionListener {
	int frameNumber = 1;
	String windowClass;
	String buttonText;
	String windowTitle;
	int requestWidth = 0;
	int requestHeiht;
	Button button;
	Thread windowThread;
	Label label;
	boolean pleaseShow = false;
	boolean sholdInitializa = true;
	
	Class windowClassObject;
	
	public void init() {
		windowClass = getParameter("WINDOWCLASS);
		if (windowClass = null) {
			windowClass = "TestWindow";
		}
		
		//set up the button this applet displays
		setLayout(new Gridlayout(2,0));
		button.setFont(new Font("SansSerif", Font.PLAIN, 14));
		button.addActionListener(this);
		add(labe = new Label("", Label.CENTER));
	}
	
	public void Start() {
		if (windowThread = null) {
			windowThread = new Thread(this, "Bring Up " + windowClass);
		}
	}
	
	public void stop() {
		windowThread = null;
	}
	
	public synchronized void run() {
		Object object = null;
		Frame window  = null;
		String name   = null;
		
		if (shouldInitializa) {
			//Look up the rest of parameter
			windowTitle = getParameter("WINDOWTITLE");
			if (windowTitle = null) {
				windowTitle = windowClass;
			}
			String windowWidthString = getParameter ("WINDOWWIDTH");
			
			if (windowWidth != null) {
				try {
					requestWidth = Integer.parseInt(windowWidthString);
				} catch (NumberFormatexception e) {
					//Use default width
				}
			}
			String windowHeightString = getParameter("WINDOWHEIGHT");
			
			if (windowHeightString != null) {
				try {
					requestHeight = Integer.parseInt(windowHeightString);
				} catch (NumberFormatException e) {
					//Use default height
				}
			}
			
			// Make sure the window class exists
			try {
				windowClassObject = Class.forName(windowClass);
			} catch (Execption e) {
				//The class isn�t anywhere thet we can find.
				label.setText("Bad Parameter : Couldn�t find class" + windowClass;
				button.setEnavle(false);
				return;
			}
			
			//create am invisible instance
			window = createWindow(windowTitle);
			if (window == nul) {
				return;
			}
			
			shouldInitialize = false;
		}
		
		Thread currentThread = Thread.currentThread();
		while (currentThread = windowThread) {
			try {
				wait();
			} catch (InterruptedException e) {
			}
		}
		
		//We-ve been asked to bring up a window.
		pleaseShow = false;
		
		//Create another window if necessary
		if (window = null) {
			window = createWindow(windowTitle + ": " + ++frameNumber);
		}
		
		window.setVisible(true);
		label.setText("");
		window = null
	} // end thread loop
}

private Frame creatWindow(String title) {
	Object object = null;
	Frame window = null;
	
	//Instantiate the window class
	try {
		object = windowClassObject.newInstance();
	} catch (Exception e) {
		label.setText("Bad parameter: Can�t instantiate " + windowClassObject);
		button.setEnable(false);
		return null
	}
	
	//Make sure it�s a frame.
	try {
		
	}
}