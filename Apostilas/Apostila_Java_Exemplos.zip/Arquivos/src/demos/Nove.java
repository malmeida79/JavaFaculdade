class Nove {
    static public void main (String[] args) {
	long fator = 12345679;
	for (int i = 1; i <= 500; i++) {		
	    System.out.print(fator + " x 9 x ");
	    System.out.print(i + " = \t");
	    System.out.println(fator * 9 * i);
	}
		
    }
}