package cursojava;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
class ImpressaoDeLinhas {
	public static void main (String[] args) {
		ImpLine("Jos� Maria R S Junior");

	}

	public static final boolean ImpLine( String msg ) {
		boolean result = true;
		File fporta = new File("LPT1:");
		byte[] buf = new byte[ msg.length() ];
		msg.getBytes(0, msg.length(), buf, 0);
		try {
			FileOutputStream porta = new FileOutputStream( fporta );
			porta.write( buf );
			porta.flush();
			porta.close();
		} catch (IOException e) {
			fporta.exists();
			result = false;
		}
		fporta.exists();
		return result;
	}
}