import java.io.*;
import java.lang.StringBuffer;
import java.lang.NumberFormatException;
import java.util.Random;

public class Apertadinho {
    
    static private String keyboardRead () {
		int in = 0;
		char chr;
		StringBuffer Valor = new StringBuffer("");
		do {
	    	try {
 				in = System.in.read();
				chr = (char) in;
				if ((in != 10) & (in != 13))
		    		Valor.append(chr);
	    	} catch (IOException e) {}
		} while (in != 10);
		return Valor.toString();
    }
	
    static int read () {
		int retorno;
	
		try {
	    	retorno = Integer.parseInt(keyboardRead());
		} catch (NumberFormatException e) {
			retorno = -1;
		}
	    System.out.println();
		return retorno;
    }
	
    public static void main (String args[]) {
		int limiteInferior = 1;
		int limiteSuperior = 100;
		Random r = new Random();
		int numeroSorteado = r.nextInt(100);
		int chute;
		int tentativas = 0;
		do { 
	    	System.out.print("Digite um n�mero entre " + limiteInferior + " e " + limiteSuperior + " = > ");
	    	chute = read();
	    	if ((chute >= limiteInferior) & (chute <= limiteSuperior)) {
				if (chute > numeroSorteado) {
		    		limiteSuperior = chute - 1;
				} else {
		    		limiteInferior = chute + 1;
				}
	    	} else {
	    		System.out.println("N�mero digitado fora do intervalo");
	    	}
	    	tentativas++;
		} while (chute != numeroSorteado);
		
		System.out.println("Parabens !!, acertou em " + tentativas + " tentativas");
    }
}