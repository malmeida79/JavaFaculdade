import java.lang.String;
import java.lang.Integer;
import java.lang.NumberFormatException;
import java.util.Random;
import java.awt.*;
import java.awt.Toolkit;

public class ApertadinhoApplet extends java.applet.Applet {

		final static int MINIMO = 1;
		final static int MAXIMO = 100;

		Font fonte = new Font("Serif", Font.BOLD, 24);
		Label lblMsg = new Label("Informe um n�mero no intervalo :");
		TextField tfLimiteInferior = new TextField(String.valueOf(MINIMO));
		TextField tfLimiteSuperior = new TextField(String.valueOf(MAXIMO));
		Button btnChute = new Button ("Chute ");
		TextField tfChute = new TextField();
		TextField tfMsg = new TextField();
		int intLimiteInferior = MINIMO;
		int intLimiteSuperior = MAXIMO;
		GridLayout lytLayout = new GridLayout(2,3);
		Random rndR = new Random();
		int intNumeroSorteado = rndR.nextInt(100);
		int intChute;
		int intTentativas = 0;
		
		public void init() {
			
			tfLimiteInferior.setFont(fonte);
			tfLimiteSuperior.setFont(fonte);
			tfChute.setFont(fonte);
			tfLimiteInferior.setEditable(false);
			tfLimiteSuperior.setEditable(false);
			tfMsg.setEnabled(false);
			setLayout(lytLayout);
			add(lblMsg);
			add(tfLimiteInferior);
			add(tfLimiteSuperior);
			add(btnChute);
			add(tfChute);
			add(tfMsg);
			tfChute.requestFocus();
		}
	
		public boolean action (Event evt, Object arg) {
			
			int chuteTemp;
			
			try {
				chuteTemp = Integer.parseInt(tfChute.getText());
			} catch (NumberFormatException e ) {chuteTemp = 0;}
			tfMsg.setText(""); 
			intTentativas++;
			if (evt.target instanceof Button) {
				if (chuteTemp == intNumeroSorteado) {
					tfMsg.setText("Parabens."+"\n"+"Acertou em " + intTentativas + " tentativas");	
					intLimiteInferior = MINIMO;
					intLimiteSuperior = MAXIMO;
					tfChute.setText("");
					tfLimiteInferior.setText(String.valueOf(intLimiteInferior = MINIMO));
					tfLimiteSuperior.setText(String.valueOf(intLimiteSuperior = MAXIMO));
				}
				else {
					if ((chuteTemp >= intLimiteInferior) & (chuteTemp <= intLimiteSuperior)) {
						if (chuteTemp < intNumeroSorteado)
							intLimiteInferior = chuteTemp + 1;
						else
							intLimiteSuperior = chuteTemp - 1;
					} 
					else {
						tfMsg.setText("N�mero fora do intervalo"); 
						Toolkit.getDefaultToolkit().beep();

					}
				}
				tfLimiteInferior.setText(String.valueOf(intLimiteInferior));
				tfLimiteSuperior.setText(String.valueOf(intLimiteSuperior));
				tfChute.setText("");
			}
		
			tfChute.requestFocus();
			
			return true;
		}
}