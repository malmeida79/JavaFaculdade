import java.applet.Applet;
import java.awt.Graphics;

public class HelloWorld extends Applet {
     public void paint (Graphics g) {
          g.drawString("Zezinho nas Applet�s", 50,25);
     }
}