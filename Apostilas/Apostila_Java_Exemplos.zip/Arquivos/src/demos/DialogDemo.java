import java.awt.*;
import java.awt.event.*;

/* Classe para exemplificar o uso do AWT */

public class DialogDemo extends Frame implements ActionListener {
	boolean inAnApplet = true;
	private SimpleDialog dialog;
	private TextArea textArea;
	
	public DialogDemo() {
		textArea = new TextArea(5,40);
		textArea.setEditable(false);
		add("Center", textArea);
		Button button = new Button("Click para exibir a caixa de dialogo");
		button.addActionListener(this);
		Panel panel = new Panel();
		panel.add(button);
		add("South", panel);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				if (inAnApplet) {
					setVisible(false);
					dispose();
				} else {
					System.exit(0);
				}
			}
			
		});
		
	}	
	
	public void actionPerformed (ActionEvent event) {
		if (dialog == null) {
			dialog = new SimpleDialog(this, "Caixa de Dial�go Simples");
		}
		dialog.setVisible(true);
	}
	
	public void setText(String text) {
		textArea.append(text + "\n");
	}
	
	public static void main (String[] args) {

		DialogDemo window = new DialogDemo();
		window.inAnApplet = false;
		
		window.setTitle("Dialog");
		window.pack();
		window.setVisible(true);
	}
	
	class SimpleDialog extends Dialog implements ActionListener{
		TextField field;
		DialogDemo parent;
		Button setButton;
		
		SimpleDialog (Frame dw, String title) {
			super(dw, title, false);
			parent = (DialogDemo)dw;
			
			// Sec��o do meio
			Panel p1 = new Panel();
			Label label = new Label("Digite um texto : ");
			p1.add(label);
			field = new TextField(40);
			field.addActionListener(this);
			p1.add(field);
			add("Center", p1);
			
			//Coluna de baixo
			Panel p2 = new Panel();
			p2.setLayout(new FlowLayout(FlowLayout.RIGHT));
			Button b = new Button("Cancel");
			b.addActionListener(this);
			setButton = new Button("Set");
			setButton.addActionListener(this);
			p2.add(b);
			p2.add(setButton);
			add("South", p2);
			
			//Inicializa o dialogo com o seu tamanho preferido
			pack();
		}
		
		public void actionPerformed (ActionEvent event) {
			Object source = event.getSource();
			if ( (source == setButton) | (source == field)) {
				parent.setText(field.getText());
			}
			field.selectAll();
			setVisible(false);
		}
	}
	
}