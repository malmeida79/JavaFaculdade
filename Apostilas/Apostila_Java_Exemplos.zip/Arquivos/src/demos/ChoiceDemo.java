import java.awt.*;
import java.awt.event.*;

/* Classe para exemplificar o uso do AWT */

public class ChoiceDemo extends Frame implements ItemListener {
	
	Panel p;
	Choice choice;
	Label label;

	public ChoiceDemo() {
		
		choice = new Choice();
		choice.addItem("Op��o 1");
		choice.addItem("Op��o 2");
		choice.addItem("Op��o 3");
		choice.addItem("Op��o 4");
		choice.addItem("Op��o 5");
		
		choice.addItemListener(this);
		
		label = new Label();
		setLabelText(choice.getSelectedIndex(), choice.getSelectedItem());
		
		p = new Panel();
		p.setLayout(new FlowLayout());
		p.add(choice);
		p.add(label);
		
		setLayout(new GridLayout(0,2));
		add(p);
	}	
	
	public static void main (String[] args) {

		ChoiceDemo window = new ChoiceDemo();
		window.setTitle("Choice");
		window.pack();
		window.setVisible(true);
	}
	
	void setLabelText (int num, String text) {
		label.setText("Item #" + num + " selecionado." + "Texto = " + text);
	}
	
	public void itemStateChanged (ItemEvent e) {
		setLabelText(choice.getSelectedIndex(), choice.getSelectedItem());
	}
}