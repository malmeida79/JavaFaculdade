import java.util.Random;

class Numeros {
		
	static public void main (String[] args) {
	
		Random r = new Random();
		int a;
				
		for ( a = (int)(r.nextDouble() * 1000) ; a != 50; ) {
			System.out.println("O n�mero sorteado foi " + a);
			a = (int)(r.nextDouble() * 1000);
		}
		
	}
}