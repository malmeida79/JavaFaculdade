import java.awt.*;
import java.io.*;

public class HorarioApplet extends java.applet.Applet {
	
	Label l1 = new Label("Entrada 1� Turno");
	Label l2 = new Label("Sa�da   1� Turno");
	Label l3 = new Label("Entrada 2� Turno");
	Label l4 = new Label("Sa�da   2� Turno");
	TextField tf1 = new TextField(5);
	TextField tf2 = new TextField(5);
	TextField tf3 = new TextField(5);
	TextField tf4 = new TextField(5);
	TextField tf5 = new TextField(30);
	Button b = new Button ("Calcular Horas");
	GridLayout layout = new GridLayout(5,2);
	
	public void init ()  {
		
		setLayout(layout);
		add(l1);
		add(tf1);
		add(l2);
		add(tf2);
		add(l3);
		add(tf3);
		add(l4);
		add(tf4);
		add(b);
		add(tf5);
		tf1.requestFocus();
	}
	
	private void calcularHoras () {
		
			String entradaManha, saidaManha, entradaTarde, saidaTarde, diferencaManha, faltaTarde;
		
			entradaManha 	= tf1.getText();
			saidaManha	= tf2.getText();
			entradaTarde	= tf3.getText();
			saidaTarde	= tf4.getText();
			if ( tf2.getText().length() == 0) {
				tf5.setText("=> Falta Par�metros");
			} else if (tf3.getText().length() == 0) {
				tf5.setText(" => Horas Trabalhadas = " + Horario.soma(entradaManha, saidaManha, "-"));
			} else if (tf4.getText().length() == 0) {
				diferencaManha = Horario.soma(entradaManha, saidaManha, "-");
				faltaTarde = Horario.soma("08:00", diferencaManha, "-");
				tf5.setText(" = > Sa�da da Tarde = " + Horario.soma(entradaTarde,faltaTarde, "+"));
			} else if (tf4.getText().length() != 0) {
				tf5.setText("Horas Trabalhadas = " +
				            Horario.soma(Horario.soma(entradaManha, saidaManha, "-"), Horario.soma(entradaTarde, saidaTarde, "-"), "+"));
			}
	}
	
	public boolean action (Event evt, Object arg) {
		
		if (evt.target instanceof Button) {
			calcularHoras();
		}
		
		return true;
	}
}