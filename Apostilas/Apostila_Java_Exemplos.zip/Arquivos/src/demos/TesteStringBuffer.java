class TesteStringBuffer {
	
	public static void NovoValor(StringBuffer s, String novoValor) {
		System.out.println(s.toString());
		s.append(novoValor);
	}
	
	public static void main (String[] args) {
		
	StringBuffer s = new StringBuffer("Valor");

		NovoValor(s, "Novo valor");
		System.out.println(s.toString());
	}
}