import java.lang.String;
import java.lang.Integer;
import java.lang.NumberFormatException;
import java.awt.*;

public class TresMaioresApplet extends java.applet.Applet {
	
	int numero = 0;
	int cont = 0;
	int maior1, maior2, maior3;
	TextField tfMaior1 = new TextField();
	TextField tfMaior2 = new TextField();
	TextField tfMaior3 = new TextField();
	TextField tfNumero = new TextField();
	Button btnLer = new Button("Ler");
	GridLayout layout = new GridLayout(2,3);
	Font fonte = new Font("Serif", Font.BOLD, 24);


	public void init () {
		setFont(fonte);
		tfMaior1.setEditable(false);
		tfMaior2.setEditable(false);
		tfMaior3.setEditable(false);
		setLayout(layout);
		add(tfMaior1);
		add(tfMaior2);
		add(tfMaior3);
		add(tfNumero);
		add(btnLer);
		tfNumero.requestFocus();
	}
	
	public boolean action (Event evt, Object arg) {
		
		
		cont++;
		try {
			 numero = Integer.parseInt(tfNumero.getText());
			} catch (NumberFormatException e ) {}
		if (evt.target instanceof Button) {
			switch (cont) {
				case 1 : { 
					maior1 = numero;
					tfMaior1.setText(String.valueOf(maior1));
					break; }
				case 2 : { 
					if (numero > maior1) {
						maior2 = maior1;
						maior1 = numero;
					} 
					else {
						maior2 = numero;
					}
					tfMaior1.setText(String.valueOf(maior1));
					tfMaior2.setText(String.valueOf(maior2));
					break;
				}
				case 3 : {
					if (numero > maior1) {
						maior3 = maior2;
						maior2 = maior1;
						maior1 = numero;
					}
					else if (numero > maior2) {
						maior3 = maior2;
						maior2 = numero;
					}
					else {maior3 = numero;}
						tfMaior1.setText(String.valueOf(maior1));
						tfMaior2.setText(String.valueOf(maior2));
						tfMaior3.setText(String.valueOf(maior3));
						break;
				}
				default : {
					if (numero > maior1) {
						maior3 = maior2;
						maior2 = maior1;
						maior1 = numero;
					}
					else if (numero > maior2) {
						maior3 = maior2;
						maior2 = numero;
					}
					else if (numero > maior3) {
						maior3 = numero;
					}
					tfMaior1.setText(String.valueOf(maior1));
					tfMaior2.setText(String.valueOf(maior2));
					tfMaior3.setText(String.valueOf(maior3));
				}
			}
		}
		tfNumero.setText("");
		tfNumero.requestFocus();
		
		return true;
	}
}