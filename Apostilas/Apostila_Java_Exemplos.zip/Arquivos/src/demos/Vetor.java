import java.util.Random;
	
public class Vetor {
	public static void main (String[] a) {
		int[][] v = new int[3][10];
		Random r = new Random();
		
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 10; j++) {
				v[i][j] = r.nextInt(100);
				System.out.print(v[i][j] + "\t");
			}
			System.out.println();
		}
	}
}