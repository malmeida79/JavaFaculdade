import java.io.*;
import java.lang.StringBuffer;
import java.lang.NumberFormatException;
import java.lang.Integer;
import java.lang.Math;


class Horario {

	static private String keyboardRead () {
		
		int in = 0;
		char chr;
		StringBuffer Valor = new StringBuffer("");

		do {
			try {
 				in = System.in.read();
				chr = (char) in;
				if ((in != 10) & (in != 13))
					Valor.append(chr);
			} catch (IOException e) {}
		} while (in != 10);
		
		return Valor.toString();
	}
	
	
	static int minutos (String Hora) {
		
		int horas, minutos;
		
		horas = Integer.parseInt(Hora.substring(0,2));
		minutos = Integer.parseInt(Hora.substring(3,5));
		
		return (horas * 60 + minutos);

	}
	
	static String soma (String entrada, String saida, String op) {
		
		int intMinutosDiferenca, intHorasDiferenca;
		int minutosEntrada, minutosSaida, minutosDiferenca;
		StringBuffer sbMinutosDiferenca, sbHorasDiferenca;
		
		minutosEntrada = minutos(entrada);
		minutosSaida = minutos(saida);
		if (op == "-")
			minutosDiferenca = Math.abs(minutosSaida - minutosEntrada);
		else
			minutosDiferenca = Math.abs(minutosSaida + minutosEntrada);
		intMinutosDiferenca = minutosDiferenca % 60;
		intHorasDiferenca = minutosDiferenca / 60;
		sbMinutosDiferenca = new StringBuffer(String.valueOf(intMinutosDiferenca));
		if (sbMinutosDiferenca.length() == 1) {
			sbMinutosDiferenca.insert(0,"0");
		}
		sbHorasDiferenca = new StringBuffer(String.valueOf(intHorasDiferenca));
		if (sbHorasDiferenca.length() == 1) {
			sbHorasDiferenca.insert(0,"0");
		}
		
		return sbHorasDiferenca + ":" + sbMinutosDiferenca;
	}
	
	public static void main (String[] args) {

		String entradaManha, saidaManha, entradaTarde, saidaTarde, diferencaManha, faltaTarde;
		int NumParam = args.length;
		
		System.out.print("Ent. do 1� Turno  = ");
		entradaManha 	= keyboardRead();
		System.out.print("Sa�da do 1� Turno = ");
		saidaManha	= keyboardRead();
		System.out.print("Ent. do 2� Turno  = ");
		entradaTarde	= keyboardRead();
		System.out.print("Sa�da do 2� Turno = ");
		saidaTarde	= keyboardRead();
		System.out.print ("=> ");
		if ( saidaManha.length() == 0) {
			System.out.println("Falta Par�metros");
		} else if (entradaTarde.length() == 0) {
			System.out.println(entradaManha + " " + saidaManha + " Horas Restante = " + soma(entradaManha, saidaManha, "-"));
		} else if (saidaTarde.length() == 0) {
			diferencaManha = soma(entradaManha, saidaManha, "-");
			faltaTarde = soma("08:00", diferencaManha, "-");
			System.out.println(entradaManha + " " + saidaManha + " " + entradaTarde + " Sa�da da Tarde = " + soma(entradaTarde,faltaTarde, "+"));
		} else if (saidaTarde.length() != 0) {
			System.out.println(entradaManha + " " + saidaManha + " " + entradaTarde + " " + saidaTarde + " = " +
							"Horas Trabalhadas = " +
				              soma(soma(entradaManha, saidaManha, "-"), soma(entradaTarde, saidaTarde, "-"), "+"));
		}
	}
}