import java.io.*;
import java.lang.StringBuffer;
import java.lang.NumberFormatException;

class Teclado {
	
	static private String keyboardRead () {
		int in = 0;
		char chr;
		StringBuffer Valor = new StringBuffer("");

		do {
			try {
 				in = System.in.read();
				chr = (char) in;
				if ((in != 10) & (in != 13))
					Valor.append(chr);
			} catch (IOException e) {}
		} while (in != 10);
		
		return Valor.toString();
	}
	
	static int read () {
		int retorno;
		try {
			retorno = Integer.parseInt(keyboardRead());
		} catch (NumberFormatException e) {retorno = -1;}

		return retorno;
	}
	
	public static void main (String args[]) {
		int i = Teclado.read();
		System.out.println(i);
	}
}