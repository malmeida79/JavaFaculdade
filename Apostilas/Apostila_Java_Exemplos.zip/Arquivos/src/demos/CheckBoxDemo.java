import java.awt.*;
import java.awt.event.*;

/* Classe para exemplificar o uso do AWT */

public class CheckBoxDemo extends Frame {
	
	
	public CheckBoxDemo() {
		Panel p1, p2;
		Checkbox cb1, cb2, cb3, cb4, cb5, cb6;
		CheckboxGroup cbg;
		
		//Primeiro Panel com cb1, cb2, cb3
		cb1 = new Checkbox();
		cb1.setLabel("Checkbox 1");
		cb2 = new Checkbox("Checkbox 2", true);
		cb3 = new Checkbox("Checkbox 3");
		cb3.setState(true);
		p1 = new Panel();
		p1.setLayout(new FlowLayout());
		p1.add(cb1);
		p1.add(cb2);
		p1.add(cb3);
		
		//Segundo Panel com checkgroup(cb4, cb5, cb6)
		cbg = new CheckboxGroup();
		cb4 = new Checkbox("Checkbox", cbg, false);
		cb5 = new Checkbox("Checkbox", cbg, false);
		cb6 = new Checkbox("Checkbox", cbg, false);
		
		p2 = new Panel();
		p2.setLayout(new FlowLayout());
		p2.add(cb4);
		p2.add(cb5);
		p2.add(cb6);

		//Inserindo p1 e p2 na janela
		
		setLayout(new GridLayout(0,2));
		add(p1);
		add(p2);
	}
	
	
	public static void main (String[] args) {

		CheckBoxDemo window = new CheckBoxDemo();
		window.setTitle("Checkbox");
		window.pack();
		window.setVisible(true);
	}
}