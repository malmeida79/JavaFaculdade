import java.awt.Graphics;
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;

public class TeclasApplet extends java.applet.Applet {
	
	char teclaCorrente;
	int iTeclaCorrente;
	int xCorrente;
	int yCorrente;
	
		
	public void init () {
		
		xCorrente = (size().width/2) - 8;
		yCorrente = (size().height/2) - 16;

		setBackground(Color.white);
		setFont(new Font("Helvetica", Font.BOLD, 36));
		requestFocus();
	}
	
	public boolean keyDown (Event evt, int key) {
		
		switch (key) {
			case Event.DOWN:
				yCorrente += 5;
				break;
			case Event.UP:
				yCorrente -= 5;
				break;
			case Event.LEFT:
				xCorrente -= 5;
				break;
			case Event.RIGHT:
				xCorrente += 5;
				break;
			default:
				teclaCorrente = (char) key;
				iTeclaCorrente = key;
		}
		repaint();
		return true;
	}
		
	public void paint (Graphics g) {
		
		if (teclaCorrente != 0) {
			g.drawString(String.valueOf(teclaCorrente) + " = " + String.valueOf(iTeclaCorrente),
				        xCorrente, yCorrente);
		}
	}
}