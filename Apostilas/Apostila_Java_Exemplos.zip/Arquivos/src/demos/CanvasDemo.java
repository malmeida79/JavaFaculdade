import java.awt.*;
import java.awt.event.*;

/* Classe para exemplificar o uso do AWT */

public class CanvasDemo extends Frame {
	
	
	public CanvasDemo() {
		MyCanvas C = new MyCanvas();
		add(C);
	}
	
	
	public static void main (String[] args) {

		CanvasDemo window = new CanvasDemo();
		window.setTitle("Bot�es");
		window.pack();
		window.setVisible(true);
	}
	
	
	class MyCanvas extends Canvas{
		
		public void paint (Graphics g) {
			int w = getSize().width;
			int h = getSize().height;
		
			g.drawRect(0,0,w - 1, h - 1);
			g.drawString("Canvas", (w - g.getFontMetrics().stringWidth("Canvas"))/2,10);
			g.setFont(new Font("SansSerif", Font.PLAIN, 8));
			g.drawLine(10, 10, 100, 100);
			g.fillRect(9,9,3,3);
			g.drawString("(10,10)", 13, 10);
			g.fillRect(49, 49, 3, 3);
			g.drawString("(50,50)", 53, 50);
			g.fillRect(99, 99, 3, 3);
			g.drawString("(100,100)", 103, 100);
		}
		
		public Dimension getMinimumSize() {
			return new Dimension(150,130);
		}
		
		public Dimension getPreferredSize() {
			return getMinimumSize();
		}
	}
	
}