//Source file: c:/InfoNet/CursoDeUML/Agrega�o/Produto.java


public class Produto 
{
   private PedidoItem pedidoItem;
   
   public Produto() 
   {
   }
}
