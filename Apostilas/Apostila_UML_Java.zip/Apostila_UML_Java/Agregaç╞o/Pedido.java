//Source file: c:/InfoNet/CursoDeUML/Agrega�o/Pedido.java


public class Pedido 
{
   private PedidoItem pedidoItem[];
   
   public Pedido() 
   {
   }
}
