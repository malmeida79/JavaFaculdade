//Source file: c:/InfoNet/CursoDeUML/Associa��o/ClasseY.java


public class ClasseY 
{
   public ClasseX theClasseX[];
   
   public ClasseY() 
   {
   }
}
