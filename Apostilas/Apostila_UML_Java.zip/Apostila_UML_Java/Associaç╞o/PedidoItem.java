//Source file: c:/InfoNet/CursoDeUML/Associa��o/PedidoItem.java


public class PedidoItem 
{
   public Pedido thePedido;
   public Pedido pedidoQualificado;
   
   public PedidoItem() 
   {
   }
}
