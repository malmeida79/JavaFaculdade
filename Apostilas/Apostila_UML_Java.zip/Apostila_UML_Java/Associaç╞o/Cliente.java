//Source file: c:/InfoNet/CursoDeUML/Associa��o/Cliente.java


public class Cliente 
{
   
   public Cliente() 
   {
   }
}
