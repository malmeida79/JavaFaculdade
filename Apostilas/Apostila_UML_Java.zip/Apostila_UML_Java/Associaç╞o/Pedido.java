//Source file: c:/InfoNet/CursoDeUML/Associa��o/Pedido.java


public class Pedido 
{
   public PedidoItem pedidoItemQualificado;
   public PedidoItem thePedidoItem[];
   private Cliente cliente;
   
   public Pedido() 
   {
   }
}
