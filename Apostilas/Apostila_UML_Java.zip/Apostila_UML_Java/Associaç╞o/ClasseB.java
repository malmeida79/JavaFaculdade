//Source file: c:/InfoNet/CursoDeUML/Associa��o/ClasseB.java


public class ClasseB 
{
   public ClasseA papelB;
   
   public ClasseB() 
   {
   }
}
