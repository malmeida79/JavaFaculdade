//Source file: c:/InfoNet/CursoDeUML/Associa��o/ClasseBeta.java


public class ClasseBeta 
{
   
   public ClasseBeta() 
   {
   }
}
