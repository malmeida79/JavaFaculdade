//Source file: c:/InfoNet/CursoDeUML/Associa��o/Setor.java


public class Setor 
{
   public Funcion�rio theFuncion�rio;
   private Funcion�rio funcionarios[];
   
   public Setor() 
   {
   }
}
