//Source file: c:/InfoNet/CursoDeUML/Associa��o/Funcion�rio.java


public class Funcion�rio 
{
   
   public Funcion�rio() 
   {
   }
}
