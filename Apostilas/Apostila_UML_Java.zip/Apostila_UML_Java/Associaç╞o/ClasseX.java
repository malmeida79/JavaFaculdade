//Source file: c:/InfoNet/CursoDeUML/Associa��o/ClasseX.java


public class ClasseX 
{
   public ClasseY theClasseY[];
   
   public ClasseX() 
   {
   }
}
