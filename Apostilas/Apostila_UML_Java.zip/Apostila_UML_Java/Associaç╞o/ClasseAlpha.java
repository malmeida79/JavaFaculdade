//Source file: c:/InfoNet/CursoDeUML/Associa��o/ClasseAlpha.java


public class ClasseAlpha 
{
   
   public ClasseAlpha() 
   {
   }
}
