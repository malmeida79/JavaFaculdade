//Source file: c:/InfoNet/CursoDeUML/Associa��o/ClasseA.java


public class ClasseA 
{
   public ClasseB papelA;
   
   public ClasseA() 
   {
   }
}
