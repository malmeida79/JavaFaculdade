//Source file: C:/Meus documentos/CursoDeUML/DiagramaDeIntera��o/util/Data.java

package util;


/**
 * @author 
 */
public class Data {
	
	public Data() {}
	
	/**
	 * @param data
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 3991F1550158
	 */
	public void Date(String data) {}
	
	/**
	 * @return String
	 * @exception 
	 * @author 
	 * @roseuid 3991F27603C0
	 */
	public String toString() {}
}
