//Source file: C:/Meus documentos/CursoDeUML/DiagramaDeIntera��o/util/Endere�o.java

package util;


/**
 * @author 
 */
public class Endere�o {
	
	public Endere�o() {}
	
	/**
	 * @param rua
	 * @param numero
	 * @param bairro
	 * @return 
	 * @exception 
	 * @author 
	 * @roseuid 3991F1640380
	 */
	public Endere�o(String rua, int numero, String bairro) {}
	
	/**
	 * @return String
	 * @exception 
	 * @author 
	 * @roseuid 3991F27D0334
	 */
	public String toString() {}
}
