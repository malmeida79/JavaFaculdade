//Source file: C:/Meus documentos/CursoDeUML/DiagramaDeIntera��o/util/CPF.java

package util;


/**
 * @author 
 */
public class CPF {
	
	public CPF() {}
	
	/**
	 * @param cpf
	 * @return 
	 * @exception 
	 * @author 
	 * @roseuid 3991F13E0317
	 */
	public CPF(String cpf) {}
	
	/**
	 * @return String
	 * @exception 
	 * @author 
	 * @roseuid 3991F2690187
	 */
	public String toString() {}
}
