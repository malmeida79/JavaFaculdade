//Source file: C:/Meus documentos/CursoDeUML/DiagramaDeIntera��o/cadastroDeCliente/Clientes.java

package cadastroDeCliente;

import util.CPF;

/**
 * @author 
 */
public class Clientes {
	private Cliente cliente[];
	
	public Clientes() {}
	
	/**
	 * @param cliente
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 3991E7A502D8
	 */
	public void adicionar(Cliente cliente) {}
	
	/**
	 * @param cpf
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 3991E7E00233
	 */
	public void remover(CPF cpf) {}
	
	/**
	 * @return String
	 * @exception 
	 * @author 
	 * @roseuid 3991E81B035A
	 */
	public String toString() {}
}
