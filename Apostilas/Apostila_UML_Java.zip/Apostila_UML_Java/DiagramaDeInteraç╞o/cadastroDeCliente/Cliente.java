//Source file: C:/Meus documentos/CursoDeUML/DiagramaDeIntera��o/cadastroDeCliente/Cliente.java

package cadastroDeCliente;

import util.CPF;
import util.Endere�o;
import util.Data;

/**
 * @author 
 */
public class Cliente {
	private String nome;
	private CPF cpf;
	private Endere�o endere�o;
	private Data dataNascimento;
	
	public Cliente() {}
	
	/**
	 * @param cpf
	 * @param nome
	 * @param end
	 * @param dataNascimento
	 * @return 
	 * @exception 
	 * @author 
	 * @roseuid 3991F04901C1
	 */
	public Cliente(CPF cpf, String nome, Endere�o end, Data dataNascimento) {}
	
	/**
	 * @return String
	 * @exception 
	 * @author 
	 * @roseuid 3991E8C700D6
	 */
	public String toString() {}
}
