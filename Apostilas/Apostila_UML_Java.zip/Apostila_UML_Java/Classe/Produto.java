//Source file: c:/InfoNet/CursoDeUML/Classe/Produto.java


public class Produto 
{
   private PedidoItem pedidoItem;
   
   public Produto() 
   {
   }
}
