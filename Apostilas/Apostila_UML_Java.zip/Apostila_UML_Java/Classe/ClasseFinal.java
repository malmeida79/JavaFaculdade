//Source file: c:/InfoNet/CursoDeUML/Classe/ClasseFinal.java


/**
 * @author 
 */
public final class ClasseFinal {
	
	public ClasseFinal() {}
}
