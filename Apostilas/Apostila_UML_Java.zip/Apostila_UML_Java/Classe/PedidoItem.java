//Source file: c:/InfoNet/CursoDeUML/Classe/PedidoItem.java


public class PedidoItem 
{
   private Pedido pedido;
   private Produto produto;
   public Produto theProduto;
   
   public PedidoItem() 
   {
   }
}
