//Source file: C:/Meus documentos/CursoDeUML/Classe/Pessoa.java


/**
 * @author
 */
public class Pessoa {
	private String nome;
	protected int dependentes = 0;
	public static int quantidadeDePessoas;
	private Date dataNascimento;

	public Pessoa() {}

	/**
	 * @param nome
	 * @return void
	 * @exception
	 * @author
	 * @roseuid 39914CBF0207
	 */
	public void setNome(String nome) {}

	/**
	 * @param dep
	 * @return void
	 * @exception
	 * @author
	 * @roseuid 3991E42F02D4
	 */
	public void setDependentes(int dep) {}

	/**
	 * @param d
	 * @return void
	 * @exception
	 * @author
	 * @roseuid 3991E44A039B
	 */
	public void setDataNascimento(Date d) {}

	/**
	 * @return String
	 * @exception
	 * @author
	 * @roseuid 3991E49A0274
	 */
	public String getNome() {}

	/**
	 * @return int
	 * @exception
	 * @author
	 * @roseuid 3991E4A300DC
	 */
	public int getDependentes() {}

	/**
	 * @return Date
	 * @exception
	 * @author
	 * @roseuid 3991E4AC0139
	 */
	public Date getDataNascimento() {}

	/**
	 * @return Int
	 * @exception
	 * @author
	 * @roseuid 39914CC40272
	 */
	protected static Int idade() {}

	/**
	 * @param d
	 * @return String
	 * @exception
	 * @author
	 * @roseuid 3991E47001DD
	 */
	private static String dateToString(Date d) {}
}
