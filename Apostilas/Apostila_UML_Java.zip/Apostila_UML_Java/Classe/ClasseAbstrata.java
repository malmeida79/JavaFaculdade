//Source file: c:/InfoNet/CursoDeUML/Classe/ClasseAbstrata.java


/**
 * @author 
 */
public abstract class ClasseAbstrata {
	
	public ClasseAbstrata() {}
}
