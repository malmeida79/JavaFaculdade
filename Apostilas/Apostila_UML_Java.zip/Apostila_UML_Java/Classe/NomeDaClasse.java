//Source file: c:/InfoNet/CursoDeUML/Classe/NomeDaClasse.java


/**
 * @author 
 */
public class NomeDaClasse {
	private String atributo1;
	protected int atributo2 = 0;
	public static int atributoEst�tico;
	
	{}
	
	public NomeDaClasse() {}
	
	/**
	 * @param par�metro
	 * @return Date
	 * @exception 
	 * @author 
	 * @roseuid 39914CBF0207
	 */
	protected Date m�todo1(String par�metro) {}
	
	/**
	 * @param param1
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 39914CC40272
	 */
	public static void m�todoEst�tico(Integer param1) {}
	
	/**
	 * @return String
	 * @exception 
	 * @author 
	 * @roseuid 39914CC702C7
	 */
	private String m�todo3() {}
}
