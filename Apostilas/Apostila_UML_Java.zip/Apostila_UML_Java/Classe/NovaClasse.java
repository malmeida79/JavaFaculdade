//Source file: c:/InfoNet/CursoDeUML/Classe/NovaClasse.java


/**
 * @author 
 */
public class NovaClasse {
	private int atributo1;
	private short atributo2;
	
	public NovaClasse() {}
	
	/**
	 * @param param1
	 * @param param2
	 * @param param3
	 * @return short
	 * @exception 
	 * @author 
	 * @roseuid 399983E400AA
	 */
	public short m�todo1(int param1, String param2, long param3) {}
	
	/**
	 * @param param1
	 * @param param2
	 * @return int
	 * @exception 
	 * @author 
	 * @roseuid 3999841E033E
	 */
	public int m�todo2(double param1, int param2) {}
}
