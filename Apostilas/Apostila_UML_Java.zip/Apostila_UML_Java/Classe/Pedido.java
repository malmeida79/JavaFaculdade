//Source file: c:/InfoNet/CursoDeUML/Classe/Pedido.java


public class Pedido 
{
   private PedidoItem pedidoItem[];
   
   public Pedido() 
   {
   }
}
