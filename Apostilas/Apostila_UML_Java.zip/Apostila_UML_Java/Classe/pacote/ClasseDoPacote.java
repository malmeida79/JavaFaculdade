//Source file: C:/Meus documentos/CursoDeUML/Classe/pacote/ClasseDoPacote.java

package pacote;


/**
 * @author 
 */
public class ClasseDoPacote {
	
	public ClasseDoPacote() {}
}
