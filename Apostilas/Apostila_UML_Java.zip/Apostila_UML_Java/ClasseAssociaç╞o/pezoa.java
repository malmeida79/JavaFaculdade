//Source file: c:/InfoNet/CursoDeUML/ClasseAssocia��o/pezoa.java


/**
 * @author 
 */
public class pezoa {
	public servizo theServizo[];
	
	public pezoa() {}
}
