//Source file: c:/InfoNet/CursoDeUML/ClasseAssocia��o/Empresa.java


/**
 * @author 
 */
public class Empresa {
	public Pessoa thePessoa[];
	
	public Empresa() {}
}
