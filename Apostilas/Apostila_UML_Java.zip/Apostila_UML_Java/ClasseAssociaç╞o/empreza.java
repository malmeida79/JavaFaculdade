//Source file: c:/InfoNet/CursoDeUML/ClasseAssocia��o/empreza.java


/**
 * @author 
 */
public class empreza {
	public servizo theServizo[];
	
	public empreza() {}
}
