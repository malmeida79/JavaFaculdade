//Source file: c:/InfoNet/CursoDeUML/ClasseAssocia��o/servizo.java


/**
 * @author 
 */
public class servizo {
	public empreza theEmpreza;
	public pezoa thePezoa;
	
	public servizo() {}
}
