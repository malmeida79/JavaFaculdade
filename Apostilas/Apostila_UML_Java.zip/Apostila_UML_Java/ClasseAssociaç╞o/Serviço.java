//Source file: c:/InfoNet/CursoDeUML/ClasseAssocia��o/Servi�o.java


/**
 * @author 
 */
public class Servi�o {
	private String descri��o;
	private Date dataDeAdmiss�o;
	private Currency sal�rio;
	
	public Servi�o() {}
	
	/**
	 * @param p
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 3991AE7903AB
	 */
	public void incluir(Pessoa p) {}
}
