//Source file: c:/InfoNet/CursoDeUML/ClasseAssocia��o/Pessoa.java


/**
 * @author 
 */
public class Pessoa {
	public Empresa theEmpresa[];
	
	public Pessoa() {}
}
