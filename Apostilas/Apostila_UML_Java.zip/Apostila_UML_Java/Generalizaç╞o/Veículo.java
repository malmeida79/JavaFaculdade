//Source file: c:/InfoNet/CursoDeUML/Generaliza��o/Ve�culo.java


/**
 * @author 
 */
public abstract class Ve�culo {
	private String chassi;
	private String placa;
	private String modelo;
	private String cor;
	protected Marca marca;
	
	public Ve�culo() {}
}
