//Source file: C:/Meus documentos/CursoDeUML/Generaliza��o/SubClasseF.java


/**
 * @author 
 */
public class SubClasseF extends SubClasseB {
	
	public SubClasseF() {}
}
