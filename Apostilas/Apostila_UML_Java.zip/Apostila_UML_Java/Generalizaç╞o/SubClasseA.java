//Source file: C:/Meus documentos/CursoDeUML/Generaliza��o/SubClasseA.java


/**
 * @author 
 */
public class SubClasseA extends ClasseRaiz {
	
	public SubClasseA() {}
}
