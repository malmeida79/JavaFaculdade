//Source file: C:/Meus documentos/CursoDeUML/Generaliza��o/ClasseRaiz.java


/**
 * @author 
 */
public abstract class ClasseRaiz {
	
	public ClasseRaiz() {}
}
