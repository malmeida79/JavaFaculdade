//Source file: c:/InfoNet/CursoDeUML/Generaliza��o/Marca.java


/**
 * @author 
 */
public class Marca {
	private int descri��o;
	private int logotipo;
	
	public Marca() {}
}
