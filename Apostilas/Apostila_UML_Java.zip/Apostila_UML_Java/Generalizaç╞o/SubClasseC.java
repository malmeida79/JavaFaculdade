//Source file: C:/Meus documentos/CursoDeUML/Generaliza��o/SubClasseC.java


/**
 * @author 
 */
public class SubClasseC extends ClasseRaiz {
	
	public SubClasseC() {}
}
