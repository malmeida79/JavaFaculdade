//Source file: C:/Meus documentos/CursoDeUML/Generaliza��o/SubClasseE.java


/**
 * @author 
 */
public class SubClasseE extends SubClasseB {
	
	public SubClasseE() {}
}
