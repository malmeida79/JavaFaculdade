//Source file: c:/InfoNet/CursoDeUML/Generaliza��o/Ve�culoDePasseio.java


/**
 * @author 
 */
public class Ve�culoDePasseio extends Ve�culo {
	private int quantidadeDePassageiros;
	
	public Ve�culoDePasseio() {}
}
