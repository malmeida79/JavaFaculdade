//Source file: c:/InfoNet/CursoDeUML/Generaliza��o/Ve�culoDeCarga.java


/**
 * @author 
 */
public class Ve�culoDeCarga extends Ve�culo {
	private int cargaM�xima;
	
	public Ve�culoDeCarga() {}
}
