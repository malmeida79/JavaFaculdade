//Source file: C:/Meus documentos/CursoDeUML/Generaliza��o/SubClasseB.java


/**
 * @author 
 */
public class SubClasseB extends ClasseRaiz {
	
	public SubClasseB() {}
}
