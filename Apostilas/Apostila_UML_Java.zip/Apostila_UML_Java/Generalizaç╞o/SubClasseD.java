//Source file: C:/Meus documentos/CursoDeUML/Generaliza��o/SubClasseD.java


/**
 * @author 
 */
public class SubClasseD extends SubClasseB {
	
	public SubClasseD() {}
}
