import java.sql.*;

public class Caixas extends TabelaRelacional {
	private static String tabela = "caixas";

	public void create (Caixa caixa) {
		String create = "create table " + tabela + "(" + caixa.create() + ")";
		super.create(create);
	}

	public void insert(Caixa caixa) {
		String insert = "insert into " + tabela + " values(" +
														caixa.insert() +
												  ")";
		super.insert(insert);
	}

	public Caixa select(int codigo) {
		Caixa caixa = new Caixa();
		String select = "select * from " + tabela + " where " + caixa.select() +
						" = " + codigo;
		ResultSet rs = super.select(select);
		try {
			if (rs.next()) {
				caixa = new Caixa(rs.getInt("codigo"),
								  rs.getString("nome"));
			} else {
				caixa = null;
			}
		} catch (Exception e) {
		}
		/* caixa = new Caixa(rs.codigo, rs.nome)*/
		return caixa;
	}

	public void update(Caixa caixa) {
		String update = "update " + tabela + " " + caixa.update();
		super.update(update);
	}

	public void delete(Caixa caixa) {
		String delete = "delete from " + tabela + " where " + caixa.delete();
		super.delete(delete);
	}
}
