//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/TiposDePagamento.java

import java.util.Vector;

/**
 * @author
 */
public class TiposDePagamento extends Vector {

}
