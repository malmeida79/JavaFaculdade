//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/Produtos.java

import java.util.Vector;

/**
 * @author 
 * Cole��o de Produto
 */
public class Produtos extends Vector {
	private Produto produtos[];
	
	public Produtos() {}
}
