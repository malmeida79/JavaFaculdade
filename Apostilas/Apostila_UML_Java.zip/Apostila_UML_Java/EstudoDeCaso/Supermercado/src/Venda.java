//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/Venda.java


/**
 * @author
 * Registro de vendas de produtos a um cliente
 */
public class Venda {
	private VendaProduto produto[];
	private TipoDePagamento tipoPagamento;

	public Venda() {}

	/**
	 * @param valor
	 * @return float
	 * @exception
	 * @author
	 * Calcula o valor do troco, subtraindo o valor total da Venda do valor fornecido
	 * @roseuid 399B2614032F
	 */
	public float troco(float valor) {return 0;}
}
