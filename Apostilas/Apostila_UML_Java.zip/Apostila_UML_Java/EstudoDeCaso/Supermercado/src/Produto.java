//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/Produto.java


/**
 * @author 
 * Produto
 */
public class Produto {
	private int codigo;
	
	public Produto() {}
}
