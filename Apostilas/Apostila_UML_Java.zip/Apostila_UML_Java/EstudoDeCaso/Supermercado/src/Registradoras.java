//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/Registradoras.java

import java.util.Vector;

/**
 * @author 
 * Cole��o dos equipamento de m�quinas registradoras
 */
public class Registradoras extends Vector {
	private Registradora registradoras[];
	
	public Registradoras() {}
}
