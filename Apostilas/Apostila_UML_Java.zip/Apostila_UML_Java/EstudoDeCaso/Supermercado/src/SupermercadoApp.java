
/**
 * Title:        <p>
 * Description:  <p>
 * Copyright:    Copyright (c) <p>
 * Company:      <p>
 * @author
 * @version 1.0
 */


public class SupermercadoApp {

	public static void main(String[] args) {

	/* Caixas */
		Caixas caixas = new Caixas();
		Caixa caixa = new Caixa(1, "AAAAAAAAAAAAAAA");
		/* Criando a tabela de clientes */
//		caixas.create(caixa);
		/* Inserindo Caixas */
		caixas.insert(caixa);
		caixa = new Caixa(2, "BBBBBBBBBBBBBBB");
		caixas.insert(caixa);
		caixa = new Caixa(3, "CCCCCCCCCCCCCCC");
		caixas.insert(caixa);
		caixa = new Caixa(4, "DDDDDDDDDDDDDDD");
		caixas.insert(caixa);
		/* Pesquisando Caixas */
		Caixa caixaSelect = caixas.select(1);
		System.out.println( caixaSelect );
		/* Alterando Caixas */
		Caixa caixaUpdate = new Caixa(1, "ZZZZZZZZZZZZZZZZ");
		caixas.update( caixaUpdate );
		caixa = caixas.select(1);
		System.out.println( caixa );
		/* Apagando Caixa */
		caixas.delete( caixa );
		caixa = caixas.select(1);
		System.out.println( caixa );

	/* Caixas */



	}
}