//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/VendaProduto.java


/**
 * @author 
 * Classe que associa um produto a uma venda
 */
public class VendaProduto {
	
	/**
	 * @author 
	 * c�digo do produto
	 */
	private int codigo;
	
	/**
	 * @author 
	 * quantidade do produto
	 */
	private int quantidade;
	private Produto produto;
	
	public VendaProduto() {}
}
