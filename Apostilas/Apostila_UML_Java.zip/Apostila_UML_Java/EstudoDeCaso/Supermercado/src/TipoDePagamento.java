//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/TipoDePagamento.java


/**
 * @author
 */
public class TipoDePagamento {
	private int codigo;
	private String descricao;

	public TipoDePagamento(int codigo, String descricao){
		this.codigo = codigo;
		this.descricao = descricao;
	}

	/**
	 * @return String
	 * @exception
	 * @author
	 * @roseuid 399B37510212
	 */
	public String toString() {
		return "[" + codigo + "," + descricao + "]";
	}
}
