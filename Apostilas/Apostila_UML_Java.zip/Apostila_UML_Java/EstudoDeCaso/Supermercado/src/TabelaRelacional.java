import java.sql.*;

public abstract class TabelaRelacional {
	private final int QUERY	= 1;
	private final int UPDATE	= 2;
	private String driver = "interbase.interclient.Driver";
	private String urlBanco = "jdbc:interbase://localhost/c:/InfoNet/HouseTech.gdb";
	private String usuario = "SYSDBA";
	private String senha = "masterkey";

	public TabelaRelacional() {}

	public void create(String create) {
		System.out.println( create );
		this.executeSQL(create, UPDATE);
	}

	public void insert(String insert) {
		System.out.println( insert );
		this.executeSQL( insert, UPDATE);
	}

	public ResultSet select(String select) {
		System.out.println( select );
		return this.executeSQL(select, QUERY);
	}

	public void update(String update) {
		System.out.println( update );
		this.executeSQL(update, UPDATE);
	}

	public void delete(String delete) {
		System.out.println( delete );
		this.executeSQL(delete, UPDATE);

	}

	private ResultSet executeSQL (String sql, int tipoSQL) {
		try {
			Class.forName(driver);
			Connection connection = DriverManager.getConnection(urlBanco,
																usuario,
																senha);
			Statement stmt = connection.createStatement();
			if ( tipoSQL == UPDATE ) {
				stmt.executeUpdate(sql);
				connection.close();
				return null;
			} else {
				ResultSet rs = stmt.executeQuery(sql);
				return rs;
			}
		} catch (ClassNotFoundException classEx) {
			String msg = "Erro ao carregar o driver : " + classEx.getMessage();
			System.out.println( msg );
		} catch (SQLException sqlEx) {
			String msg = "Erro na conex�o ao banco de dados : " +
						 sqlEx.getMessage();
			System.out.println( msg );
		} catch (Exception ex) {
			String msg = "Erro Geral : " + ex.getMessage();
			System.out.println( msg );
		}
		return null;
	}
}
