//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/Registradora.java


/**
 * @author
 * Equipamento que registra a venda (produtos e quantidades)
 */
public class Registradora {
	private int codigo;
	private Venda vendas[];

	public Registradora() {}

	/**
	 * @return String
	 * @exception
	 * @author
	 * Rela��o de Venda realizadas no dia
	 * @roseuid 399B258C001C
	 */
	public String vendas() {return "";}

	/**
	 * @return void
	 * @exception
	 * @author
	 * @roseuid 399B2D7B0261
	 */
	public void login() {}

	/**
	 * @return void
	 * @exception
	 * @author
	 * @roseuid 399B2D850067
	 */
	public void logout() {}
}
