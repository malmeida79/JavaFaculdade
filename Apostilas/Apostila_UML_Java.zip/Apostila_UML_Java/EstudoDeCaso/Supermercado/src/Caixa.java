public class Caixa {
	private int codigo;
	private String nome;

	public Caixa() {};

	public Caixa(int codigo, String nome) {
		this.codigo = codigo;
		this.nome = nome;
	}

	public String create () {
		return "codigo int not null primary key, " +
			   "nome char(30) not null";
	}

	public String insert () {
		return codigo + ", '" + nome + "'";
	}

	public String select () {
		return "codigo";
	}

	public String update () {
		return "set nome = '" + nome + "' where codigo = " + codigo;
	}

	public String delete () {
		return "codigo = " + codigo;
	}

	public void vendas() {

	}

	public String toString () {
		return "[" + codigo + ", " + nome + "]";
	}
}
