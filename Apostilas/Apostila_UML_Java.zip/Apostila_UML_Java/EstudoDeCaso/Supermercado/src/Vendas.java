//Source file: C:/Meus documentos/CursoDeUML/EstudoDeCaso/Supermercado/src/Vendas.java

import java.util.Vector;

/**
 * @author 
 * Cole��o das vendas realizadas
 */
public class Vendas extends Vector {
	private Venda vendas[];
	
	public Vendas() {}
}
