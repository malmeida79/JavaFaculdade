//Source file: C:/Meus documentos/CursoDeUML/Interface/Interface.java


/**
 * @author 
 */
public interface Interface {
	private static final String const1 = "Valor inicial";
	private static final Date const2 = "01/01/01";
	private static final Byte const3 = 0;
	
	/**
	 * @param param1
	 * @return String
	 * @exception 
	 * @author 
	 * @roseuid 3991513800EC
	 */
	public String m�todo1(String param1);
	
	/**
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 3991513800EE
	 */
	public void m�todo2();
	
	/**
	 * @param param
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 3991513800EF
	 */
	public void m�todo3(Object param);
}
