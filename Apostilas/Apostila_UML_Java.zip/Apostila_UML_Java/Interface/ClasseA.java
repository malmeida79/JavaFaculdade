//Source file: C:/Meus documentos/CursoDeUML/Interface/ClasseA.java


/**
 * @author 
 */
public class ClasseA implements Interface {
	
	public ClasseA() {}
	
	/**
	 * @param param1
	 * @return String
	 * @exception 
	 * @author 
	 * @roseuid 3991B9F50240
	 */
	public String m�todo1(String param1) {}
	
	/**
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 3991B9F502C3
	 */
	public void m�todo2() {}
	
	/**
	 * @param param
	 * @return void
	 * @exception 
	 * @author 
	 * @roseuid 3991B9F502F5
	 */
	public void m�todo3(Object param) {}
}
