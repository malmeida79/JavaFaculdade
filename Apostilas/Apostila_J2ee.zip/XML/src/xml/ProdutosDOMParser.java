package xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import java.io.File;
import java.io.IOException;

import org.w3c.dom.Document;
import org.w3c.dom.DOMException;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

public class ProdutosDOMParser {

  static Document document;

  static final String[] typeName = {
    "none",
    "Element",
    "Attr",
    "Text",
    "CDATA",
    "EntityRef",
    "Entity",
    "ProcInstr",
    "Comment",
    "Document",
    "DocType",
    "DocFragment",
    "Notation",
  };

  public static void main(String[] args) {

    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

    try {
      String xmlFileName = "D:/My Documents/CursoJava/Enterprise/XML/produtos.xml";
      DocumentBuilder builder = factory.newDocumentBuilder();
      document = builder.parse( new File(xmlFileName) );
      NodeList nodeList = document.getChildNodes();
      System.out.println("document: " + document);

      for (int i = 0; i < nodeList.getLength(); i++ ) {
        Node node = nodeList.item(i);
        System.out.println("node[" + i + "] = " + node);
      }

      NodeList produtos = nodeList.item(1).getChildNodes();
      System.out.println("produtos.getLength() = " + produtos.getLength());
      for (int i =0; i < produtos.getLength(); i++) {
        Node produto = produtos.item(i);
        if (produto != null && produto.getNodeType() == 1) {
          System.out.println("produto:" + produto.getNodeName());
        }
      }

    } catch (SAXParseException spe) {
      System.out.println("\n** Parsing error"
        + ", line " + spe.getLineNumber()
        + ", uri " + spe.getSystemId());
      System.out.println("   " + spe.getMessage() );

      Exception  x = spe;
      if (spe.getException() != null)
        x = spe.getException();
      x.printStackTrace();
    } catch (SAXException sxe) {
      Exception  x = sxe;
      if (sxe.getException() != null)
        x = sxe.getException();
      x.printStackTrace();
     } catch (ParserConfigurationException pce) {
      pce.printStackTrace();
     } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }

}