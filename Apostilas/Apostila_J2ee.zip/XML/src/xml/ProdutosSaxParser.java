package xml;

import java.io.*;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;


/**
 * Classe para realizar o Paser SAX de um arquivo XML
 */
public class ProdutosSaxParser extends DefaultHandler {

  StringBuffer textBuffer;

  private int contProdutos;
  private float totalPrecos;

  public ProdutosSaxParser () {
    contProdutos = 0;
  }

  /*
   * M�todo para fazer leitura de caracters com Buffer.
   * Utiliza o atributo est�tico textBuffer
   */
  public void characters(char buf[], int offset, int len)
    throws SAXException {
    String s = new String(buf, offset, len);
    if (textBuffer == null) {
      textBuffer = new StringBuffer(s);
    } else {
      textBuffer.append(s);
    }
  }

  /* M�todo para tratar o evento: In�cio do Documento */
  public void startDocument() throws SAXException {
    System.out.println("Inicando processamento...");
  }

  /* M�todo para tratar o evento: Fim do Documento */
  public void endDocument() throws SAXException {
    System.out.println("Quantidade produtos = " + contProdutos);
    System.out.println("Total de pre�os = " + totalPrecos);
    System.out.println("Finalizando processamento.");
  }

  /* M�todo para tratar o evento: In�cio de Elemento */
  public void startElement(String namespaceURI, String sName,  String qName,
                           Attributes attrs)
    throws SAXException {
  }

  /* M�todo para tratar o evento: Fim de Elemento */
  public void endElement(String namespaceURI, String sName, String qName)
    throws SAXException {
    /* Verificando se uma tag produto foi processada */
    if (qName.equals("produto")){
      this.contProdutos++;
    }
    /* Verificando se uma tag pre�o foi processada */
    if ( qName.equals("preco") ) {
      /* Obtendo o pre�o atrav�s do StringBuffer manipulado por characters*/
      String sPreco = new String(textBuffer);
      if ( sPreco != null) {
        try {
          float preco = Float.parseFloat(sPreco);
          totalPrecos += preco;
        } catch (Exception e) {
          System.out.println("Formato do pre�o errado: " + sPreco);
        }
      }
    }
    textBuffer = null;
  }


  public static void main(String[] args) {
    String xmlFileName = "D:/My Documents/CursoJava/Enterprise/XML/Produtos.xml";

    DefaultHandler handler = new ProdutosSaxParser();
    SAXParserFactory factory = SAXParserFactory.newInstance();

    try {
      SAXParser saxParser = factory.newSAXParser();
      saxParser.parse( xmlFileName, handler );
    } catch (Throwable t) {
      t.printStackTrace();
    }
    System.exit(0);
  }

}