package xml;

import java.io.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;


/**
 * Classe para realizar o Paser SAX de um arquivo XML
 */
public class SaxParser extends DefaultHandler {
  static private Writer out;
  StringBuffer textBuffer;

  /* M�todo para escrever na sa�da padr�o. Utiliza o atributo est�tico out */
  private void emit(String s) throws SAXException {
    try {
      out.write(s);
      out.flush();
    } catch (IOException e) {
      throw new SAXException("I/O error", e);
    }
  }

  /*
   * M�todo para fazer leitura de caracters com Buffer.
   * Utiliza o atributo est�tico textBuffer
   */
  public void characters(char buf[], int offset, int len)
    throws SAXException {
    String s = new String(buf, offset, len);
    if (textBuffer == null) {
      textBuffer = new StringBuffer(s);
    } else {
      textBuffer.append(s);
    }
  }

  /*
   * M�todo para utilizar o buffer de caracters para escrever no objeto out
   */
  private void echoText() throws SAXException {
    if (textBuffer == null) return;
    String s = ""+textBuffer;
    emit(s);
    textBuffer = null;
  }


  /* M�todo para escrever salto de linha na sa�da padr�o */

  private void nl()  throws SAXException {
    String lineEnd = System.getProperty("line.separator");
    try {
      out.write(lineEnd);
    } catch (IOException e) {
      throw new SAXException("I/O error", e);
    }
  }

  /* M�todo para tratar o evento: In�cio do Documento */
  public void startDocument() throws SAXException {
    emit("<?xml version='1.0' encoding='UTF-8'?>");
    nl();
  }

  /* M�todo para tratar o evento: Fim do Documento */
  public void endDocument() throws SAXException {
    try {
      nl();
      out.flush();
    } catch (IOException e) {
      throw new SAXException("I/O error", e);
    }
  }

  /* M�todo para tratar o evento: In�cio de Elemento */
  public void startElement(String namespaceURI, String sName,  String qName,
                           Attributes attrs)
    throws SAXException {
    echoText();
    String eName = sName; // element name
    if ("".equals(eName)) eName = qName; // not namespaceAware
    emit("<"+eName);
    if (attrs != null) {
      for (int i = 0; i < attrs.getLength(); i++) {
        String aName = attrs.getLocalName(i); // Attr name
        if ("".equals(aName)) aName = attrs.getQName(i);
        emit(" ");
        emit(aName+"=\""+attrs.getValue(i)+"\"");
      }
    }
    emit(">");
  }

  /* M�todo para tratar o evento: Fim de Elemento */
  public void endElement(String namespaceURI, String sName, String qName)
    throws SAXException {
    echoText();
    String eName = sName; // element name
    if ("".equals(eName)) eName = qName; // not namespaceAware
    emit("<"+eName+">");
  }


  public static void main(String[] args) {
    String xmlFileName = "D:/My Documents/CursoJava/Enterprise/XML/Produtos.xml";

    // Use an instance of ourselves as the SAX event handler
    DefaultHandler handler = new SaxParser();
    // Use the default (non-validating) parser
    SAXParserFactory factory = SAXParserFactory.newInstance();

    try {
      out = new OutputStreamWriter(System.out, "UTF8");
      // Parse the input
      SAXParser saxParser = factory.newSAXParser();
      saxParser.parse( xmlFileName, handler );
    } catch (Throwable t) {
      t.printStackTrace();
    }
    System.exit(0);
  }

}