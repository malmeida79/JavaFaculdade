package components;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.Vector;
import java.util.StringTokenizer;

// IconDemoApp.java requires the following files:
//   images/right.gif
//   images/left.gif
//   images/dimmedRight.gif
//   images/dimmedLeft.gif
//   images/sunw01.jpg
//   images/sunw02.jpg
//   images/sunw03.jpg
//   images/sunw04.jpg
//   images/sunw05.jpg

public class IconDemoApp extends JFrame implements ActionListener {

    Vector<Photo> photos = new Vector<Photo>();

    static IconDemoApp frame;

    JButton previousButton;
    JButton nextButton;
    JLabel photographLabel;
    JLabel captionLabel;
    JLabel numberLabel;

    int current = 0;
    int widthOfWidest = 0;
    int heightOfTallest = 0;

    String imagedir = "images/";
    
    public static void main(String args[]) {
        String myargs[] = {
            "sunw01.jpg", "Original SUNW Logo", "300", "200",
            "sunw02.jpg", "The Clocktower", "275", "220", 
            "sunw03.jpg", "Clocktower from the West", "268", "195", 
            "sunw04.jpg", "The Mansion", "315", "200",
            "sunw05.jpg", "Sun Auditorium", "330", "205"
        };

        frame = new IconDemoApp("Icon Demo", myargs); 

    }
    
    public IconDemoApp(String title, String args[]) {
        // Parse the application arguments listed as arguments in JNLP
        // Must come in sets of 4: image file, file description, width, height
        if (args.length % 4 != 0) {
            System.out.println("Error - must specify arguments in sets of 4: image file, description of image, width, and height for each image to process.");
            return;
        } else {
            for (int i=0; i < args.length; i++) {
                String image = args[i];
                String caption = args[++i];
                int width = getWidth(args[++i]);
                int height = getHeight(args[++i]);
                Photo photo = new Photo(image, caption, height, width);
                photos.addElement(photo);
            }
        }
        init();
    }

    private void initializeGUI() {
        // If the JNLP doesn't provide default image parameters
        // display an error message
        if (photos.size() == 0) {
            captionLabel = new JLabel("No images listed ...");
            captionLabel.setHorizontalAlignment(JLabel.CENTER);
            frame.add(captionLabel);
            return;
        }

        // Create the GUI components

        // A label to identify Picture XX of XX
        numberLabel = new JLabel("Picture " + (current+1) +
                                    " of " + photos.size());
        numberLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // A label for the caption
        final Photo first = photos.firstElement();
        captionLabel = new JLabel(first.caption);
        captionLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // A label for displaying the pictures
        photographLabel = new JLabel("Loading first image ...");
        photographLabel.setHorizontalAlignment(SwingConstants.CENTER);
        photographLabel.setBorder(BorderFactory.createEtchedBorder());
        photographLabel.setPreferredSize(new java.awt.Dimension(300, 200));

        // Set the preferred size for the picture, leave room for borders
        Insets i = photographLabel.getInsets();
        photographLabel.setPreferredSize(new Dimension(
                            widthOfWidest+i.left+i.right,
                            heightOfTallest+i.bottom+i.top));

        // Create the next and previous buttons
        ImageIcon nextIcon = createAppImageIcon("images/right.gif",
                                "a right arrow");
        ImageIcon dimmedNextIcon = createAppImageIcon("images/dimmedRight.gif",
                                "a dimmed right arrow");
        ImageIcon previousIcon = createAppImageIcon("images/left.gif",
                                "a left arrow");
        ImageIcon dimmedPreviousIcon = createAppImageIcon("images/dimmedLeft.gif",
                                "a dimmed left arrow");

        nextButton = new JButton("Next", nextIcon);
        nextButton.setDisabledIcon(dimmedNextIcon);
        nextButton.setMnemonic('N');
        nextButton.setBorder(BorderFactory.createEtchedBorder());
        nextButton.setHorizontalTextPosition(SwingConstants.LEFT);
        nextButton.setPreferredSize(new Dimension(80, 30));
        nextButton.setIconTextGap(8);
        nextButton.setActionCommand("next");
        nextButton.addActionListener(this);

        previousButton = new JButton("Previous", previousIcon);
        previousButton.setDisabledIcon(dimmedPreviousIcon);
        previousButton.setMnemonic('P');
        previousButton.setBorder(BorderFactory.createEtchedBorder());
        previousButton.setHorizontalTextPosition(SwingConstants.RIGHT);
        previousButton.setPreferredSize(new java.awt.Dimension(80, 30));
        previousButton.setIconTextGap(8);
        previousButton.setActionCommand("previous");
        previousButton.addActionListener(this);
        previousButton.setEnabled(false);

        // Lay out the GUI (taken from NetBeans code)
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
            .addComponent(numberLabel, GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)
            .addComponent(photographLabel, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)
            .addComponent(captionLabel, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
            .addComponent(previousButton, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 150, Short.MAX_VALUE)
            .addComponent(nextButton, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE)))
            .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(captionLabel)
            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(photographLabel, GroupLayout.DEFAULT_SIZE, 308, Short.MAX_VALUE)
            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(numberLabel)
            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
            .addComponent(nextButton, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
            .addComponent(previousButton, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            .addContainerGap())
        );
        pack();

        // Start loading the image for the first picture now
        // The loadImage method uses a SwingWorker
        // to load the image in a separate thread
        loadImage(imagedir + first.filename, current);
    }
    
    public void init() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                initializeGUI();
                frame.setVisible(true);
                frame.setSize(widthOfWidest+150, heightOfTallest+150);
                
            }
        });
    }

    //User clicked either the next or previous button
    public void actionPerformed(ActionEvent e) {
        //Show loading message
        photographLabel.setIcon(null);
        photographLabel.setText("Loading image...");

        //Compute index of photograph to view
        if (e.getActionCommand().equals("next")) {
            current += 1;
            if (!previousButton.isEnabled())
                previousButton.setEnabled(true);
            if (current == photos.size() - 1)
                nextButton.setEnabled(false);
        } else {
            current -= 1;
            if (!nextButton.isEnabled())
                nextButton.setEnabled(true);
            if (current == 0)
                previousButton.setEnabled(false);
        }

        //Get the photo object
        Photo photo = photos.elementAt(current);

        //Update the caption and number labels
        captionLabel.setText(photo.caption);
        numberLabel.setText("Picture " + (current+1) +
                            " of " + photos.size());

        //Update the photograph
        if (photo.icon == null) {     //haven't viewed this photo before
            loadImage(imagedir + photo.filename, current);
        } else {
            updatePhotograph(photo);
        }
    }

    //Must be invoked from the event-dispatching thread
    private void updatePhotograph(Photo photo) {
        ImageIcon icon = photo.icon;

        photographLabel.setToolTipText(photo.filename + ": " +
                                    icon.getIconWidth() + " X " +
                                    icon.getIconHeight());
        photographLabel.setIcon(icon);
        photographLabel.setText("");
    }

    //Load an image in a worker thread
    private void loadImage(final String imagePath, final int index) {
        (new SwingWorker<ImageIcon, Void>() {

            @Override
            public ImageIcon doInBackground() {
                return createAppImageIcon(imagePath, "photo #" + index);
            }

            @Override
            public void done() { 
                Photo photo = photos.elementAt(index);
                try {
                    photo.icon = get();
                } catch (InterruptedException ignore) {}
                catch (java.util.concurrent.ExecutionException e) {
                    String why = null;
                    Throwable cause = e.getCause();
                    if (cause != null) {
                        why = cause.getMessage();
                    } else {
                        why = e.getMessage();
                    }
                    System.err.println("Error retrieving file: " + why);
                }

                if (index == current) {
                    updatePhotograph(photo);
                }
            }
        }).execute();
    }

    protected int getWidth(String swidth) {
        int width = 0;
        String widthString = swidth;
        if (widthString != null) {
            try {
                width = Integer.parseInt(widthString);
            } catch (NumberFormatException e) {
                width = 0;
            }
        } else {
            width = 0;
        }
        if (width > widthOfWidest)
            widthOfWidest = width;
        return width;
    }

    protected int getHeight(String sheight) {
        int height = 0;
        String heightString = sheight;
        if (heightString != null) {
            try {
                height = Integer.parseInt(heightString);
            } catch (NumberFormatException e) {
                height = 0;
            }
        } else {
            height = 0;
        }
        if (height > heightOfTallest)
            heightOfTallest = height;
        return height;
    }

    // Returns an ImageIcon, or null if the path was invalid
    // When running  using Java Plug-in, getResourceAsStream
    // is more efficient than getResource
    protected static ImageIcon createAppImageIcon(String path,
                                            String description) {
        int MAX_IMAGE_SIZE = 124000;    // Change this to the size of
                                        // your biggest image, in bytes
        int count = 0;
        BufferedInputStream imgStream = new BufferedInputStream(
           IconDemoApp.class.getResourceAsStream(path));
        if (imgStream != null) {
            byte buf[] = new byte[MAX_IMAGE_SIZE];
            try {
                count = imgStream.read(buf);
            } catch (IOException ieo) {
                System.err.println("Couldn't read stream from file: " + path);
            }

            try {
                imgStream.close();
            } catch (IOException ieo) {
                 System.err.println("Can't close file " + path);
            }

            if (count <= 0) {
                System.err.println("Empty file: " + path);
                return null;
            }
            return new ImageIcon(Toolkit.getDefaultToolkit().createImage(buf),
                                 description);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }

    class Photo {
        public String filename;
        public String caption;
        public int height;
        public int width;
        public ImageIcon icon = null;

        public Photo(String filename, String caption, int height, int width) {
            this.filename = filename;
            this.caption = caption;
            this.height = height;
            this.width = width;
        }
    }
}
